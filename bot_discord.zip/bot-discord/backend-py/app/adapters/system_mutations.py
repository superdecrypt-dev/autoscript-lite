import base64
import copy
import grp
import ipaddress
import json
import os
import pwd
import random
import re
import secrets
import shutil
import string
import tarfile
import tempfile
import threading
import time
import urllib.parse
import urllib.error
import urllib.request
import uuid
import zlib
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from pathlib import Path, PurePosixPath
from typing import Any

from ..utils.locks import file_lock

ACCOUNT_ROOT = Path("/opt/account")
QUOTA_ROOT = Path("/opt/quota")
SPEED_POLICY_ROOT = Path("/opt/speed")
SPEED_CONFIG_FILE = Path("/etc/xray-speed/config.json")
XRAY_CONFDIR = Path("/usr/local/etc/xray/conf.d")
XRAY_INBOUNDS_CONF = XRAY_CONFDIR / "10-inbounds.json"
XRAY_OUTBOUNDS_CONF = XRAY_CONFDIR / "20-outbounds.json"
XRAY_ROUTING_CONF = XRAY_CONFDIR / "30-routing.json"
XRAY_DNS_CONF = XRAY_CONFDIR / "02-dns.json"
NGINX_CONF = Path("/etc/nginx/conf.d/xray.conf")
XRAY_DOMAIN_FILE = Path("/etc/xray/domain")
CERT_DIR = Path("/opt/cert")
CERT_FULLCHAIN = CERT_DIR / "fullchain.pem"
CERT_PRIVKEY = CERT_DIR / "privkey.pem"
EDGE_RUNTIME_ENV_FILE = Path("/etc/default/edge-runtime")
BOT_STATE_DIR = Path(os.getenv("BOT_STATE_DIR", "/var/lib/bot-discord"))
WORK_DIR = BOT_STATE_DIR / "tmp"
ROUTING_LOCK_FILE = "/run/autoscript/locks/xray-routing.lock"
SPEED_POLICY_LOCK_FILE = "/var/lock/xray-speed-policy.lock"
USER_DATA_MUTATION_LOCK_FILE = "/run/autoscript/locks/user-data-mutation.lock"
XRAY_PROTOCOLS = ("vless", "vmess", "trojan")
SSH_PROTOCOL = "ssh"
USER_PROTOCOLS = XRAY_PROTOCOLS + (SSH_PROTOCOL,)
PROTOCOLS = XRAY_PROTOCOLS
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")
SSH_USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_-]{1,31}$")
DOMAIN_RE = re.compile(r"^([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,}$")
SPEED_OUTBOUND_TAG_PREFIX = "speed-mark-"
SPEED_RULE_MARKER_PREFIX = "dummy-speed-user-"
SPEED_MARK_MIN = 1000
SPEED_MARK_MAX = 59999
QUOTA_UNIT_DECIMAL = {"decimal", "gb", "1000", "gigabyte"}
DEFAULT_EGRESS_PORTS = {"1-65535", "0-65535"}
DNS_LOCK_FILE = "/run/autoscript/locks/xray-dns.lock"
DNS_QUERY_STRATEGY_ALLOWED = {"UseIP", "UseIPv4", "UseIPv6", "PreferIPv4", "PreferIPv6"}
CLOUDFLARE_API_TOKEN = os.getenv(
    "CLOUDFLARE_API_TOKEN",
    "ZEbavEuJawHqX4-Jwj-L5Vj0nHOD-uPXtdxsMiAZ",
).strip()
PROVIDED_ROOT_DOMAINS = (
    "vyxara1.web.id",
    "vyxara2.web.id",
)
ACME_SH_INSTALL_REF = os.getenv("ACME_SH_INSTALL_REF", "f39d066ced0271d87790dc426556c1e02a88c91b").strip()
ACME_SH_TARBALL_URL = f"https://codeload.github.com/acmesh-official/acme.sh/tar.gz/{ACME_SH_INSTALL_REF}"
ACME_SH_SCRIPT_URL = f"https://raw.githubusercontent.com/acmesh-official/acme.sh/{ACME_SH_INSTALL_REF}/acme.sh"
ACME_SH_DNS_CF_HOOK_URL = (
    f"https://raw.githubusercontent.com/acmesh-official/acme.sh/{ACME_SH_INSTALL_REF}/dnsapi/dns_cf.sh"
)
SSH_ACCOUNT_DIR = ACCOUNT_ROOT / SSH_PROTOCOL
SSH_QUOTA_DIR = QUOTA_ROOT / SSH_PROTOCOL
SSHWS_LOCK_FILE = Path("/run/autoscript/locks/sshws-qac.lock")
SSHWS_QAC_ENFORCER_BIN = Path("/usr/local/bin/sshws-qac-enforcer")
ZIVPN_SERVICE = "zivpn"
ZIVPN_CONFIG_FILE = Path("/etc/zivpn/config.json")
ZIVPN_SYNC_BIN = Path("/usr/local/bin/zivpn-password-sync")
ZIVPN_PASSWORDS_DIR = Path("/etc/zivpn/passwords.d")
ZIVPN_CERT_FILE = Path("/etc/zivpn/zivpn.crt")
ZIVPN_KEY_FILE = Path("/etc/zivpn/zivpn.key")
ZIVPN_DEFAULT_LISTEN = ":5667"
ZIVPN_DEFAULT_OBFS = "zivpn"

_USER_DATA_MUTATION_LOCK_STATE = threading.local()


@contextmanager
def _user_data_mutation_lock():
    depth = int(getattr(_USER_DATA_MUTATION_LOCK_STATE, "depth", 0) or 0)
    if depth > 0:
        _USER_DATA_MUTATION_LOCK_STATE.depth = depth + 1
        try:
            yield
        finally:
            _USER_DATA_MUTATION_LOCK_STATE.depth = depth
        return

    with file_lock(USER_DATA_MUTATION_LOCK_FILE):
        _USER_DATA_MUTATION_LOCK_STATE.depth = 1
        try:
            yield
        finally:
            _USER_DATA_MUTATION_LOCK_STATE.depth = 0


def _user_data_mutation_locked(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        with _user_data_mutation_lock():
            return func(*args, **kwargs)

    return wrapper


def _run_cmd(
    argv: list[str],
    timeout: int = 25,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
) -> tuple[bool, str]:
    try:
        proc = shutil.which(argv[0])
        if proc is None:
            return False, f"Command tidak ditemukan: {argv[0]}"
        import subprocess

        cp = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            env=env,
            cwd=cwd,
        )
    except Exception as exc:
        return False, f"Gagal menjalankan {' '.join(argv)}: {exc}"

    out = ((cp.stdout or "") + ("\n" + cp.stderr if cp.stderr else "")).strip()
    if not out:
        out = "(no output)"
    if cp.returncode != 0:
        return False, f"[exit {cp.returncode}]\n{out}"
    return True, out


def _service_exists(name: str) -> bool:
    ok, _ = _run_cmd(["systemctl", "status", name], timeout=10)
    if ok:
        return True
    ok2, out2 = _run_cmd(["systemctl", "list-unit-files", f"{name}.service"], timeout=10)
    if not ok2:
        return False
    return f"{name}.service" in out2


def _service_is_active(name: str) -> bool:
    ok, out = _run_cmd(["systemctl", "is-active", name], timeout=10)
    if not ok:
        return False
    state = out.splitlines()[-1].strip() if out else ""
    return state == "active"


def _service_state(name: str) -> str:
    ok, out = _run_cmd(["systemctl", "is-active", name], timeout=10)
    if ok:
        return out.splitlines()[-1].strip() if out else ""
    if out:
        return out.splitlines()[-1].strip()
    return ""


def _zivpn_account_info_enabled() -> bool:
    return _zivpn_runtime_available()


def _zivpn_runtime_available() -> bool:
    if not ZIVPN_SYNC_BIN.exists():
        return False
    return _service_exists(ZIVPN_SERVICE) or ZIVPN_CONFIG_FILE.exists()


def _zivpn_password_file(username: str) -> Path:
    return ZIVPN_PASSWORDS_DIR / f"{str(username or '').strip()}.pass"


def _zivpn_runtime_settings() -> dict[str, str]:
    settings = {
        "listen": ZIVPN_DEFAULT_LISTEN,
        "cert": str(ZIVPN_CERT_FILE),
        "key": str(ZIVPN_KEY_FILE),
        "obfs": ZIVPN_DEFAULT_OBFS,
    }
    ok, payload = _read_json(ZIVPN_CONFIG_FILE)
    if ok and isinstance(payload, dict):
        for key in ("listen", "cert", "key", "obfs"):
            value = str(payload.get(key) or "").strip()
            if value:
                settings[key] = value
    listen = str(settings.get("listen") or "").strip() or ZIVPN_DEFAULT_LISTEN
    if listen.isdigit():
        listen = f":{listen}"
    settings["listen"] = listen
    return settings


def _zivpn_sync_runtime() -> tuple[bool, str]:
    if not _zivpn_runtime_available():
        return True, "skip"
    settings = _zivpn_runtime_settings()
    return _run_cmd(
        [
            str(ZIVPN_SYNC_BIN),
            "--config",
            str(ZIVPN_CONFIG_FILE),
            "--passwords-dir",
            str(ZIVPN_PASSWORDS_DIR),
            "--listen",
            settings["listen"],
            "--cert",
            settings["cert"],
            "--key",
            settings["key"],
            "--obfs",
            settings["obfs"],
            "--account-dir",
            str(SSH_ACCOUNT_DIR),
            "--service",
            ZIVPN_SERVICE,
            "--sync-service-state",
        ],
        timeout=30,
    )


def _zivpn_store_user_password(username: str, password: str) -> tuple[bool, str]:
    username_n = str(username or "").strip()
    password_n = str(password or "").strip()
    if not username_n or not password_n:
        return False, "username/password ZIVPN tidak valid"
    try:
        ZIVPN_PASSWORDS_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(ZIVPN_PASSWORDS_DIR, 0o700)
        dst = _zivpn_password_file(username_n)
        _write_text_atomic(dst, password_n + "\n")
        _chmod_600(dst)
        return True, str(dst)
    except Exception as exc:
        return False, f"Gagal menyimpan password ZIVPN: {exc}"


def _zivpn_sync_user_password(username: str, password: str) -> tuple[bool, str]:
    if not _zivpn_runtime_available():
        return True, "skip"
    ok_store, store_msg = _zivpn_store_user_password(username, password)
    if not ok_store:
        return False, store_msg
    return _zivpn_sync_runtime()


def _zivpn_remove_user_password(username: str) -> tuple[bool, str]:
    if not _zivpn_runtime_available():
        return True, "skip"
    try:
        _zivpn_password_file(username).unlink(missing_ok=True)
    except Exception as exc:
        return False, f"Gagal menghapus password ZIVPN: {exc}"
    return _zivpn_sync_runtime()


def _zivpn_user_password_synced(username: str) -> bool:
    if not _zivpn_runtime_available():
        return False
    return _zivpn_password_file(username).exists()


def _zivpn_password_read(username: str) -> str:
    if not _zivpn_runtime_available():
        return "-"
    try:
        text = _zivpn_password_file(username).read_text(encoding="utf-8").strip()
    except Exception:
        return "-"
    return text or "-"


def _edge_runtime_get_env(key: str) -> str:
    try:
        if not EDGE_RUNTIME_ENV_FILE.exists():
            return ""
        for line in EDGE_RUNTIME_ENV_FILE.read_text(encoding="utf-8").splitlines():
            text = line.strip()
            if not text or text.startswith("#") or "=" not in text:
                continue
            env_key, env_value = text.split("=", 1)
            if env_key.strip() == key:
                return env_value.strip()
    except Exception:
        return ""
    return ""


def _edge_runtime_service_name() -> str:
    provider = _edge_runtime_get_env("EDGE_PROVIDER").strip().lower()
    if provider == "nginx-stream":
        return "nginx"
    if provider == "go":
        return "edge-mux.service"
    return ""


def _edge_runtime_uses_public_http_port_80() -> bool:
    provider = _edge_runtime_get_env("EDGE_PROVIDER").strip().lower()
    active = _edge_runtime_get_env("EDGE_ACTIVATE_RUNTIME").strip().lower()
    http_port = _edge_runtime_get_env("EDGE_PUBLIC_HTTP_PORT").strip() or "80"
    if provider in {"", "none"}:
        return False
    if active not in {"1", "true", "yes", "on", "y"}:
        return False
    return http_port == "80"


def _restart_and_wait(name: str, timeout_sec: int = 20) -> bool:
    if not _service_exists(name):
        return False

    cmd_timeout = max(4, min(30, timeout_sec + 4))
    ok_restart, _ = _run_cmd(["systemctl", "restart", name], timeout=cmd_timeout)
    if ok_restart:
        end = time.time() + max(1, timeout_sec)
        while time.time() < end:
            if _service_is_active(name):
                return True
            time.sleep(0.5)
        if _service_is_active(name):
            return True
    else:
        state_after_restart = _service_state(name)
        if state_after_restart not in {"failed", "inactive", "activating", "deactivating"}:
            return False

    state_now = _service_state(name)
    if state_now in {"failed", "inactive", "activating", "deactivating"}:
        _run_cmd(["systemctl", "reset-failed", name], timeout=10)
        ok_start, _ = _run_cmd(["systemctl", "start", name], timeout=cmd_timeout)
        if not ok_start:
            return False
        end2 = time.time() + max(1, timeout_sec)
        while time.time() < end2:
            if _service_is_active(name):
                return True
            time.sleep(0.5)
        return _service_is_active(name)

    return False


def _stop_and_wait_inactive(name: str, timeout_sec: int = 20) -> bool:
    if not _service_exists(name):
        return True

    cmd_timeout = max(4, min(30, timeout_sec + 4))
    ok_stop, _ = _run_cmd(["systemctl", "stop", name], timeout=cmd_timeout)
    if not ok_stop:
        return False

    end = time.time() + max(1, timeout_sec)
    while time.time() < end:
        if _service_state(name) == "inactive":
            return True
        time.sleep(0.5)
    return _service_state(name) == "inactive"


def _read_json(path: Path) -> tuple[bool, Any]:
    if not path.exists():
        return False, f"File tidak ditemukan: {path}"
    try:
        return True, json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, f"Gagal parse JSON {path}: {exc}"


def _write_json_atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    previous = None
    try:
        previous = path.stat()
    except Exception:
        previous = None
    fd, tmp = tempfile.mkstemp(prefix=".tmp.", suffix=path.suffix or ".json", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as wf:
            json.dump(payload, wf, ensure_ascii=False, indent=2)
            wf.write("\n")
            wf.flush()
            os.fsync(wf.fileno())
        os.replace(tmp, path)
        if previous is not None:
            try:
                os.chmod(path, previous.st_mode & 0o777)
            except Exception:
                pass
            try:
                os.chown(path, previous.st_uid, previous.st_gid)
            except Exception:
                pass
        if path.parent == XRAY_CONFDIR:
            try:
                os.chmod(path, 0o640)
            except Exception:
                pass
            try:
                xray_gid = grp.getgrnam("xray").gr_gid
                os.chown(path, 0, xray_gid)
            except Exception:
                pass
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _write_text_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    previous = None
    try:
        previous = path.stat()
    except Exception:
        previous = None
    fd, tmp = tempfile.mkstemp(prefix=".tmp.", suffix=path.suffix or ".txt", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as wf:
            wf.write(content)
            wf.flush()
            os.fsync(wf.fileno())
        os.replace(tmp, path)
        if previous is not None:
            try:
                os.chmod(path, previous.st_mode & 0o777)
            except Exception:
                pass
            try:
                os.chown(path, previous.st_uid, previous.st_gid)
            except Exception:
                pass
        if path.parent == XRAY_CONFDIR:
            try:
                os.chmod(path, 0o640)
            except Exception:
                pass
            try:
                xray_gid = grp.getgrnam("xray").gr_gid
                os.chown(path, 0, xray_gid)
            except Exception:
                pass
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _write_bytes_atomic(path: Path, payload: bytes) -> tuple[bool, str]:
    path.parent.mkdir(parents=True, exist_ok=True)
    previous = None
    try:
        previous = path.stat()
    except Exception:
        previous = None
    fd, tmp = tempfile.mkstemp(prefix=".tmp.", suffix=path.suffix or ".bin", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as wf:
            wf.write(payload)
            wf.flush()
            os.fsync(wf.fileno())
        os.replace(tmp, path)
        if previous is not None:
            try:
                os.chmod(path, previous.st_mode & 0o777)
            except Exception:
                pass
            try:
                os.chown(path, previous.st_uid, previous.st_gid)
            except Exception:
                pass
        if path.parent == XRAY_CONFDIR:
            try:
                os.chmod(path, 0o640)
            except Exception:
                pass
            try:
                xray_gid = grp.getgrnam("xray").gr_gid
                os.chown(path, 0, xray_gid)
            except Exception:
                pass
    except Exception as exc:
        return False, f"Gagal menulis file {path}: {exc}"
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return True, "ok"


def _chmod_600(path: Path) -> None:
    try:
        path.chmod(0o600)
    except Exception:
        pass


def _ensure_runtime_dirs() -> None:
    for p in [
        ACCOUNT_ROOT / "vless",
        ACCOUNT_ROOT / "vmess",
        ACCOUNT_ROOT / "trojan",
        SSH_ACCOUNT_DIR,
        QUOTA_ROOT / "vless",
        QUOTA_ROOT / "vmess",
        QUOTA_ROOT / "trojan",
        SSH_QUOTA_DIR,
        SPEED_POLICY_ROOT / "vless",
        SPEED_POLICY_ROOT / "vmess",
        SPEED_POLICY_ROOT / "trojan",
        WORK_DIR,
    ]:
        p.mkdir(parents=True, exist_ok=True)


def _safe_extract_tarball(archive_path: Path, dest_dir: Path) -> tuple[bool, str]:
    dest_dir.mkdir(parents=True, exist_ok=True)
    base_real = dest_dir.resolve()
    try:
        with tarfile.open(archive_path, "r:gz") as tf:
            for member in tf.getmembers():
                raw_name = str(member.name or "")
                if "\x00" in raw_name:
                    return False, "Tar acme.sh mengandung path NUL byte."
                norm = PurePosixPath(raw_name)
                if norm.is_absolute() or ".." in norm.parts:
                    return False, f"Tar acme.sh mengandung path tidak aman: {raw_name}"
                if raw_name in {"", "."}:
                    continue
                target = (base_real / norm).resolve()
                if target != base_real and base_real not in target.parents:
                    return False, f"Tar acme.sh keluar dari direktori tujuan: {raw_name}"
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                if not member.isfile():
                    return False, f"Tar acme.sh mengandung entry tidak didukung: {raw_name}"
                target.parent.mkdir(parents=True, exist_ok=True)
                extracted = tf.extractfile(member)
                if extracted is None:
                    return False, f"Gagal membaca entry tar acme.sh: {raw_name}"
                with extracted, open(target, "wb") as dst:
                    shutil.copyfileobj(extracted, dst)
        return True, "ok"
    except Exception as exc:
        return False, f"Gagal extract acme.sh tarball: {exc}"


def _to_int(v: Any, default: int = 0) -> int:
    try:
        if v is None:
            return default
        if isinstance(v, bool):
            return int(v)
        if isinstance(v, (int, float)):
            return int(v)
        s = str(v).strip()
        if not s:
            return default
        return int(float(s))
    except Exception:
        return default


def _to_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        if isinstance(v, bool):
            return float(int(v))
        if isinstance(v, (int, float)):
            return float(v)
        s = str(v).strip().lower().replace("mbit", "").replace("mbps", "")
        if not s:
            return default
        return float(s)
    except Exception:
        return default


def _fmt_number(v: float) -> str:
    if v <= 0:
        return "0"
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return f"{v:.3f}".rstrip("0").rstrip(".")


def _fmt_quota_gb_from_bytes(quota_bytes: int) -> str:
    if quota_bytes <= 0:
        return "0"
    return _fmt_number(quota_bytes / (1024**3))


def _is_valid_username(username: str) -> bool:
    return bool(USERNAME_RE.match(username or ""))


def _email(proto: str, username: str) -> str:
    return f"{username}@{proto}"


def _detect_public_ipv4() -> str:
    ok, out = _run_cmd(["ip", "-4", "-o", "addr", "show", "scope", "global"], timeout=8)
    if ok:
        m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/", out)
        if m:
            return m.group(1)
    return "0.0.0.0"


def _geo_lookup(ip: str) -> tuple[str, str]:
    # Keep account rendering local-only; avoid third-party lookups from bot actions.
    del ip
    return "-", "-"


def _path_alt_placeholder(path: str) -> str:
    raw = str(path or "").strip()
    if not raw:
        return "-"
    if not raw.startswith("/"):
        raw = "/" + raw
    return f"/<bebas>{raw}"


def _proto_display_label(proto: str) -> str:
    mapping = {
        "vless": "Vless",
        "vmess": "Vmess",
        "trojan": "Trojan",
    }
    return mapping.get(str(proto or "").strip().lower(), str(proto or "").strip().title() or "Xray")


def _normalize_created_display(raw: Any, *, date_only: bool = False) -> str:
    value = str(raw or "").strip()
    if not value:
        return datetime.utcnow().strftime("%Y-%m-%d" if date_only else "%Y-%m-%d %H:%M")
    normalized = value.replace("T", " ").strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1]
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(normalized[: len(fmt)], fmt)
            if date_only:
                return dt.strftime("%Y-%m-%d")
            return dt.strftime("%Y-%m-%d" if fmt == "%Y-%m-%d" else "%Y-%m-%d %H:%M")
        except Exception:
            pass
    if len(normalized) >= 10 and normalized[4:5] == "-" and normalized[7:8] == "-":
        if date_only:
            return normalized[:10]
        return normalized[:16] if len(normalized) >= 16 and normalized[13:14] == ":" else normalized[:10]
    return datetime.utcnow().strftime("%Y-%m-%d" if date_only else "%Y-%m-%d %H:%M")


def _detect_domain() -> str:
    if NGINX_CONF.exists():
        for line in NGINX_CONF.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = re.match(r"^\s*server_name\s+([^;]+);", line)
            if m:
                token = m.group(1).strip().split()[0]
                if token and token != "_":
                    return token
    ok, fqdn = _run_cmd(["hostname", "-f"], timeout=8)
    if ok and fqdn.strip():
        return fqdn.splitlines()[0].strip()
    ok2, host = _run_cmd(["hostname"], timeout=8)
    if ok2 and host.strip():
        return host.splitlines()[0].strip()
    return "-"


def _parse_date_only(raw: Any) -> date | None:
    s = str(raw or "").strip()[:10]
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def _status_lock_reason(status: dict[str, Any]) -> str:
    if bool(status.get("manual_block")):
        return "manual"
    if bool(status.get("quota_exhausted")):
        return "quota"
    if bool(status.get("ip_limit_locked")):
        return "ip_limit"
    return ""


def _status_apply_lock_fields(status: dict[str, Any]) -> None:
    reason = _status_lock_reason(status)
    status["lock_reason"] = reason
    if reason:
        status["locked_at"] = str(status.get("locked_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    else:
        status["locked_at"] = ""


def _account_candidates(proto: str, username: str) -> list[Path]:
    return [
        ACCOUNT_ROOT / proto / f"{username}@{proto}.txt",
        ACCOUNT_ROOT / proto / f"{username}.txt",
    ]


def _quota_candidates(proto: str, username: str) -> list[Path]:
    return [
        QUOTA_ROOT / proto / f"{username}@{proto}.json",
        QUOTA_ROOT / proto / f"{username}.json",
    ]


def _resolve_existing(candidates: list[Path]) -> Path | None:
    for p in candidates:
        if p.exists():
            return p
    return None


def _is_valid_ssh_username(username: str) -> bool:
    return bool(SSH_USERNAME_RE.match(username or ""))


def _linux_user_exists(username: str) -> bool:
    try:
        pwd.getpwnam(str(username or "").strip())
        return True
    except KeyError:
        return False
    except Exception:
        return False


def _ssh_password_output(password_raw: str) -> str:
    return str(password_raw or "-")


def _ssh_password_from_account_info(username: str) -> str:
    account_file = _resolve_existing(_account_candidates(SSH_PROTOCOL, username))
    if account_file is None:
        return "-"
    fields = _read_account_fields(account_file)
    password = str(fields.get("Password") or "").strip()
    return password or "-"


def _ssh_previous_password(username: str) -> str:
    password = _zivpn_password_read(username)
    if password and password != "-":
        return password
    return _ssh_password_from_account_info(username)


def _ssh_collect_existing_tokens(state_dir: Path, current_path: Path | None = None) -> set[str]:
    tokens: set[str] = set()
    current_real = current_path.resolve() if current_path and current_path.exists() else None
    try:
        candidates = sorted(state_dir.glob("*.json"))
    except Exception:
        return tokens
    for candidate in candidates:
        try:
            if current_real is not None and candidate.resolve() == current_real:
                continue
        except Exception:
            pass
        ok, payload = _read_json(candidate)
        if not ok or not isinstance(payload, dict):
            continue
        token = str(payload.get("sshws_token") or "").strip().lower()
        if re.fullmatch(r"[a-f0-9]{10}", token or ""):
            tokens.add(token)
    return tokens


def _ssh_ensure_state_token(payload: dict[str, Any], state_path: Path | None = None) -> str:
    candidate = str(payload.get("sshws_token") or "").strip().lower()
    state_dir = state_path.parent if state_path is not None else SSH_QUOTA_DIR
    used = _ssh_collect_existing_tokens(state_dir, current_path=state_path)
    if re.fullmatch(r"[a-f0-9]{10}", candidate or "") and candidate not in used:
        return candidate
    for _ in range(128):
        token = secrets.token_hex(5)
        if token not in used:
            return token
    raise RuntimeError("Gagal membuat sshws_token unik.")


def _ssh_ws_public_ports_label() -> str:
    return "443 & 80"


def _ssh_direct_public_ports_label() -> str:
    return "443 & 80"


def _ssh_ssl_tls_public_ports_label() -> str:
    return "443 & 80"


def _badvpn_public_port_label() -> str:
    return "7300, 7400, 7500, 7600, 7700, 7800, 7900"


def _ssh_normalize_state_payload(
    username: str,
    payload: dict[str, Any] | None = None,
    *,
    created_at: str = "",
    expired_at: str = "",
    state_path: Path | None = None,
) -> dict[str, Any]:
    existing = payload if isinstance(payload, dict) else {}
    status_raw = existing.get("status") if isinstance(existing.get("status"), dict) else {}
    quota_limit = max(0, _to_int(existing.get("quota_limit"), 0))
    quota_used = max(0, _to_int(existing.get("quota_used"), 0))
    quota_unit = str(existing.get("quota_unit") or "binary").strip().lower()
    if quota_unit not in {"binary", "decimal"}:
        quota_unit = "binary"

    return {
        "managed_by": "autoscript-manage",
        "username": str(username or "").strip(),
        "protocol": SSH_PROTOCOL,
        "created_at": str(created_at or existing.get("created_at") or "").strip()
        or datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "expired_at": (str(expired_at or existing.get("expired_at") or "-").strip() or "-")[:10],
        "quota_limit": quota_limit,
        "quota_unit": quota_unit,
        "quota_used": quota_used,
        "sshws_token": _ssh_ensure_state_token(existing, state_path=state_path),
        "status": {
            "manual_block": bool(status_raw.get("manual_block")),
            "quota_exhausted": bool(status_raw.get("quota_exhausted")),
            "ip_limit_enabled": bool(status_raw.get("ip_limit_enabled")),
            "ip_limit": max(0, _to_int(status_raw.get("ip_limit"), 0)),
            "ip_limit_locked": bool(status_raw.get("ip_limit_locked")),
            "speed_limit_enabled": bool(status_raw.get("speed_limit_enabled")),
            "speed_down_mbit": max(0.0, _to_float(status_raw.get("speed_down_mbit"), 0.0)),
            "speed_up_mbit": max(0.0, _to_float(status_raw.get("speed_up_mbit"), 0.0)),
            "lock_reason": str(status_raw.get("lock_reason") or "").strip().lower(),
            "locked_at": str(status_raw.get("locked_at") or "").strip(),
            "account_locked": bool(status_raw.get("account_locked")),
            "lock_owner": str(status_raw.get("lock_owner") or "").strip(),
            "lock_shell_restore": str(status_raw.get("lock_shell_restore") or "").strip(),
        },
    }


def _ssh_load_state(
    username: str,
    *,
    create_missing: bool = False,
    created_at: str = "",
    expired_at: str = "",
) -> tuple[bool, Path | str, dict[str, Any] | str]:
    target = _resolve_existing(_quota_candidates(SSH_PROTOCOL, username))
    if target is None:
        if not create_missing:
            return False, f"File quota tidak ditemukan untuk {username} [{SSH_PROTOCOL}]", ""
        target = SSH_QUOTA_DIR / f"{username}@{SSH_PROTOCOL}.json"
        payload: dict[str, Any] = {}
    else:
        ok, raw = _read_json(target)
        if not ok:
            return False, str(raw), ""
        if not isinstance(raw, dict):
            return False, f"Format quota tidak valid: {target}", ""
        payload = raw

    normalized = _ssh_normalize_state_payload(
        username,
        payload,
        created_at=created_at,
        expired_at=expired_at,
        state_path=target,
    )
    return True, target, normalized


def _ssh_save_state(path: Path, payload: dict[str, Any]) -> None:
    normalized = _ssh_normalize_state_payload(
        str(payload.get("username") or ""),
        payload,
        created_at=str(payload.get("created_at") or ""),
        expired_at=str(payload.get("expired_at") or ""),
        state_path=path,
    )
    _write_json_atomic(path, normalized)
    _chmod_600(path)


def _ssh_quota_limit_display(quota_bytes: int) -> str:
    if quota_bytes <= 0:
        return "0 GB"
    return f"{_fmt_number(quota_bytes / (1024**3))} GB"


def _ssh_expired_display(expired_at: str) -> str:
    value = str(expired_at or "").strip()[:10]
    if not value or value == "-":
        return "unlimited"
    try:
        expiry = datetime.strptime(value, "%Y-%m-%d").date()
        days = max(0, (expiry - datetime.now(timezone.utc).date()).days)
        return f"{days} days"
    except Exception:
        return "unknown"


def _ssh_ip_limit_display(enabled: bool, limit: int) -> str:
    if not enabled:
        return "OFF"
    if limit > 0:
        return f"ON ({limit})"
    return "ON"


def _ssh_speed_limit_display(enabled: bool, down: float, up: float) -> str:
    if not enabled:
        return "OFF"
    return f"ON (DOWN {_fmt_number(down)} Mbps | UP {_fmt_number(up)} Mbps)"


def _ssh_write_account_info(
    username: str,
    *,
    password: str,
    quota_payload: dict[str, Any],
) -> tuple[bool, str]:
    status = quota_payload.get("status") if isinstance(quota_payload.get("status"), dict) else {}
    account_file = SSH_ACCOUNT_DIR / f"{username}@{SSH_PROTOCOL}.txt"
    created_at = str(quota_payload.get("created_at") or "").strip() or datetime.utcnow().strftime("%Y-%m-%d %H:%M")
    created_disp = _normalize_created_display(created_at, date_only=True)
    expired_at = str(quota_payload.get("expired_at") or "-").strip()[:10] or "-"
    quota_limit = max(0, _to_int(quota_payload.get("quota_limit"), 0))
    ip_enabled = bool(status.get("ip_limit_enabled"))
    ip_limit = max(0, _to_int(status.get("ip_limit"), 0))
    speed_enabled = bool(status.get("speed_limit_enabled"))
    speed_down = max(0.0, _to_float(status.get("speed_down_mbit"), 0.0))
    speed_up = max(0.0, _to_float(status.get("speed_up_mbit"), 0.0))
    sshws_token = str(quota_payload.get("sshws_token") or "").strip().lower()
    if re.fullmatch(r"[a-f0-9]{10}", sshws_token or ""):
        sshws_path = f"/{sshws_token}"
        sshws_alt_path = _path_alt_placeholder(sshws_path)
        sshws_main = sshws_path
    else:
        sshws_alt_path = "-"
        sshws_main = "-"
    domain = _detect_domain() or "-"
    ok_ip, public_ip = _get_public_ipv4()
    ip = (public_ip if ok_ip else (_detect_public_ipv4() or "-")).strip() or "-"
    isp, country = _geo_lookup(ip)

    running_label_width = 16
    lines = [
        "=== SSH ACCOUNT INFO ===",
        f"Domain      : {domain}",
        f"IP          : {ip}",
        f"ISP         : {isp}",
        f"Country     : {country}",
        f"Username    : {username}",
        f"Password    : {_ssh_password_output(password)}",
        f"Quota Limit : {_ssh_quota_limit_display(quota_limit)}",
        f"Expired     : {_ssh_expired_display(expired_at)}",
        f"Valid Until : {expired_at}",
        f"Created     : {created_disp}",
        f"IP Limit    : {_ssh_ip_limit_display(ip_enabled, ip_limit)}",
        f"Speed Limit : {_ssh_speed_limit_display(speed_enabled, speed_down, speed_up)}",
        "",
        "=== RUNNING ON PORT ===",
        f"{'SSH WS Path':<{running_label_width}} : {sshws_main}",
        f"{'SSH WS Path Alt':<{running_label_width}} : {sshws_alt_path}",
        f"{'SSH WS Port':<{running_label_width}} : {_ssh_ws_public_ports_label()}",
        f"{'SSH Direct Port':<{running_label_width}} : {_ssh_direct_public_ports_label()}",
        f"{'SSH SSL/TLS Port':<{running_label_width}} : {_ssh_ssl_tls_public_ports_label()}",
        f"{'BadVPN UDPGW':<{running_label_width}} : {_badvpn_public_port_label()}",
    ]
    if _zivpn_account_info_enabled():
        zivpn_password_state = "same as SSH password" if _zivpn_user_password_synced(username) else "not synced to runtime"
        lines.extend(
            [
                "",
                "=== ZIVPN UDP ===",
                f"{'ZIVPN Password':<{running_label_width}} : {zivpn_password_state}",
            ]
        )
    lines.extend(
        [
            "",
            "=== STANDARD PAYLOAD ===",
            "Payload WS:",
            f"    GET {sshws_alt_path} HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]",
            "",
            "Payload WSS:",
            f"    GET wss://[host]{sshws_alt_path} HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]",
        ]
    )
    content = "\n".join(lines) + "\n"
    try:
        _write_text_atomic(account_file, content)
        _chmod_600(account_file)
        return True, str(account_file)
    except Exception as exc:
        return False, f"Gagal menulis SSH account info: {exc}"


def _ssh_refresh_account_info(username: str, password_override: str = "") -> tuple[bool, str]:
    ok_state, state_path_or_err, payload_or_err = _ssh_load_state(username)
    if not ok_state:
        return False, str(state_path_or_err)
    state_path = state_path_or_err
    quota_payload = payload_or_err
    assert isinstance(state_path, Path)
    assert isinstance(quota_payload, dict)
    try:
        _ssh_save_state(state_path, quota_payload)
    except Exception as exc:
        return False, f"Gagal menyimpan state SSH: {exc}"
    password = str(password_override or "").strip() or _ssh_password_from_account_info(username)
    return _ssh_write_account_info(username, password=password, quota_payload=quota_payload)


def _ssh_run_enforcer(*, username: str = "", require_available: bool = False) -> tuple[bool, str]:
    if not SSHWS_QAC_ENFORCER_BIN.exists():
        if require_available:
            return False, "sshws-qac-enforcer tidak tersedia"
        return True, "skip: sshws-qac-enforcer tidak tersedia"
    args = [str(SSHWS_QAC_ENFORCER_BIN), "--once"]
    target_user = str(username or "").strip()
    if target_user:
        args.extend(["--user", target_user])
    ok, out = _run_cmd(args, timeout=20)
    if ok:
        return True, "ok"
    return False, out


def _ssh_post_update_warnings(username: str, password_override: str = "") -> list[str]:
    warnings: list[str] = []
    ok_enforce, enforce_msg = _ssh_run_enforcer(username=username)
    if not ok_enforce:
        warnings.append(f"enforcer: {enforce_msg}")
    ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=password_override)
    if not ok_refresh:
        warnings.append(f"account-info: {refresh_msg}")
    return warnings


def _ssh_apply_state_update(
    username: str,
    path: Path,
    previous_payload: dict[str, Any],
    next_payload: dict[str, Any],
    *,
    password_override: str = "",
    require_enforcer: bool = False,
    require_account_info: bool = False,
) -> tuple[bool, list[str], str]:
    try:
        _ssh_save_state(path, next_payload)
    except Exception as exc:
        return False, [], f"Gagal menyimpan state SSH: {exc}"

    if not require_enforcer and not require_account_info:
        return True, _ssh_post_update_warnings(username, password_override=password_override), ""

    if not require_enforcer:
        ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=password_override)
        if ok_refresh:
            return True, [], ""
        rollback_notes: list[str] = []
        try:
            _ssh_save_state(path, previous_payload)
        except Exception as exc:
            rollback_notes.append(f"rollback-state: {exc}")
        else:
            ok_rollback_refresh, rollback_refresh_msg = _ssh_refresh_account_info(
                username,
                password_override=password_override,
            )
            if not ok_rollback_refresh:
                rollback_notes.append(f"rollback-account-info: {rollback_refresh_msg}")

        detail = f"account-info: {refresh_msg}"
        if rollback_notes:
            detail += " | " + " | ".join(rollback_notes)
        else:
            detail += " | state di-rollback"
        return False, [], detail

    ok_enforce, enforce_msg = _ssh_run_enforcer(username=username, require_available=True)
    if ok_enforce:
        ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=password_override)
        if ok_refresh:
            return True, [], ""

        rollback_notes: list[str] = []
        try:
            _ssh_save_state(path, previous_payload)
        except Exception as exc:
            rollback_notes.append(f"rollback-state: {exc}")
        else:
            ok_rollback_enforce, rollback_enforce_msg = _ssh_run_enforcer(
                username=username,
                require_available=True,
            )
            if not ok_rollback_enforce:
                rollback_notes.append(f"rollback-enforcer: {rollback_enforce_msg}")
            ok_rollback_refresh, rollback_refresh_msg = _ssh_refresh_account_info(
                username,
                password_override=password_override,
            )
            if not ok_rollback_refresh:
                rollback_notes.append(f"rollback-account-info: {rollback_refresh_msg}")

        detail = f"account-info: {refresh_msg}"
        if rollback_notes:
            detail += " | " + " | ".join(rollback_notes)
        else:
            detail += " | state di-rollback"
        return False, [], detail

    rollback_notes: list[str] = []
    try:
        _ssh_save_state(path, previous_payload)
    except Exception as exc:
        rollback_notes.append(f"rollback-state: {exc}")
    else:
        ok_rollback_enforce, rollback_enforce_msg = _ssh_run_enforcer(
            username=username,
            require_available=True,
        )
        if not ok_rollback_enforce:
            rollback_notes.append(f"rollback-enforcer: {rollback_enforce_msg}")
        ok_rollback_refresh, rollback_refresh_msg = _ssh_refresh_account_info(
            username,
            password_override=password_override,
        )
        if not ok_rollback_refresh:
            rollback_notes.append(f"rollback-account-info: {rollback_refresh_msg}")

    detail = f"enforcer: {enforce_msg}"
    if rollback_notes:
        detail += " | " + " | ".join(rollback_notes)
    else:
        detail += " | state di-rollback"
    return False, [], detail


def _ssh_restore_linux_password(username: str, password: str) -> tuple[bool, str]:
    return _run_cmd(
        ["bash", "-lc", 'printf "%s:%s\\n" "$0" "$1" | chpasswd', username, password],
        timeout=20,
    )


def _ssh_delete_linux_user(username: str) -> tuple[bool, str]:
    if not _linux_user_exists(username):
        return True, "skip"
    ok_del, out_del = _run_cmd(["userdel", "-r", username], timeout=20)
    if ok_del or not _linux_user_exists(username):
        return True, out_del
    ok_del2, out_del2 = _run_cmd(["userdel", username], timeout=20)
    if ok_del2 or not _linux_user_exists(username):
        return True, out_del2
    return False, out_del2


def _ssh_password_reset_rollback(username: str, previous_password: str) -> tuple[bool, str]:
    previous = str(previous_password or "").strip()
    if not previous or previous == "-":
        return False, "password lama tidak tersedia untuk rollback"
    ok_restore, restore_msg = _ssh_restore_linux_password(username, previous)
    if not ok_restore:
        return False, f"rollback Linux password gagal: {restore_msg}"
    rollback_notes: list[str] = []
    ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=previous)
    if not ok_refresh:
        rollback_notes.append(f"account info rollback gagal: {refresh_msg}")
    ok_zivpn, zivpn_msg = _zivpn_sync_user_password(username, previous)
    if not ok_zivpn:
        rollback_notes.append(f"rollback ZIVPN gagal: {zivpn_msg}")
    if rollback_notes:
        return False, "password Linux dipulihkan, tetapi " + " | ".join(rollback_notes)
    return True, "ok"


def _ssh_delete_zivpn_rollback(username: str, previous_password: str) -> tuple[bool, str]:
    previous = str(previous_password or "").strip()
    if not previous or previous == "-":
        return False, "password lama tidak tersedia untuk rollback ZIVPN"
    return _zivpn_sync_user_password(username, previous)


def _ssh_add_user_rollback(
    username: str,
    quota_path: Path | None,
    account_path: Path,
    *,
    raw_password: str,
    error_prefix: str,
    cleanup_zivpn: bool,
) -> tuple[bool, str, str]:
    title = "User Management - Add User"
    if cleanup_zivpn:
        ok_cleanup, cleanup_msg = _zivpn_remove_user_password(username)
        if not ok_cleanup:
            return (
                False,
                title,
                (
                    f"{error_prefix}\n"
                    f"- Rollback ZIVPN gagal: {cleanup_msg}\n"
                    f"- Akun dipertahankan agar bisa dipulihkan/manual cleanup"
                ),
            )

    ok_del, del_msg = _ssh_delete_linux_user(username)
    if not ok_del:
        rollback_note = ""
        if cleanup_zivpn:
            ok_restore, restore_msg = _zivpn_sync_user_password(username, raw_password)
            rollback_note = (
                f"\n- Rollback ZIVPN: {restore_msg}"
                if ok_restore
                else f"\n- Rollback ZIVPN gagal: {restore_msg}"
            )
        return (
            False,
            title,
            (
                f"{error_prefix}\n"
                f"- Rollback user Linux gagal: {del_msg}\n"
                f"- Akun dipertahankan agar bisa dipulihkan/manual cleanup"
                f"{rollback_note}"
            ),
        )

    for path in (quota_path, account_path):
        if path is None:
            continue
        try:
            path.unlink(missing_ok=True)
        except Exception as exc:
            error_prefix += f"\n- Cleanup artefak gagal: {path} ({exc})"
            continue
        if path.exists() or path.is_symlink():
            error_prefix += f"\n- Cleanup artefak gagal: {path} masih ada"
    return False, title, error_prefix


def _ssh_apply_linux_expiry(username: str, expiry: str) -> tuple[bool, str]:
    expiry_n = str(expiry or "").strip()
    if not expiry_n or expiry_n == "-":
        return _run_cmd(["chage", "-E", "-1", username], timeout=20)
    return _run_cmd(["chage", "-E", expiry_n, username], timeout=20)


def _ssh_expiry_update_rollback(
    username: str,
    previous_expiry: str,
    quota_path: Path,
    previous_payload: dict[str, Any],
) -> tuple[bool, str]:
    notes: list[str] = []
    ok_expiry, expiry_msg = _ssh_apply_linux_expiry(username, previous_expiry)
    if not ok_expiry:
        notes.append(f"rollback-expiry: {expiry_msg}")
    try:
        _ssh_save_state(quota_path, previous_payload)
    except Exception as exc:
        notes.append(f"rollback-state: {exc}")
    ok_refresh, refresh_msg = _ssh_refresh_account_info(username)
    if not ok_refresh:
        notes.append(f"rollback-account-info: {refresh_msg}")
    if notes:
        return False, " | ".join(notes)
    return True, "ok"


def _load_quota(proto: str, username: str) -> tuple[bool, Path | str, dict[str, Any] | str]:
    target = _resolve_existing(_quota_candidates(proto, username))
    if target is None:
        return False, f"File quota tidak ditemukan untuk {username} [{proto}]", ""
    ok, payload = _read_json(target)
    if not ok:
        return False, str(payload), ""
    if not isinstance(payload, dict):
        return False, f"Format quota tidak valid: {target}", ""
    return True, target, payload


def _save_quota(path: Path, payload: dict[str, Any]) -> None:
    _write_json_atomic(path, payload)
    _chmod_600(path)


def _extract_username_from_file_name(path: Path, proto: str) -> str:
    stem = path.stem
    suffix = f"@{proto}"
    if stem.endswith(suffix):
        return stem[: -len(suffix)]
    return stem


def _username_exists_anywhere(username: str) -> tuple[bool, str]:
    needle = username.strip().lower()

    for proto in USER_PROTOCOLS:
        acc_dir = ACCOUNT_ROOT / proto
        if acc_dir.exists():
            for p in acc_dir.glob("*.txt"):
                if _extract_username_from_file_name(p, proto).lower() == needle:
                    return True, f"account:{proto}:{p.name}"
        q_dir = QUOTA_ROOT / proto
        if q_dir.exists():
            for p in q_dir.glob("*.json"):
                if _extract_username_from_file_name(p, proto).lower() == needle:
                    return True, f"quota:{proto}:{p.name}"

    ok, payload = _read_json(XRAY_INBOUNDS_CONF)
    if ok and isinstance(payload, dict):
        inbounds = payload.get("inbounds", [])
        if isinstance(inbounds, list):
            for ib in inbounds:
                if not isinstance(ib, dict):
                    continue
                proto = str(ib.get("protocol") or "")
                settings = ib.get("settings") or {}
                clients = settings.get("clients") if isinstance(settings, dict) else []
                if not isinstance(clients, list):
                    continue
                for c in clients:
                    if not isinstance(c, dict):
                        continue
                    email = str(c.get("email") or "").lower().strip()
                    user_part, _, proto_part = email.partition("@")
                    if user_part == needle and proto_part in PROTOCOLS:
                        return True, f"xray:{proto_part}:{email}"
    if _linux_user_exists(needle):
        return True, f"linux:{needle}"
    return False, ""


def _inbound_matches_proto(ib: Any, proto: str) -> bool:
    if not isinstance(ib, dict):
        return False
    ib_proto = str(ib.get("protocol") or "").strip().lower()
    return proto in {"vless", "vmess", "trojan"} and ib_proto == proto


def _generate_credential(proto: str) -> str:
    if proto == "trojan":
        return secrets.token_hex(16)
    return str(uuid.uuid4())


def _xray_add_client(proto: str, username: str, cred: str) -> tuple[bool, str]:
    if not XRAY_INBOUNDS_CONF.exists():
        return False, f"Config tidak ditemukan: {XRAY_INBOUNDS_CONF}"

    email = _email(proto, username)
    with file_lock(ROUTING_LOCK_FILE):
        ok, payload = _read_json(XRAY_INBOUNDS_CONF)
        if not ok:
            return False, str(payload)
        if not isinstance(payload, dict):
            return False, "Format inbounds tidak valid"

        original = json.loads(json.dumps(payload))
        inbounds = payload.get("inbounds")
        if not isinstance(inbounds, list):
            return False, "Format inbounds tidak valid: inbounds bukan list"

        for ib in inbounds:
            if not isinstance(ib, dict):
                continue
            if not _inbound_matches_proto(ib, proto):
                continue
            settings = ib.get("settings") or {}
            clients = settings.get("clients")
            if isinstance(clients, list):
                for c in clients:
                    if isinstance(c, dict) and str(c.get("email") or "") == email:
                        return False, f"User sudah ada di config: {email}"

        if proto == "vless":
            client = {"id": cred, "email": email}
        elif proto == "vmess":
            client = {"id": cred, "alterId": 0, "email": email}
        elif proto == "trojan":
            client = {"password": cred, "email": email}
        elif proto != "trojan":
            return False, f"Protocol tidak didukung: {proto}"
        else:
            client = {"password": cred, "email": email}

        updated = False
        for ib in inbounds:
            if not isinstance(ib, dict):
                continue
            if not _inbound_matches_proto(ib, proto):
                continue
            settings = ib.setdefault("settings", {})
            clients = settings.get("clients")
            if clients is None:
                settings["clients"] = []
                clients = settings["clients"]
            if not isinstance(clients, list):
                continue
            clients.append(client)
            updated = True

        if not updated:
            return False, f"Inbound protocol {proto} tidak ditemukan"

        try:
            _write_json_atomic(XRAY_INBOUNDS_CONF, payload)
            if not _restart_and_wait("xray", timeout_sec=20):
                _write_json_atomic(XRAY_INBOUNDS_CONF, original)
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah add user (rollback)."
        except Exception as exc:
            try:
                _write_json_atomic(XRAY_INBOUNDS_CONF, original)
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal update inbounds: {exc}"

    return True, "ok"


def _xray_delete_client(proto: str, username: str) -> tuple[bool, str]:
    if not XRAY_INBOUNDS_CONF.exists():
        return False, f"Config tidak ditemukan: {XRAY_INBOUNDS_CONF}"
    if not XRAY_ROUTING_CONF.exists():
        return False, f"Config tidak ditemukan: {XRAY_ROUTING_CONF}"

    email = _email(proto, username)
    with file_lock(ROUTING_LOCK_FILE):
        ok_inb, inb_payload = _read_json(XRAY_INBOUNDS_CONF)
        if not ok_inb:
            return False, str(inb_payload)
        ok_rt, rt_payload = _read_json(XRAY_ROUTING_CONF)
        if not ok_rt:
            return False, str(rt_payload)
        if not isinstance(inb_payload, dict) or not isinstance(rt_payload, dict):
            return False, "Format config Xray tidak valid"

        inb_original = json.loads(json.dumps(inb_payload))
        rt_original = json.loads(json.dumps(rt_payload))

        inbounds = inb_payload.get("inbounds")
        if not isinstance(inbounds, list):
            return False, "Format inbounds tidak valid"

        removed = 0
        for ib in inbounds:
            if not isinstance(ib, dict):
                continue
            if not _inbound_matches_proto(ib, proto):
                continue
            settings = ib.get("settings") or {}
            clients = settings.get("clients")
            if not isinstance(clients, list):
                continue
            before = len(clients)
            settings["clients"] = [c for c in clients if not (isinstance(c, dict) and str(c.get("email") or "") == email)]
            removed += before - len(settings["clients"])
            ib["settings"] = settings

        if removed == 0:
            return False, f"User tidak ditemukan di inbounds: {email}"

        routing = rt_payload.get("routing") or {}
        rules = routing.get("rules") if isinstance(routing, dict) else None
        if isinstance(rules, list):
            markers = {"dummy-block-user", "dummy-quota-user", "dummy-limit-user", "dummy-warp-user", "dummy-direct-user"}
            for rule in rules:
                if not isinstance(rule, dict):
                    continue
                users = rule.get("user")
                if not isinstance(users, list):
                    continue
                has_marker = any(u in markers for u in users)
                if not has_marker:
                    has_marker = any(isinstance(u, str) and u.startswith(SPEED_RULE_MARKER_PREFIX) for u in users)
                if not has_marker:
                    continue
                rule["user"] = [u for u in users if u != email]
            routing["rules"] = rules
            rt_payload["routing"] = routing

        try:
            _write_json_atomic(XRAY_INBOUNDS_CONF, inb_payload)
            _write_json_atomic(XRAY_ROUTING_CONF, rt_payload)
            if not _restart_and_wait("xray", timeout_sec=20):
                _write_json_atomic(XRAY_INBOUNDS_CONF, inb_original)
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah delete user (rollback)."
        except Exception as exc:
            try:
                _write_json_atomic(XRAY_INBOUNDS_CONF, inb_original)
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal update config saat delete user: {exc}"

    return True, "ok"


def _routing_set_user_in_marker(marker: str, email: str, state: str, outbound_tag: str = "blocked") -> tuple[bool, str]:
    if state not in {"on", "off"}:
        return False, "state harus on/off"
    if not XRAY_ROUTING_CONF.exists():
        return False, f"Config routing tidak ditemukan: {XRAY_ROUTING_CONF}"

    with file_lock(ROUTING_LOCK_FILE):
        ok, payload = _read_json(XRAY_ROUTING_CONF)
        if not ok:
            return False, str(payload)
        if not isinstance(payload, dict):
            return False, "Format routing tidak valid"

        original = json.loads(json.dumps(payload))
        routing = payload.get("routing") or {}
        rules = routing.get("rules") if isinstance(routing, dict) else None
        if not isinstance(rules, list):
            return False, "Format routing.rules tidak valid"

        target = None
        for rule in rules:
            if not isinstance(rule, dict):
                continue
            if rule.get("type") != "field":
                continue
            if rule.get("outboundTag") != outbound_tag:
                continue
            users = rule.get("user")
            if not isinstance(users, list):
                continue
            if marker in users:
                target = rule
                break

        if target is None:
            return False, f"Marker {marker} pada outboundTag={outbound_tag} tidak ditemukan"

        users = target.get("user") or []
        if not isinstance(users, list):
            users = []

        if marker not in users:
            users.insert(0, marker)
        else:
            users = [marker] + [u for u in users if u != marker]

        changed = False
        if state == "on":
            if email not in users:
                users.append(email)
                changed = True
        else:
            new_users = [u for u in users if u != email]
            if new_users != users:
                users = new_users
                changed = True

        if not changed:
            return True, "noop"

        target["user"] = users
        routing["rules"] = rules
        payload["routing"] = routing

        try:
            _write_json_atomic(XRAY_ROUTING_CONF, payload)
            if not _restart_and_wait("xray", timeout_sec=20):
                _write_json_atomic(XRAY_ROUTING_CONF, original)
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah update routing marker (rollback)."
        except Exception as exc:
            try:
                _write_json_atomic(XRAY_ROUTING_CONF, original)
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal update routing marker: {exc}"

    return True, "ok"


def _is_speed_outbound_tag(tag: str) -> bool:
    return bool(tag) and tag.startswith(SPEED_OUTBOUND_TAG_PREFIX)


def _routing_default_rule_index(rules: list[Any]) -> int:
    idx = -1
    for i, rule in enumerate(rules):
        if not isinstance(rule, dict):
            continue
        if rule.get("type") != "field":
            continue
        port = str(rule.get("port") or "").strip()
        if port not in DEFAULT_EGRESS_PORTS:
            continue
        if rule.get("user") or rule.get("domain") or rule.get("ip") or rule.get("protocol"):
            continue
        idx = i
    return idx


def _outbound_tags_from_cfg(out_cfg: dict[str, Any]) -> list[str]:
    tags: list[str] = []
    seen: set[str] = set()
    outbounds = out_cfg.get("outbounds")
    if not isinstance(outbounds, list):
        return tags
    for item in outbounds:
        if not isinstance(item, dict):
            continue
        tag = str(item.get("tag") or "").strip()
        if not tag or tag in seen:
            continue
        seen.add(tag)
        tags.append(tag)
    return tags


def _routing_set_default_warp_global_mode(rt_cfg: dict[str, Any], out_cfg: dict[str, Any], mode: str) -> tuple[bool, str]:
    mode_n = str(mode or "").strip().lower()
    if mode_n not in {"direct", "warp"}:
        return False, "Mode WARP global harus direct/warp."

    routing = rt_cfg.get("routing")
    if not isinstance(routing, dict):
        routing = {}
    rules = routing.get("rules")
    if not isinstance(rules, list):
        return False, "Invalid routing config: routing.rules bukan list"

    idx = _routing_default_rule_index(rules)
    if idx < 0:
        return False, "Default rule (port 1-65535 / 0-65535) tidak ditemukan."

    outbound_tags = _outbound_tags_from_cfg(out_cfg)
    if mode_n in {"direct", "warp"} and mode_n not in set(outbound_tags):
        return False, f"Outbound '{mode_n}' tidak ditemukan pada 20-outbounds.json."

    target = rules[idx]
    if not isinstance(target, dict):
        return False, "Default rule tidak valid."

    if mode_n in {"direct", "warp"}:
        target["outboundTag"] = mode_n
    rules[idx] = target
    routing["rules"] = rules
    rt_cfg["routing"] = routing
    return True, f"WARP global di-set ke {mode_n}."


def _apply_routing_transaction(
    mutator: Any,
) -> tuple[bool, str]:
    if not XRAY_ROUTING_CONF.exists():
        return False, f"Config routing tidak ditemukan: {XRAY_ROUTING_CONF}"
    if not XRAY_OUTBOUNDS_CONF.exists():
        return False, f"Config outbounds tidak ditemukan: {XRAY_OUTBOUNDS_CONF}"

    with file_lock(ROUTING_LOCK_FILE):
        ok_rt, rt_cfg = _read_json(XRAY_ROUTING_CONF)
        if not ok_rt:
            return False, str(rt_cfg)
        ok_out, out_cfg = _read_json(XRAY_OUTBOUNDS_CONF)
        if not ok_out:
            return False, str(out_cfg)
        if not isinstance(rt_cfg, dict) or not isinstance(out_cfg, dict):
            return False, "Format config Xray tidak valid."

        rt_original = json.loads(json.dumps(rt_cfg))
        try:
            ok_mut, msg_mut = mutator(rt_cfg, out_cfg)
            if not ok_mut:
                return False, str(msg_mut)
            _write_json_atomic(XRAY_ROUTING_CONF, rt_cfg)
            if not _restart_and_wait("xray", timeout_sec=20):
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah update network controls (rollback)."
            return True, str(msg_mut)
        except Exception as exc:
            try:
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal update routing network controls: {exc}"


def _normalize_dns_root(cfg: Any) -> dict[str, Any]:
    if not isinstance(cfg, dict):
        cfg = {}
    dns_obj = cfg.get("dns")
    if not isinstance(dns_obj, dict):
        dns_obj = {}
    cfg["dns"] = dns_obj
    return cfg


def _dns_servers_list(cfg: dict[str, Any]) -> list[Any]:
    dns_obj = cfg.get("dns")
    if not isinstance(dns_obj, dict):
        dns_obj = {}
        cfg["dns"] = dns_obj
    servers = dns_obj.get("servers")
    if not isinstance(servers, list):
        servers = []
    dns_obj["servers"] = servers
    return servers


def _dns_set_server_idx(cfg: dict[str, Any], idx: int, value: str) -> None:
    val = str(value or "").strip()
    if not val:
        return
    servers = _dns_servers_list(cfg)
    while len(servers) <= idx:
        servers.append("")
    if isinstance(servers[idx], dict):
        servers[idx]["address"] = val
    else:
        servers[idx] = val


def _is_valid_port_text(port_text: str) -> bool:
    if not port_text.isdigit():
        return False
    try:
        port = int(port_text)
    except Exception:
        return False
    return 1 <= port <= 65535


def _is_valid_dns_host(value: str) -> bool:
    host = str(value or "").strip().lower().strip(".")
    if not host:
        return False
    if host == "localhost":
        return True
    try:
        ipaddress.ip_address(host)
        return True
    except Exception:
        pass
    return bool(DOMAIN_RE.match(host))


def _is_valid_dns_server_value(value: str) -> bool:
    val = str(value or "").strip()
    if not val:
        return False

    # Plain IP/FQDN.
    if _is_valid_dns_host(val):
        return True

    # IPv4 with explicit port.
    if ":" in val and val.count(":") == 1:
        host, port_text = val.rsplit(":", 1)
        if _is_valid_port_text(port_text) and _is_valid_dns_host(host):
            return True

    # Bracketed IPv6 with explicit port.
    m = re.match(r"^\[(.+)\]:(\d{1,5})$", val)
    if m:
        host = m.group(1)
        port_text = m.group(2)
        if _is_valid_port_text(port_text):
            try:
                ipaddress.ip_address(host)
                return True
            except Exception:
                return False

    # URI form (for DoH/DoT style values), e.g. https://dns.google/dns-query.
    parsed = urllib.parse.urlparse(val)
    if parsed.scheme and parsed.hostname and _is_valid_dns_host(str(parsed.hostname)):
        return True

    return False


def _apply_dns_transaction(mutator: Any) -> tuple[bool, str]:
    with file_lock(DNS_LOCK_FILE):
        existed_before = XRAY_DNS_CONF.exists()
        raw_snapshot: bytes | None = None
        raw_mode: int | None = None
        if existed_before:
            try:
                raw_snapshot = XRAY_DNS_CONF.read_bytes()
                raw_mode = int(XRAY_DNS_CONF.stat().st_mode & 0o777)
            except Exception as exc:
                return False, f"Gagal membaca snapshot DNS asli: {exc}"

        cfg_original: dict[str, Any]
        if XRAY_DNS_CONF.exists():
            ok_read, raw_cfg = _read_json(XRAY_DNS_CONF)
            if not ok_read:
                return False, f"Config DNS tidak valid:\n{raw_cfg}"
            cfg_original = raw_cfg if isinstance(raw_cfg, dict) else {}
        else:
            cfg_original = {"dns": {}}

        cfg_work = json.loads(json.dumps(cfg_original))
        cfg_work = _normalize_dns_root(cfg_work)

        def restore_raw_snapshot() -> None:
            if existed_before:
                XRAY_DNS_CONF.parent.mkdir(parents=True, exist_ok=True)
                tmp = XRAY_DNS_CONF.parent / f".{XRAY_DNS_CONF.name}.rollback.{uuid.uuid4().hex}.tmp"
                tmp.write_bytes(raw_snapshot or b"")
                os.chmod(tmp, raw_mode if raw_mode is not None else 0o600)
                os.replace(tmp, XRAY_DNS_CONF)
                if raw_mode is not None:
                    os.chmod(XRAY_DNS_CONF, raw_mode)
                else:
                    _chmod_600(XRAY_DNS_CONF)
            else:
                try:
                    XRAY_DNS_CONF.unlink()
                except FileNotFoundError:
                    pass

        try:
            ok_mut, msg_mut = mutator(cfg_work)
            if not ok_mut:
                return False, str(msg_mut)

            _write_json_atomic(XRAY_DNS_CONF, cfg_work)
            if not _restart_and_wait("xray", timeout_sec=20):
                restore_raw_snapshot()
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah update DNS (rollback)."
            return True, str(msg_mut)
        except Exception as exc:
            try:
                restore_raw_snapshot()
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal update DNS: {exc}"


def _dns_set_primary(cfg: dict[str, Any], value: str) -> tuple[bool, str]:
    val = str(value or "").strip()
    if not val:
        return False, "Primary DNS tidak boleh kosong."
    if not _is_valid_dns_server_value(val):
        return False, "Primary DNS tidak valid. Gunakan IP/FQDN/URI DNS yang valid."
    _dns_set_server_idx(cfg, 0, val)
    return True, f"Primary DNS di-set ke {val}."


def _dns_set_secondary(cfg: dict[str, Any], value: str) -> tuple[bool, str]:
    val = str(value or "").strip()
    if not val:
        return False, "Secondary DNS tidak boleh kosong."
    if not _is_valid_dns_server_value(val):
        return False, "Secondary DNS tidak valid. Gunakan IP/FQDN/URI DNS yang valid."
    servers = _dns_servers_list(cfg)
    if len(servers) == 0:
        _dns_set_server_idx(cfg, 0, "1.1.1.1")
    _dns_set_server_idx(cfg, 1, val)
    return True, f"Secondary DNS di-set ke {val}."


def _dns_set_query_strategy(cfg: dict[str, Any], strategy: str) -> tuple[bool, str]:
    val = str(strategy or "").strip()
    if val not in DNS_QUERY_STRATEGY_ALLOWED:
        choices = ", ".join(sorted(DNS_QUERY_STRATEGY_ALLOWED))
        return False, f"Query strategy invalid. Pilihan: {choices}."
    dns_obj = cfg.get("dns")
    assert isinstance(dns_obj, dict)
    dns_obj["queryStrategy"] = val
    return True, f"Query strategy di-set ke {val}."


def _dns_toggle_cache(cfg: dict[str, Any]) -> tuple[bool, str]:
    dns_obj = cfg.get("dns")
    assert isinstance(dns_obj, dict)
    current = bool(dns_obj.get("disableCache"))
    dns_obj["disableCache"] = not current
    state = "OFF" if not current else "ON"
    # disableCache=true means cache OFF.
    return True, f"DNS cache sekarang: {state}."


def _build_links(proto: str, username: str, cred: str, domain: str) -> dict[str, str]:
    public_paths = {
        "vless": {"ws": "/vless-ws", "httpupgrade": "/vless-hup", "grpc": "vless-grpc"},
        "vmess": {"ws": "/vmess-ws", "httpupgrade": "/vmess-hup", "grpc": "vmess-grpc"},
        "trojan": {"ws": "/trojan-ws", "httpupgrade": "/trojan-hup", "grpc": "trojan-grpc"},
    }

    def vless_link(net: str, val: str) -> str:
        q = {"encryption": "none", "security": "tls", "type": net, "sni": domain}
        if net in {"ws", "httpupgrade"}:
            q["path"] = val or "/"
        elif net == "grpc" and val:
            q["serviceName"] = val
        return f"vless://{cred}@{domain}:443?{urllib.parse.urlencode(q)}#{urllib.parse.quote(username + '@' + proto)}"

    def trojan_link(net: str, val: str) -> str:
        q = {"security": "tls", "type": net, "sni": domain}
        if net in {"ws", "httpupgrade"}:
            q["path"] = val or "/"
        elif net == "grpc" and val:
            q["serviceName"] = val
        return f"trojan://{cred}@{domain}:443?{urllib.parse.urlencode(q)}#{urllib.parse.quote(username + '@' + proto)}"

    def vmess_link(net: str, val: str) -> str:
        obj = {
            "v": "2",
            "ps": username + "@" + proto,
            "add": domain,
            "port": "443",
            "id": cred,
            "aid": "0",
            "net": net,
            "type": "none",
            "host": domain,
            "tls": "tls",
            "sni": domain,
        }
        if net in {"ws", "httpupgrade"}:
            obj["path"] = val or "/"
        elif net == "grpc":
            obj["path"] = val or ""
            obj["type"] = "gun"
        raw = json.dumps(obj, separators=(",", ":"))
        return "vmess://" + base64.b64encode(raw.encode()).decode()

    links: dict[str, str] = {}
    p = public_paths.get(proto, {})
    for net in ("ws", "httpupgrade", "grpc"):
        v = p.get(net, "")
        if proto == "vless":
            links[net] = vless_link(net, v)
        elif proto == "vmess":
            links[net] = vmess_link(net, v)
        else:
            links[net] = trojan_link(net, v)
    return links


def _build_account_text(
    proto: str,
    username: str,
    credential: str,
    domain: str,
    ip: str,
    quota_bytes: int,
    created_at: str,
    expired_at: str,
    days: int,
    ip_enabled: bool,
    ip_limit: int,
    speed_enabled: bool,
    speed_down: float,
    speed_up: float,
) -> str:
    links = _build_links(proto, username, credential, domain)
    isp, country = _geo_lookup(ip)
    proto_disp = _proto_display_label(proto)
    ws_path = (({
        "vless": {"ws": "/vless-ws"},
        "vmess": {"ws": "/vmess-ws"},
        "trojan": {"ws": "/trojan-ws"},
    }).get(proto, {}).get("ws") or "/")
    lines = [
        "=== XRAY ACCOUNT INFO ===",
        f"Domain      : {domain}",
        f"IP          : {ip}",
        f"ISP         : {isp}",
        f"Country     : {country}",
        f"Username    : {username}",
        f"Protocol    : {proto}",
    ]
    if proto in {"vless", "vmess"}:
        lines.append(f"UUID        : {credential}")
    else:
        lines.append(f"Password    : {credential}")

    lines.extend(
        [
            f"Quota Limit : {_fmt_quota_gb_from_bytes(max(0, quota_bytes))} GB",
            f"Expired     : {max(0, days)} days",
            f"Valid Until : {expired_at}",
            f"Created     : {created_at}",
            f"IP Limit    : {'ON' if ip_enabled else 'OFF'}" + (f" ({ip_limit})" if ip_enabled else ""),
        ]
    )

    if speed_enabled and speed_down > 0 and speed_up > 0:
        lines.append(f"Speed Limit : ON (DOWN {_fmt_number(speed_down)} Mbps | UP {_fmt_number(speed_up)} Mbps)")
    else:
        lines.append("Speed Limit : OFF")
    lines.append(f"{proto_disp} Path : {ws_path}")
    lines.append(f"{proto_disp} Path Alt : {_path_alt_placeholder(ws_path)}")
    lines.append(f"{proto_disp} Port : 443 & 80")

    lines.extend(
        [
            "",
            "Links Import:",
            f"  WebSocket   : {links.get('ws', '-')}",
            f"  HTTPUpgrade : {links.get('httpupgrade', '-')}",
            f"  gRPC        : {links.get('grpc', '-')}",
            "",
        ]
    )
    return "\n".join(lines)


def _read_account_fields(path: Path) -> dict[str, str]:
    fields: dict[str, str] = {}
    if not path.exists():
        return fields
    try:
        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if ":" not in raw:
                continue
            k, v = raw.split(":", 1)
            fields[k.strip()] = v.strip()
    except Exception:
        return {}
    return fields


def _find_credential_in_inbounds(proto: str, username: str) -> str:
    email = _email(proto, username)
    ok, payload = _read_json(XRAY_INBOUNDS_CONF)
    if not ok or not isinstance(payload, dict):
        return ""
    inbounds = payload.get("inbounds", [])
    if not isinstance(inbounds, list):
        return ""
    for ib in inbounds:
        if not _inbound_matches_proto(ib, proto):
            continue
        clients = (ib.get("settings") or {}).get("clients")
        if not isinstance(clients, list):
            continue
        for c in clients:
            if not isinstance(c, dict):
                continue
            if str(c.get("email") or "") != email:
                continue
            if proto == "trojan":
                return str(c.get("password") or "").strip()
            return str(c.get("id") or "").strip()
    return ""


def _write_account_artifacts(
    proto: str,
    username: str,
    credential: str,
    quota_bytes: int,
    days: int,
    ip_enabled: bool,
    ip_limit: int,
    speed_enabled: bool,
    speed_down: float,
    speed_up: float,
) -> tuple[Path, Path]:
    _ensure_runtime_dirs()

    created_dt = datetime.now(timezone.utc)
    created_date = created_dt.date()
    expired_date = created_date + timedelta(days=max(1, int(days)))
    created_at = created_dt.strftime("%Y-%m-%d %H:%M")
    expired_at = expired_date.strftime("%Y-%m-%d")

    domain = _detect_domain()
    ip = _detect_public_ipv4()

    account_file = ACCOUNT_ROOT / proto / f"{username}@{proto}.txt"
    quota_file = QUOTA_ROOT / proto / f"{username}@{proto}.json"

    account_text = _build_account_text(
        proto=proto,
        username=username,
        credential=credential,
        domain=domain,
        ip=ip,
        quota_bytes=int(max(0, quota_bytes)),
        created_at=created_at,
        expired_at=expired_at,
        days=max(0, int(days)),
        ip_enabled=bool(ip_enabled),
        ip_limit=max(0, int(ip_limit)) if ip_enabled else 0,
        speed_enabled=bool(speed_enabled),
        speed_down=float(speed_down) if speed_enabled else 0.0,
        speed_up=float(speed_up) if speed_enabled else 0.0,
    )

    quota_payload: dict[str, Any] = {
        "username": _email(proto, username),
        "protocol": proto,
        "quota_limit": int(max(0, quota_bytes)),
        "quota_unit": "binary",
        "quota_used": 0,
        "created_at": created_at,
        "expired_at": expired_at,
        "status": {
            "manual_block": False,
            "quota_exhausted": False,
            "ip_limit_enabled": bool(ip_enabled),
            "ip_limit": int(max(0, ip_limit)) if ip_enabled else 0,
            "speed_limit_enabled": bool(speed_enabled),
            "speed_down_mbit": float(speed_down) if speed_enabled else 0.0,
            "speed_up_mbit": float(speed_up) if speed_enabled else 0.0,
            "ip_limit_locked": False,
            "lock_reason": "",
            "locked_at": "",
        },
    }

    _write_text_atomic(account_file, account_text)
    _write_json_atomic(quota_file, quota_payload)
    _chmod_600(account_file)
    _chmod_600(quota_file)
    return account_file, quota_file


def _refresh_account_info_for_user(proto: str, username: str, domain: str | None = None, ip: str | None = None) -> tuple[bool, str]:
    if proto not in USER_PROTOCOLS:
        return False, f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "Username SSH tidak valid"
        return _ssh_refresh_account_info(username)
    if not _is_valid_username(username):
        return False, "Username tidak valid"

    _ensure_runtime_dirs()

    account_target = _resolve_existing(_account_candidates(proto, username))
    quota_target = _resolve_existing(_quota_candidates(proto, username))

    if account_target is None:
        account_target = ACCOUNT_ROOT / proto / f"{username}@{proto}.txt"

    account_fields = _read_account_fields(account_target)

    quota_data: dict[str, Any] = {}
    if quota_target is not None:
        ok, payload = _read_json(quota_target)
        if ok and isinstance(payload, dict):
            quota_data = payload

    status = quota_data.get("status") if isinstance(quota_data.get("status"), dict) else {}

    quota_limit = _to_int(quota_data.get("quota_limit"), 0)
    created_at = _normalize_created_display(
        quota_data.get("created_at") or account_fields.get("Created") or "",
        date_only=False,
    )

    expired_at = str(quota_data.get("expired_at") or account_fields.get("Valid Until") or "").strip()[:10]
    if not expired_at:
        expired_at = "-"

    d_created = _parse_date_only(created_at)
    d_expired = _parse_date_only(expired_at)
    if d_created and d_expired:
        days = max(0, (d_expired - d_created).days)
    elif d_expired:
        days = max(0, (d_expired - date.today()).days)
    else:
        days = 0

    ip_enabled = bool(status.get("ip_limit_enabled"))
    ip_limit = _to_int(status.get("ip_limit"), 0) if ip_enabled else 0

    speed_enabled = bool(status.get("speed_limit_enabled"))
    speed_down = _to_float(status.get("speed_down_mbit"), 0.0)
    speed_up = _to_float(status.get("speed_up_mbit"), 0.0)
    if speed_down <= 0 or speed_up <= 0:
        speed_enabled = False
        speed_down = 0.0
        speed_up = 0.0

    credential = _find_credential_in_inbounds(proto, username)
    if not credential:
        if proto == "trojan":
            credential = account_fields.get("Password", "").strip()
        else:
            credential = account_fields.get("UUID", "").strip()
    if not credential:
        return False, f"Credential tidak ditemukan untuk {username}@{proto}"

    domain_eff = str(domain or "").strip() or _detect_domain()
    ip_eff = str(ip or "").strip() or account_fields.get("IP", "").strip() or _detect_public_ipv4()

    content = _build_account_text(
        proto=proto,
        username=username,
        credential=credential,
        domain=domain_eff,
        ip=ip_eff,
        quota_bytes=quota_limit,
        created_at=created_at,
        expired_at=expired_at,
        days=days,
        ip_enabled=ip_enabled,
        ip_limit=ip_limit,
        speed_enabled=speed_enabled,
        speed_down=speed_down,
        speed_up=speed_up,
    )

    _write_text_atomic(account_target, content)
    _chmod_600(account_target)
    return True, "ok"


def _restore_account_info_snapshots(snapshots: dict[Path, dict[str, Any]]) -> list[str]:
    notes: list[str] = []
    for path, snapshot in snapshots.items():
        ok_restore, restore_msg = _restore_optional_file(path, snapshot)
        if not ok_restore:
            notes.append(restore_msg)
    return notes


@_user_data_mutation_locked
def _refresh_all_account_info(domain: str | None = None, ip: str | None = None) -> tuple[int, int]:
    _ensure_runtime_dirs()
    domain_eff = str(domain or "").strip() or _detect_domain()
    ip_eff = str(ip or "").strip() or _detect_public_ipv4()

    updated = 0
    failed = 0
    snapshots: dict[Path, dict[str, Any]] = {}

    for proto in USER_PROTOCOLS:
        d = ACCOUNT_ROOT / proto
        if not d.exists():
            continue
        selected: dict[str, Path] = {}
        selected_has_at: dict[str, bool] = {}
        for p in sorted(d.glob("*.txt")):
            username = _extract_username_from_file_name(p, proto)
            if not username:
                continue
            has_at = "@" in p.stem
            prev = selected.get(username)
            if prev is not None:
                if has_at and not selected_has_at.get(username, False):
                    selected[username] = p
                    selected_has_at[username] = True
                continue
            selected[username] = p
            selected_has_at[username] = has_at

        for username in sorted(selected.keys()):
            target = selected[username]
            if target not in snapshots:
                snapshots[target] = _snapshot_optional_file(target)
            ok, _ = _refresh_account_info_for_user(proto, username, domain=domain_eff, ip=ip_eff)
            if ok:
                updated += 1
            else:
                failed += 1

    if failed > 0:
        restore_notes = _restore_account_info_snapshots(snapshots)
        updated = 0
        if restore_notes:
            failed += len(restore_notes)
    return updated, failed


def _account_refresh_outcome(
    title: str,
    lines: list[str],
    *,
    updated: int,
    failed: int,
    partial_failure_hint: str,
) -> tuple[bool, str, str]:
    message_lines = list(lines)
    message_lines.append(f"- Refresh account info: updated={updated}, failed={failed}")
    if failed > 0:
        message_lines.append(partial_failure_hint)
        return False, title, "\n".join(message_lines)
    return True, title, "\n".join(message_lines)


def _speed_policy_file_path(proto: str, username: str) -> Path:
    return SPEED_POLICY_ROOT / proto / f"{username}@{proto}.json"


def _speed_policy_exists(proto: str, username: str) -> bool:
    return _speed_policy_file_path(proto, username).exists()


def _speed_policy_remove(proto: str, username: str) -> None:
    p = _speed_policy_file_path(proto, username)
    with file_lock(SPEED_POLICY_LOCK_FILE):
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


def _valid_mark(v: Any) -> bool:
    m = _to_int(v, -1)
    return SPEED_MARK_MIN <= m <= SPEED_MARK_MAX


def _collect_used_marks(exclude_path: Path | None = None) -> set[int]:
    used: set[int] = set()
    for proto in PROTOCOLS:
        d = SPEED_POLICY_ROOT / proto
        if not d.exists():
            continue
        for p in d.glob("*.json"):
            if exclude_path is not None and p.resolve() == exclude_path.resolve():
                continue
            ok, payload = _read_json(p)
            if not ok or not isinstance(payload, dict):
                continue
            m = _to_int(payload.get("mark"), -1)
            if _valid_mark(m):
                used.add(m)
    return used


def _speed_policy_upsert(proto: str, username: str, down_mbit: float, up_mbit: float) -> tuple[bool, int | str]:
    down = _to_float(down_mbit, 0.0)
    up = _to_float(up_mbit, 0.0)
    if down <= 0 or up <= 0:
        return False, "Speed harus > 0"

    _ensure_runtime_dirs()

    email = _email(proto, username)
    target = _speed_policy_file_path(proto, username)

    with file_lock(SPEED_POLICY_LOCK_FILE):
        existing_mark = None
        if target.exists():
            ok, payload = _read_json(target)
            if ok and isinstance(payload, dict) and _valid_mark(payload.get("mark")):
                existing_mark = _to_int(payload.get("mark"), -1)

        used = _collect_used_marks(exclude_path=target)

        mark: int
        if existing_mark is not None and existing_mark not in used:
            mark = existing_mark
        else:
            size = SPEED_MARK_MAX - SPEED_MARK_MIN + 1
            seed = zlib.crc32(email.encode("utf-8")) & 0xFFFFFFFF
            start = SPEED_MARK_MIN + (seed % size)
            mark = -1
            for i in range(size):
                cand = SPEED_MARK_MIN + ((start - SPEED_MARK_MIN + i) % size)
                if cand not in used:
                    mark = cand
                    break
            if mark < 0:
                return False, "Range mark speed policy habis"

        payload = {
            "enabled": True,
            "username": email,
            "protocol": proto,
            "mark": mark,
            "down_mbit": round(down, 3),
            "up_mbit": round(up, 3),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        _write_json_atomic(target, payload)
        _chmod_600(target)

    return True, mark


def _list_speed_mark_users() -> dict[int, list[str]]:
    mark_users: dict[int, set[str]] = {}
    for proto in PROTOCOLS:
        d = SPEED_POLICY_ROOT / proto
        if not d.exists():
            continue
        for p in sorted(d.glob("*.json")):
            ok, payload = _read_json(p)
            if not ok or not isinstance(payload, dict):
                continue
            enabled = payload.get("enabled", True)
            enabled_bool = bool(enabled) if isinstance(enabled, bool) else str(enabled).strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
            if not enabled_bool:
                continue
            mark = _to_int(payload.get("mark"), -1)
            if not _valid_mark(mark):
                continue
            down = _to_float(payload.get("down_mbit"), 0.0)
            up = _to_float(payload.get("up_mbit"), 0.0)
            if down <= 0 or up <= 0:
                continue
            email = str(payload.get("username") or payload.get("email") or p.stem).strip()
            if not email:
                continue
            mark_users.setdefault(mark, set()).add(email)
    return {k: sorted(v) for k, v in sorted(mark_users.items())}


def _speed_policy_sync_xray() -> tuple[bool, str]:
    if not XRAY_OUTBOUNDS_CONF.exists() or not XRAY_ROUTING_CONF.exists():
        return False, "File outbounds/routing tidak ditemukan"

    with file_lock(ROUTING_LOCK_FILE):
        ok_out, out_cfg = _read_json(XRAY_OUTBOUNDS_CONF)
        ok_rt, rt_cfg = _read_json(XRAY_ROUTING_CONF)
        if not ok_out:
            return False, str(out_cfg)
        if not ok_rt:
            return False, str(rt_cfg)
        if not isinstance(out_cfg, dict) or not isinstance(rt_cfg, dict):
            return False, "Format config Xray tidak valid"

        out_original = json.loads(json.dumps(out_cfg))
        rt_original = json.loads(json.dumps(rt_cfg))

        outbounds = out_cfg.get("outbounds")
        if not isinstance(outbounds, list):
            return False, "outbounds bukan list"

        routing = rt_cfg.get("routing") or {}
        rules = routing.get("rules") if isinstance(routing, dict) else None
        if not isinstance(rules, list):
            return False, "routing.rules bukan list"

        mark_users = _list_speed_mark_users()

        out_by_tag: dict[str, dict[str, Any]] = {}
        for out in outbounds:
            if isinstance(out, dict):
                tag = str(out.get("tag") or "").strip()
                if tag:
                    out_by_tag[tag] = out

        def is_default_rule(rule: Any) -> bool:
            if not isinstance(rule, dict):
                return False
            if rule.get("type") != "field":
                return False
            port = str(rule.get("port", "")).strip()
            if port not in {"1-65535", "0-65535"}:
                return False
            if rule.get("user") or rule.get("domain") or rule.get("ip") or rule.get("protocol"):
                return False
            return True

        default_rule = None
        for rule in rules:
            if is_default_rule(rule):
                default_rule = rule
                break

        base_selector: list[str] = []

        if isinstance(default_rule, dict):
            ot = str(default_rule.get("outboundTag") or "").strip()
            if ot:
                base_selector = [ot]

        if not base_selector:
            if "direct" in out_by_tag:
                base_selector = ["direct"]
            else:
                for tag in out_by_tag.keys():
                    if not tag.startswith(SPEED_OUTBOUND_TAG_PREFIX):
                        base_selector = [tag]
                        break

        if not base_selector:
            return False, "Outbound dasar untuk speed policy tidak ditemukan"

        effective_selector: list[str] = []
        seen: set[str] = set()
        for tag in base_selector:
            t = str(tag).strip()
            if not t or t in {"api", "blocked"} or t.startswith(SPEED_OUTBOUND_TAG_PREFIX):
                continue
            if t not in out_by_tag:
                continue
            if t in seen:
                continue
            seen.add(t)
            effective_selector.append(t)

        if not effective_selector:
            if "direct" in out_by_tag:
                effective_selector = ["direct"]
            else:
                for t in out_by_tag.keys():
                    if t in {"api", "blocked"} or t.startswith(SPEED_OUTBOUND_TAG_PREFIX):
                        continue
                    effective_selector = [t]
                    break

        if not effective_selector:
            return False, "Selector outbound dasar untuk speed policy kosong"

        clean_outbounds: list[Any] = []
        for out in outbounds:
            if isinstance(out, dict):
                tag = str(out.get("tag") or "").strip()
                if tag.startswith(SPEED_OUTBOUND_TAG_PREFIX):
                    continue
            clean_outbounds.append(out)

        mark_out_tags: dict[int, dict[str, str]] = {}
        for mark in sorted(mark_users.keys()):
            per_mark: dict[str, str] = {}
            for base_tag in effective_selector:
                src = out_by_tag.get(base_tag)
                if not isinstance(src, dict):
                    continue
                clone = json.loads(json.dumps(src))
                safe_base_tag = re.sub(r"[^A-Za-z0-9_.-]", "-", base_tag)
                clone_tag = f"{SPEED_OUTBOUND_TAG_PREFIX}{mark}-{safe_base_tag}"
                clone["tag"] = clone_tag
                ss = clone.get("streamSettings")
                if not isinstance(ss, dict):
                    ss = {}
                sock = ss.get("sockopt")
                if not isinstance(sock, dict):
                    sock = {}
                sock["mark"] = int(mark)
                ss["sockopt"] = sock
                clone["streamSettings"] = ss
                clean_outbounds.append(clone)
                per_mark[base_tag] = clone_tag
            mark_out_tags[mark] = per_mark

        out_cfg["outbounds"] = clean_outbounds

        def is_protected_rule(rule: Any) -> bool:
            if not isinstance(rule, dict):
                return False
            if rule.get("type") != "field":
                return False
            ot = str(rule.get("outboundTag") or "").strip()
            return ot in {"api", "blocked"}

        kept_rules: list[Any] = []
        for rule in rules:
            if not isinstance(rule, dict):
                kept_rules.append(rule)
                continue
            if rule.get("type") != "field":
                kept_rules.append(rule)
                continue
            users = rule.get("user")
            ot = str(rule.get("outboundTag") or "").strip()
            has_speed_marker = isinstance(users, list) and any(
                isinstance(u, str) and u.startswith(SPEED_RULE_MARKER_PREFIX) for u in users
            )
            if has_speed_marker and ot.startswith(SPEED_OUTBOUND_TAG_PREFIX):
                continue
            kept_rules.append(rule)

        insert_idx = len(kept_rules)
        for idx, rule in enumerate(kept_rules):
            if is_protected_rule(rule):
                continue
            insert_idx = idx
            break

        speed_rules: list[dict[str, Any]] = []
        for mark, users in sorted(mark_users.items()):
            marker = f"{SPEED_RULE_MARKER_PREFIX}{mark}"
            rule: dict[str, Any] = {"type": "field", "user": [marker] + users}
            first_base = effective_selector[0]
            ot = mark_out_tags.get(mark, {}).get(first_base, "")
            if not ot:
                continue
            rule["outboundTag"] = ot
            speed_rules.append(rule)

        merged_rules = kept_rules[:insert_idx] + speed_rules + kept_rules[insert_idx:]
        routing["rules"] = merged_rules
        rt_cfg["routing"] = routing

        try:
            _write_json_atomic(XRAY_OUTBOUNDS_CONF, out_cfg)
            _write_json_atomic(XRAY_ROUTING_CONF, rt_cfg)
            if not _restart_and_wait("xray", timeout_sec=20):
                _write_json_atomic(XRAY_OUTBOUNDS_CONF, out_original)
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
                return False, "xray tidak aktif setelah sinkronisasi speed policy (rollback)."
        except Exception as exc:
            try:
                _write_json_atomic(XRAY_OUTBOUNDS_CONF, out_original)
                _write_json_atomic(XRAY_ROUTING_CONF, rt_original)
                _restart_and_wait("xray", timeout_sec=20)
            except Exception:
                pass
            return False, f"Gagal sinkronisasi speed policy: {exc}"

    return True, "ok"


def _speed_policy_apply_now() -> bool:
    if Path("/usr/local/bin/xray-speed").exists() and SPEED_CONFIG_FILE.exists():
        ok, _ = _run_cmd(["/usr/local/bin/xray-speed", "once", "--config", str(SPEED_CONFIG_FILE)], timeout=30)
        if ok:
            return True
    if _service_exists("xray-speed"):
        return _restart_and_wait("xray-speed", timeout_sec=20)
    return False


def _quota_sync_speed_policy_for_user(proto: str, username: str, quota_data: dict[str, Any]) -> tuple[bool, str]:
    status = quota_data.get("status") if isinstance(quota_data.get("status"), dict) else {}
    speed_on = bool(status.get("speed_limit_enabled"))
    speed_down = _to_float(status.get("speed_down_mbit"), 0.0)
    speed_up = _to_float(status.get("speed_up_mbit"), 0.0)

    if speed_on:
        if speed_down <= 0 or speed_up <= 0:
            return False, "Speed limit aktif tapi nilai speed_down/speed_up belum valid (>0)."
        ok_upsert, mark_or_err = _speed_policy_upsert(proto, username, speed_down, speed_up)
        if not ok_upsert:
            return False, f"Gagal menyimpan speed policy: {mark_or_err}"
        ok_sync, sync_msg = _speed_policy_sync_xray()
        if not ok_sync:
            return False, sync_msg
        if not _speed_policy_apply_now():
            return False, "Speed policy tersimpan, tetapi apply runtime gagal (xray-speed)."
        return True, f"Speed policy aktif (mark={mark_or_err})."

    removed = _speed_policy_exists(proto, username)
    if removed:
        ok_remove, remove_msg = _speed_policy_remove_checked(proto, username)
        if not ok_remove:
            return False, remove_msg
        ok_sync, sync_msg = _speed_policy_sync_xray()
        if not ok_sync:
            return False, sync_msg
        if not _speed_policy_apply_now():
            return False, "Speed policy dimatikan, tetapi apply runtime gagal (xray-speed)."
        return True, "ok"
    if not _speed_policy_apply_now():
        return False, "Speed policy runtime gagal di-refresh (xray-speed)."
    return True, "ok"


def _delete_account_artifacts(proto: str, username: str) -> None:
    for p in [
        ACCOUNT_ROOT / proto / f"{username}@{proto}.txt",
        ACCOUNT_ROOT / proto / f"{username}.txt",
        QUOTA_ROOT / proto / f"{username}@{proto}.json",
        QUOTA_ROOT / proto / f"{username}.json",
    ]:
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


def _delete_account_artifacts_checked(proto: str, username: str) -> list[str]:
    notes: list[str] = []
    for p in [
        ACCOUNT_ROOT / proto / f"{username}@{proto}.txt",
        ACCOUNT_ROOT / proto / f"{username}.txt",
        QUOTA_ROOT / proto / f"{username}@{proto}.json",
        QUOTA_ROOT / proto / f"{username}.json",
    ]:
        exists_before = p.exists() or p.is_symlink()
        if not exists_before:
            continue
        try:
            p.unlink(missing_ok=True)
        except Exception as exc:
            notes.append(f"{p}: {exc}")
            continue
        if p.exists() or p.is_symlink():
            notes.append(f"{p}: masih ada setelah unlink")
    return notes


def _run_limit_ip_restart_if_present() -> tuple[bool, str]:
    for name in ("xray-limit-ip", "xray-limit"):
        if _service_exists(name):
            if _restart_and_wait(name, timeout_sec=15):
                return True, "ok"
            return False, f"Service {name} gagal restart/apply"
    return True, "skip"


def _xray_refresh_account_info_required(
    title: str,
    proto: str,
    username: str,
    success_msg: str,
) -> tuple[bool, str, str]:
    ok_refresh, refresh_msg = _refresh_account_info_for_user(proto, username)
    if ok_refresh:
        return True, title, success_msg
    return (
        False,
        title,
        (
            f"{success_msg}\n"
            f"- Refresh XRAY ACCOUNT INFO gagal: {refresh_msg}\n"
            f"- Perubahan runtime/metadata sudah diterapkan, tetapi file account belum sinkron"
        ),
    )


def _xray_cleanup_new_user_after_failure(proto: str, username: str) -> tuple[bool, str]:
    notes: list[str] = []

    ok_del, del_msg = _xray_delete_client(proto, username)
    if not ok_del and "tidak ditemukan" not in del_msg.lower():
        notes.append(f"cleanup inbounds: {del_msg}")

    cleanup_notes = _delete_account_artifacts_checked(proto, username)
    for note in cleanup_notes:
        notes.append(f"cleanup artefak: {note}")

    ok_remove, remove_msg = _speed_policy_remove_checked(proto, username)
    if not ok_remove:
        notes.append(f"cleanup speed policy file: {remove_msg}")
    ok_sync, sync_msg = _speed_policy_sync_xray()
    if not ok_sync:
        notes.append(f"cleanup speed policy: {sync_msg}")
    elif not _speed_policy_apply_now():
        notes.append("cleanup speed policy: apply runtime gagal (xray-speed)")

    if notes:
        return False, "; ".join(notes)
    return True, "ok"


def _restore_account_artifacts_from_snapshots(
    proto: str,
    username: str,
    *,
    account_snapshot: str | None,
    quota_snapshot: dict[str, Any] | None,
) -> list[str]:
    notes: list[str] = []
    account_path = ACCOUNT_ROOT / proto / f"{username}@{proto}.txt"
    quota_path = QUOTA_ROOT / proto / f"{username}@{proto}.json"

    if quota_snapshot is not None:
        try:
            _save_quota(quota_path, copy.deepcopy(quota_snapshot))
        except Exception as exc:
            notes.append(f"restore quota: {exc}")
    if account_snapshot is not None:
        try:
            _write_text_atomic(account_path, account_snapshot)
            _chmod_600(account_path)
        except Exception as exc:
            notes.append(f"restore account: {exc}")
    return notes


def _xray_apply_runtime_from_quota(
    proto: str,
    username: str,
    quota_data: dict[str, Any],
    *,
    ensure_client_credential: str = "",
    restore_markers: bool = False,
    restart_limit_ip: bool = False,
    sync_speed: bool = False,
) -> tuple[bool, str]:
    if ensure_client_credential and not _user_exists_in_inbounds(proto, username):
        ok_add, add_msg = _xray_add_client(proto, username, ensure_client_credential)
        if not ok_add and "sudah ada" not in add_msg.lower():
            return False, f"restore inbounds: {add_msg}"

    status = quota_data.get("status") if isinstance(quota_data.get("status"), dict) else {}
    if restore_markers:
        marker_states = (
            ("dummy-quota-user", bool(status.get("quota_exhausted"))),
            ("dummy-block-user", bool(status.get("manual_block"))),
            ("dummy-limit-user", bool(status.get("ip_limit_locked"))),
        )
        for marker, enabled in marker_states:
            ok_marker, marker_msg = _routing_set_user_in_marker(
                marker,
                _email(proto, username),
                "on" if enabled else "off",
                outbound_tag="blocked",
            )
            if not ok_marker:
                return False, f"routing {marker}: {marker_msg}"

    if restart_limit_ip:
        ok_restart, restart_msg = _run_limit_ip_restart_if_present()
        if not ok_restart:
            return False, restart_msg

    if sync_speed:
        ok_speed, speed_msg = _quota_sync_speed_policy_for_user(proto, username, quota_data)
        if not ok_speed:
            return False, speed_msg

    return True, "ok"


def _xray_apply_quota_update(
    title: str,
    proto: str,
    username: str,
    quota_path: Path,
    previous_payload: dict[str, Any],
    next_payload: dict[str, Any],
    success_msg: str,
    *,
    ensure_client_credential: str = "",
    restore_markers: bool = False,
    restart_limit_ip: bool = False,
    sync_speed: bool = False,
) -> tuple[bool, str, str]:
    _save_quota(quota_path, next_payload)

    ok_runtime, runtime_msg = _xray_apply_runtime_from_quota(
        proto,
        username,
        next_payload,
        ensure_client_credential=ensure_client_credential,
        restore_markers=restore_markers,
        restart_limit_ip=restart_limit_ip,
        sync_speed=sync_speed,
    )
    if not ok_runtime:
        rollback_notes: list[str] = []
        try:
            _save_quota(quota_path, previous_payload)
        except Exception as exc:
            rollback_notes.append(f"rollback quota: {exc}")
        else:
            ok_restore, restore_msg = _xray_apply_runtime_from_quota(
                proto,
                username,
                previous_payload,
                ensure_client_credential=ensure_client_credential,
                restore_markers=restore_markers,
                restart_limit_ip=restart_limit_ip,
                sync_speed=sync_speed,
            )
            if not ok_restore:
                rollback_notes.append(f"rollback runtime: {restore_msg}")
            ok_refresh, refresh_msg = _refresh_account_info_for_user(proto, username)
            if not ok_refresh:
                rollback_notes.append(f"rollback account-info: {refresh_msg}")

        detail = runtime_msg
        if rollback_notes:
            detail += " | " + " | ".join(rollback_notes)
        else:
            detail += " | state di-rollback"
        return False, title, detail

    ok_refresh, refresh_msg = _refresh_account_info_for_user(proto, username)
    if ok_refresh:
        return True, title, success_msg

    rollback_notes: list[str] = [f"refresh account-info: {refresh_msg}"]
    try:
        _save_quota(quota_path, previous_payload)
    except Exception as exc:
        rollback_notes.append(f"rollback quota: {exc}")
    else:
        ok_restore, restore_msg = _xray_apply_runtime_from_quota(
            proto,
            username,
            previous_payload,
            ensure_client_credential=ensure_client_credential,
            restore_markers=restore_markers,
            restart_limit_ip=restart_limit_ip,
            sync_speed=sync_speed,
        )
        if not ok_restore:
            rollback_notes.append(f"rollback runtime: {restore_msg}")
        ok_rb_refresh, rb_refresh_msg = _refresh_account_info_for_user(proto, username)
        if not ok_rb_refresh:
            rollback_notes.append(f"rollback account-info: {rb_refresh_msg}")

    return False, title, f"{success_msg} | " + " | ".join(rollback_notes)


def _xray_restore_deleted_user(
    proto: str,
    username: str,
    *,
    credential: str,
    account_snapshot: str | None,
    quota_snapshot: dict[str, Any] | None,
) -> tuple[bool, str]:
    notes = _restore_account_artifacts_from_snapshots(
        proto,
        username,
        account_snapshot=account_snapshot,
        quota_snapshot=quota_snapshot,
    )

    ok_runtime, runtime_msg = _xray_apply_runtime_from_quota(
        proto,
        username,
        quota_snapshot or {},
        ensure_client_credential=credential,
        restore_markers=True,
        restart_limit_ip=True,
        sync_speed=True,
    )
    if not ok_runtime:
        notes.append(f"restore runtime: {runtime_msg}")

    ok_refresh, refresh_msg = _refresh_account_info_for_user(proto, username)
    if not ok_refresh:
        notes.append(f"restore account-info: {refresh_msg}")

    if notes:
        return False, " | ".join(notes)
    return True, "ok"


@_user_data_mutation_locked
def op_user_add(
    proto: str,
    username: str,
    days: int,
    quota_gb: float,
    ip_enabled: bool,
    ip_limit: int,
    speed_enabled: bool,
    speed_down_mbit: float,
    speed_up_mbit: float,
    password: str = "",
) -> tuple[bool, str, str]:
    if proto not in USER_PROTOCOLS:
        return False, "User Management - Add User", f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "User Management - Add User", "Username SSH tidak valid. Gunakan huruf kecil/angka/_/-."
    elif not _is_valid_username(username):
        return False, "User Management - Add User", "Username tidak valid."
    if days <= 0:
        return False, "User Management - Add User", "Masa aktif harus > 0 hari."
    if quota_gb <= 0:
        return False, "User Management - Add User", "Quota harus > 0 GB."
    if ip_enabled and ip_limit <= 0:
        return False, "User Management - Add User", "IP limit harus > 0 jika IP limit aktif."

    speed_on = bool(speed_enabled)
    down = _to_float(speed_down_mbit, 0.0)
    up = _to_float(speed_up_mbit, 0.0)
    if speed_on and (down <= 0 or up <= 0):
        return False, "User Management - Add User", "Speed limit aktif, tapi speed download/upload belum valid (>0)."

    exists, where = _username_exists_anywhere(username)
    if exists:
        return False, "User Management - Add User", f"Username sudah ada: {username} ({where})"

    if proto == SSH_PROTOCOL:
        raw_password = str(password or "")
        if not raw_password.strip():
            return False, "User Management - Add User", "Password SSH wajib diisi."
        if username.strip().lower() == raw_password.strip().lower():
            return False, "User Management - Add User", "Password SSH tidak boleh sama dengan username."

        expiry = (date.today() + timedelta(days=max(1, int(days)))).strftime("%Y-%m-%d")
        created_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M")
        quota_bytes = int(round(quota_gb * (1024**3)))
        quota_path = SSH_QUOTA_DIR / f"{username}@{SSH_PROTOCOL}.json"
        account_path = SSH_ACCOUNT_DIR / f"{username}@{SSH_PROTOCOL}.txt"

        ok_add_user, out_add_user = _run_cmd(["useradd", "-m", "-s", "/bin/bash", username], timeout=20)
        if not ok_add_user:
            return False, "User Management - Add User", f"Gagal membuat user Linux '{username}': {out_add_user}"

        ok_passwd, out_passwd = _run_cmd(
            ["bash", "-lc", 'printf "%s:%s\\n" "$0" "$1" | chpasswd', username, raw_password],
            timeout=20,
        )
        if not ok_passwd:
            return _ssh_add_user_rollback(
                username,
                None,
                account_path,
                raw_password=raw_password,
                error_prefix=f"Gagal set password user '{username}': {out_passwd}",
                cleanup_zivpn=False,
            )

        ok_expiry, out_expiry = _ssh_apply_linux_expiry(username, expiry)
        if not ok_expiry:
            return _ssh_add_user_rollback(
                username,
                None,
                account_path,
                raw_password=raw_password,
                error_prefix=f"Gagal set expiry user '{username}': {out_expiry}",
                cleanup_zivpn=False,
            )

        try:
            with file_lock(str(SSHWS_LOCK_FILE)):
                ok_state, quota_path_or_err, payload_or_err = _ssh_load_state(
                    username,
                    create_missing=True,
                    created_at=created_at,
                    expired_at=expiry,
                )
                if not ok_state:
                    raise RuntimeError(str(quota_path_or_err))
                quota_path = quota_path_or_err
                quota_payload = payload_or_err
                assert isinstance(quota_path, Path)
                assert isinstance(quota_payload, dict)

                quota_payload["quota_limit"] = quota_bytes
                quota_payload["quota_used"] = 0
                quota_payload["created_at"] = created_at
                quota_payload["expired_at"] = expiry
                status = quota_payload.get("status") if isinstance(quota_payload.get("status"), dict) else {}
                status["manual_block"] = False
                status["quota_exhausted"] = False
                status["ip_limit_enabled"] = bool(ip_enabled)
                status["ip_limit"] = int(max(0, ip_limit)) if ip_enabled else 0
                status["ip_limit_locked"] = False
                status["speed_limit_enabled"] = bool(speed_on)
                status["speed_down_mbit"] = float(down) if speed_on else 0.0
                status["speed_up_mbit"] = float(up) if speed_on else 0.0
                status["account_locked"] = False
                status["lock_owner"] = ""
                status["lock_shell_restore"] = ""
                _status_apply_lock_fields(status)
                quota_payload["status"] = status
                _ssh_save_state(quota_path, quota_payload)
        except Exception as exc:
            return _ssh_add_user_rollback(
                username,
                quota_path if "quota_path" in locals() else None,
                account_path,
                raw_password=raw_password,
                error_prefix=f"Gagal menulis metadata SSH: {exc}",
                cleanup_zivpn=False,
            )

        if ip_enabled:
            ok_enforce, enforce_msg = _ssh_run_enforcer(
                username=username,
                require_available=True,
            )
            if not ok_enforce:
                return _ssh_add_user_rollback(
                    username,
                    quota_path,
                    account_path,
                    raw_password=raw_password,
                    error_prefix=f"Gagal enforcement awal SSH untuk '{username}': {enforce_msg}",
                    cleanup_zivpn=False,
                )

        ok_account, account_msg = _ssh_refresh_account_info(username, password_override=raw_password)
        if not ok_account:
            return _ssh_add_user_rollback(
                username,
                quota_path,
                account_path,
                raw_password=raw_password,
                error_prefix=str(account_msg),
                cleanup_zivpn=False,
            )

        ok_zivpn, zivpn_msg = _zivpn_sync_user_password(username, raw_password)
        if not ok_zivpn:
            return _ssh_add_user_rollback(
                username,
                quota_path,
                account_path,
                raw_password=raw_password,
                error_prefix=f"Gagal sinkronisasi ZIVPN untuk '{username}': {zivpn_msg}",
                cleanup_zivpn=True,
            )
        ok_account, account_msg = _ssh_refresh_account_info(username, password_override=raw_password)
        if not ok_account:
            return _ssh_add_user_rollback(
                username,
                quota_path,
                account_path,
                raw_password=raw_password,
                error_prefix=f"Gagal refresh SSH ACCOUNT INFO final untuk '{username}': {account_msg}",
                cleanup_zivpn=True,
            )

        warnings = _ssh_post_update_warnings(username, password_override=raw_password)
        msg = (
            f"Add user SSH sukses.\n"
            f"- User: {username}@{proto}\n"
            f"- Account: {account_path}\n"
            f"- Quota: {quota_path}"
        )
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "User Management - Add User", msg

    cred = _generate_credential(proto)
    quota_bytes = int(round(quota_gb * (1024**3)))

    ok_add, add_msg = _xray_add_client(proto, username, cred)
    if not ok_add:
        return False, "User Management - Add User", add_msg

    try:
        account_file, quota_file = _write_account_artifacts(
            proto=proto,
            username=username,
            credential=cred,
            quota_bytes=quota_bytes,
            days=days,
            ip_enabled=ip_enabled,
            ip_limit=ip_limit,
            speed_enabled=speed_on,
            speed_down=down,
            speed_up=up,
        )

        if speed_on:
            ok_sync, sync_msg = _quota_sync_speed_policy_for_user(
                proto,
                username,
                {
                    "status": {
                        "speed_limit_enabled": True,
                        "speed_down_mbit": down,
                        "speed_up_mbit": up,
                    }
                },
            )
            if not ok_sync:
                ok_cleanup, cleanup_msg = _xray_cleanup_new_user_after_failure(proto, username)
                suffix = (
                    f"\n- Cleanup rollback: {cleanup_msg}"
                    if ok_cleanup
                    else f"\n- Cleanup rollback gagal: {cleanup_msg}"
                )
                return (
                    False,
                    "User Management - Add User",
                    f"Rollback add user karena speed policy gagal: {sync_msg}{suffix}",
                )

        msg = (
            f"Add user sukses.\n"
            f"- User: {username}@{proto}\n"
            f"- Account: {account_file}\n"
            f"- Quota: {quota_file}"
        )
        return True, "User Management - Add User", msg
    except Exception as exc:
        ok_cleanup, cleanup_msg = _xray_cleanup_new_user_after_failure(proto, username)
        suffix = (
            f" Cleanup rollback: {cleanup_msg}."
            if ok_cleanup
            else f" Cleanup rollback gagal: {cleanup_msg}."
        )
        return False, "User Management - Add User", f"Gagal menyimpan artefak user: {exc}.{suffix}"


def op_user_account_file_download(proto: str, username: str) -> tuple[bool, dict[str, str] | str]:
    if proto not in USER_PROTOCOLS:
        return False, f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "Username SSH tidak valid."
    elif not _is_valid_username(username):
        return False, "Username tidak valid."

    account_file = _resolve_existing(_account_candidates(proto, username))
    if account_file is None:
        return False, f"File account tidak ditemukan untuk {username}@{proto}."

    try:
        raw = account_file.read_bytes()
    except Exception as exc:
        return False, f"Gagal membaca file account: {exc}"

    return True, {
        "filename": f"{username}@{proto}.txt",
        "content_base64": base64.b64encode(raw).decode("ascii"),
        "content_type": "text/plain",
    }


@_user_data_mutation_locked
def op_user_delete(proto: str, username: str) -> tuple[bool, str, str]:
    if proto not in USER_PROTOCOLS:
        return False, "User Management - Delete User", f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "User Management - Delete User", "Username SSH tidak valid."
    elif not _is_valid_username(username):
        return False, "User Management - Delete User", "Username tidak valid."

    if proto == SSH_PROTOCOL:
        previous_password = _ssh_previous_password(username)
        linux_exists = _linux_user_exists(username)
        if linux_exists and _zivpn_runtime_available() and (not previous_password or previous_password == "-"):
            return (
                False,
                "User Management - Delete User",
                (
                    f"Delete user dibatalkan untuk {username}@{proto}\n"
                    f"- Password rollback ZIVPN tidak tersedia\n"
                    f"- Akun belum dihapus agar rollback aman tetap memungkinkan"
                ),
            )
        ok_zivpn, zivpn_msg = _zivpn_remove_user_password(username)
        if not ok_zivpn:
            return (
                False,
                "User Management - Delete User",
                (
                    f"Delete user gagal untuk {username}@{proto}\n"
                    f"- Cleanup ZIVPN gagal: {zivpn_msg}\n"
                    f"- Akun belum dihapus agar bisa dicoba ulang dengan aman"
                ),
            )
        ok_del, del_msg = _ssh_delete_linux_user(username)
        if not ok_del:
            ok_rollback, rollback_msg = _ssh_delete_zivpn_rollback(username, previous_password)
            suffix = (
                f" Rollback ZIVPN: {rollback_msg}"
                if ok_rollback
                else f" Rollback ZIVPN gagal: {rollback_msg}"
            )
            return (
                False,
                "User Management - Delete User",
                f"Gagal menghapus user Linux '{username}': {del_msg}.{suffix}",
            )
        cleanup_notes = _delete_account_artifacts_checked(proto, username)
        if cleanup_notes:
            return (
                False,
                "User Management - Delete User",
                (
                    f"User Linux '{username}' sudah dihapus, tetapi cleanup artefak lokal gagal.\n- "
                    + "\n- ".join(cleanup_notes)
                ),
            )
        return True, "User Management - Delete User", f"Delete user selesai: {username}@{proto}"

    previous_credential = _find_credential_in_inbounds(proto, username) or _find_credential_from_account(proto, username)
    if not previous_credential:
        return False, "User Management - Delete User", f"Credential tidak ditemukan untuk restore {username}@{proto}"
    account_path = _resolve_existing(_account_candidates(proto, username))
    account_snapshot = None
    if account_path is not None:
        try:
            account_snapshot = account_path.read_text(encoding="utf-8")
        except Exception:
            account_snapshot = None
    ok_prev_quota, _, prev_quota_or_msg = _load_quota(proto, username)
    previous_quota = copy.deepcopy(prev_quota_or_msg) if ok_prev_quota and isinstance(prev_quota_or_msg, dict) else None

    ok_del, del_msg = _xray_delete_client(proto, username)
    if not ok_del:
        return False, "User Management - Delete User", del_msg

    cleanup_notes = _delete_account_artifacts_checked(proto, username)
    ok_remove, remove_msg = _speed_policy_remove_checked(proto, username)
    ok_sync, sync_msg = _speed_policy_sync_xray()
    apply_ok = ok_sync and _speed_policy_apply_now()
    notes: list[str] = []
    if cleanup_notes:
        notes.extend(f"cleanup artefak: {note}" for note in cleanup_notes)
    if not ok_remove:
        notes.append(f"cleanup speed policy file: {remove_msg}")
    if not ok_sync:
        notes.append(f"sync speed policy: {sync_msg}")
    elif not apply_ok:
        notes.append("apply speed policy runtime gagal (xray-speed)")
    if notes:
        ok_restore, restore_msg = _xray_restore_deleted_user(
            proto,
            username,
            credential=previous_credential,
            account_snapshot=account_snapshot,
            quota_snapshot=previous_quota,
        )
        if ok_restore:
            notes.append("rollback: user dipulihkan")
        else:
            notes.append(f"rollback gagal: {restore_msg}")
        return (
            False,
            "User Management - Delete User",
            (
                f"Delete user untuk {username}@{proto} selesai parsial.\n- "
                + "\n- ".join(notes)
            ),
        )

    return True, "User Management - Delete User", f"Delete user selesai: {username}@{proto}"


def _find_credential_from_account(proto: str, username: str) -> str:
    acc = _resolve_existing(_account_candidates(proto, username))
    if acc is None:
        return ""
    fields = _read_account_fields(acc)
    if proto == "trojan":
        return fields.get("Password", "").strip()
    return fields.get("UUID", "").strip()


def _user_exists_in_inbounds(proto: str, username: str) -> bool:
    email = _email(proto, username)
    ok, payload = _read_json(XRAY_INBOUNDS_CONF)
    if not ok or not isinstance(payload, dict):
        return False
    inbounds = payload.get("inbounds", [])
    if not isinstance(inbounds, list):
        return False
    for ib in inbounds:
        if not _inbound_matches_proto(ib, proto):
            continue
        clients = (ib.get("settings") or {}).get("clients")
        if not isinstance(clients, list):
            continue
        for c in clients:
            if isinstance(c, dict) and str(c.get("email") or "") == email:
                return True
    return False


@_user_data_mutation_locked
def op_user_extend_expiry(proto: str, username: str, mode: str, value: str) -> tuple[bool, str, str]:
    if proto not in USER_PROTOCOLS:
        return False, "User Management - Extend Expiry", f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "User Management - Extend Expiry", "Username SSH tidak valid."
    elif not _is_valid_username(username):
        return False, "User Management - Extend Expiry", "Username tidak valid."

    if proto == SSH_PROTOCOL:
        if not _linux_user_exists(username):
            return False, "User Management - Extend Expiry", f"User Linux '{username}' tidak ditemukan."

        ok_state, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_state:
            return False, "User Management - Extend Expiry", str(q_path_or_msg)
        quota_path = q_path_or_msg
        quota_data = q_data_or_msg
        assert isinstance(quota_path, Path)
        assert isinstance(quota_data, dict)
        previous_payload = copy.deepcopy(quota_data)

        current_expiry = str(quota_data.get("expired_at") or "").strip()[:10]
        today = date.today()
        mode_n = str(mode or "").strip().lower()
        if mode_n in {"extend", "tambah", "days", "1"}:
            add_days = _to_int(value, 0)
            if add_days <= 0:
                return False, "User Management - Extend Expiry", "Nilai extend harus angka hari > 0."
            base = _parse_date_only(current_expiry) or today
            if base < today:
                base = today
            new_expiry = (base + timedelta(days=add_days)).strftime("%Y-%m-%d")
        elif mode_n in {"set", "date", "2"}:
            d = _parse_date_only(value)
            if d is None:
                return False, "User Management - Extend Expiry", "Format tanggal harus YYYY-MM-DD."
            new_expiry = d.strftime("%Y-%m-%d")
        else:
            return False, "User Management - Extend Expiry", "Mode harus extend atau set."

        ok_expiry, out_expiry = _ssh_apply_linux_expiry(username, new_expiry)
        if not ok_expiry:
            return False, "User Management - Extend Expiry", f"Gagal update expiry untuk '{username}': {out_expiry}"

        quota_data["expired_at"] = new_expiry
        try:
            _ssh_save_state(quota_path, quota_data)
        except Exception as exc:
            ok_rollback, rollback_msg = _ssh_expiry_update_rollback(
                username,
                current_expiry,
                quota_path,
                previous_payload,
            )
            suffix = f" Rollback: {rollback_msg}" if ok_rollback else f" Rollback gagal: {rollback_msg}"
            return (
                False,
                "User Management - Extend Expiry",
                f"Gagal menyimpan metadata expiry untuk '{username}': {exc}.{suffix}",
            )
        ok_refresh, refresh_msg = _ssh_refresh_account_info(username)
        if not ok_refresh:
            ok_rollback, rollback_msg = _ssh_expiry_update_rollback(
                username,
                current_expiry,
                quota_path,
                previous_payload,
            )
            suffix = f" Rollback: {rollback_msg}" if ok_rollback else f" Rollback gagal: {rollback_msg}"
            return (
                False,
                "User Management - Extend Expiry",
                f"Gagal sinkron SSH ACCOUNT INFO untuk '{username}': {refresh_msg}.{suffix}",
            )
        return (
            True,
            "User Management - Extend Expiry",
            f"Expiry diperbarui: {username}@{proto}\n- Lama: {current_expiry or '-'}\n- Baru: {new_expiry}",
        )

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "User Management - Extend Expiry", str(q_path_or_msg)
    quota_path = q_path_or_msg
    quota_data = q_data_or_msg
    assert isinstance(quota_path, Path)
    assert isinstance(quota_data, dict)

    current_expiry = str(quota_data.get("expired_at") or "").strip()[:10]
    today = date.today()

    mode_n = str(mode or "").strip().lower()
    if mode_n in {"extend", "tambah", "days", "1"}:
        add_days = _to_int(value, 0)
        if add_days <= 0:
            return False, "User Management - Extend Expiry", "Nilai extend harus angka hari > 0."
        base = _parse_date_only(current_expiry) or today
        if base < today:
            base = today
        new_expiry = (base + timedelta(days=add_days)).strftime("%Y-%m-%d")
    elif mode_n in {"set", "date", "2"}:
        d = _parse_date_only(value)
        if d is None:
            return False, "User Management - Extend Expiry", "Format tanggal harus YYYY-MM-DD."
        new_expiry = d.strftime("%Y-%m-%d")
    else:
        return False, "User Management - Extend Expiry", "Mode harus extend atau set."

    previous_payload = copy.deepcopy(quota_data)
    quota_data["expired_at"] = new_expiry
    status = quota_data.get("status") if isinstance(quota_data.get("status"), dict) else {}

    st_quota = bool(status.get("quota_exhausted"))
    st_manual = bool(status.get("manual_block"))
    st_iplocked = bool(status.get("ip_limit_locked"))

    if st_quota:
        status["quota_exhausted"] = False

    _status_apply_lock_fields(status)
    quota_data["status"] = status

    ensure_credential = ""
    if not _user_exists_in_inbounds(proto, username):
        ensure_credential = _find_credential_from_account(proto, username)
        if not ensure_credential:
            return False, "User Management - Extend Expiry", f"Credential tidak ditemukan untuk restore {username}@{proto}"

    return _xray_apply_quota_update(
        "User Management - Extend Expiry",
        proto,
        username,
        quota_path,
        previous_payload,
        quota_data,
        f"Expiry diperbarui: {username}@{proto}\n- Lama: {current_expiry or '-'}\n- Baru: {new_expiry}",
        ensure_client_credential=ensure_credential,
        restore_markers=True,
        restart_limit_ip=True,
    )


@_user_data_mutation_locked
def op_ssh_reset_password(username: str, password: str) -> tuple[bool, str, str]:
    title = "User Management - Reset Password"
    if not _is_valid_ssh_username(username):
        return False, title, "Username SSH tidak valid."
    raw_password = str(password or "")
    if not raw_password.strip():
        return False, title, "Password SSH wajib diisi."
    if username.strip().lower() == raw_password.strip().lower():
        return False, title, "Password SSH tidak boleh sama dengan username."
    if not _linux_user_exists(username):
        return False, title, f"User Linux '{username}' tidak ditemukan."
    previous_password = _ssh_previous_password(username)
    if not previous_password or previous_password == "-":
        return False, title, (
            f"Password lama untuk '{username}' tidak tersedia, jadi rollback aman tidak bisa dijamin."
        )

    ok_passwd, out_passwd = _run_cmd(
        ["bash", "-lc", 'printf "%s:%s\\n" "$0" "$1" | chpasswd', username, raw_password],
        timeout=20,
    )
    if not ok_passwd:
        return False, title, f"Gagal reset password user '{username}': {out_passwd}"

    ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=raw_password)
    if not ok_refresh:
        ok_rollback, rollback_msg = _ssh_password_reset_rollback(username, previous_password)
        suffix = f" Rollback: {rollback_msg}" if ok_rollback else f" Rollback gagal: {rollback_msg}"
        return False, title, f"Gagal sinkron SSH ACCOUNT INFO untuk '{username}': {refresh_msg}.{suffix}"

    ok_zivpn, zivpn_msg = _zivpn_sync_user_password(username, raw_password)
    if not ok_zivpn:
        ok_rollback, rollback_msg = _ssh_password_reset_rollback(username, previous_password)
        suffix = f" Rollback: {rollback_msg}" if ok_rollback else f" Rollback gagal: {rollback_msg}"
        return False, title, f"Gagal sinkronisasi ZIVPN untuk '{username}': {zivpn_msg}.{suffix}"
    ok_refresh, refresh_msg = _ssh_refresh_account_info(username, password_override=raw_password)
    if not ok_refresh:
        ok_rollback, rollback_msg = _ssh_password_reset_rollback(username, previous_password)
        suffix = f" Rollback: {rollback_msg}" if ok_rollback else f" Rollback gagal: {rollback_msg}"
        return False, title, f"Gagal refresh SSH ACCOUNT INFO final untuk '{username}': {refresh_msg}.{suffix}"

    warnings: list[str] = []
    ok_enforce, enforce_msg = _ssh_run_enforcer()
    if not ok_enforce:
        warnings.append(f"enforcer: {enforce_msg}")
    msg = f"Password berhasil direset untuk {username}@{SSH_PROTOCOL}"
    if warnings:
        msg += "\n- Warning: " + " | ".join(warnings)
    return True, title, msg


def op_quota_set_limit(proto: str, username: str, quota_gb: float) -> tuple[bool, str, str]:
    if proto not in USER_PROTOCOLS:
        return False, "Quota - Set Limit", f"Proto tidak valid: {proto}"
    if proto == SSH_PROTOCOL:
        if not _is_valid_ssh_username(username):
            return False, "Quota - Set Limit", "Username SSH tidak valid"
    elif not _is_valid_username(username):
        return False, "Quota - Set Limit", "Username tidak valid"
    if quota_gb <= 0:
        return False, "Quota - Set Limit", "Quota harus > 0 GB"

    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Set Limit", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        q_data["quota_limit"] = int(round(quota_gb * (1024**3)))
        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        _status_apply_lock_fields(status)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - Set Limit", (
                f"Quota limit gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"Quota limit diubah ke {_fmt_number(quota_gb)} GB untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Set Limit", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Set Limit", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    q_data["quota_limit"] = int(round(quota_gb * (1024**3)))
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    _status_apply_lock_fields(st)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Set Limit",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Quota limit diubah ke {_fmt_number(quota_gb)} GB untuk {username}@{proto}",
        restore_markers=True,
    )


def op_quota_reset_used(proto: str, username: str) -> tuple[bool, str, str]:
    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Reset Used", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        q_data["quota_used"] = 0
        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["quota_exhausted"] = False
        _status_apply_lock_fields(status)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - Reset Used", (
                f"Reset quota gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"Quota used di-reset untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Reset Used", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Reset Used", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    q_data["quota_used"] = 0
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["quota_exhausted"] = False
    _status_apply_lock_fields(st)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Reset Used",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Quota used di-reset untuk {username}@{proto}",
        restore_markers=True,
    )


def op_quota_manual_block(proto: str, username: str, enabled: bool) -> tuple[bool, str, str]:
    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Manual Block", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["manual_block"] = bool(enabled)
        _status_apply_lock_fields(status)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - Manual Block", (
                f"Manual block {'ON' if enabled else 'OFF'} gagal diterapkan untuk "
                f"{username}@{proto}: {apply_error}"
            )
        msg = f"Manual block {'ON' if enabled else 'OFF'} untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Manual Block", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Manual Block", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["manual_block"] = bool(enabled)
    _status_apply_lock_fields(st)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Manual Block",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Manual block {'ON' if enabled else 'OFF'} untuk {username}@{proto}",
        restore_markers=True,
    )


def op_quota_ip_limit_enable(proto: str, username: str, enabled: bool) -> tuple[bool, str, str]:
    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - IP Limit", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["ip_limit_enabled"] = bool(enabled)
        if not enabled:
            status["ip_limit_locked"] = False
        _status_apply_lock_fields(status)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - IP Limit", (
                f"IP/Login limit {'ON' if enabled else 'OFF'} gagal diterapkan untuk "
                f"{username}@{proto}: {apply_error}"
            )
        msg = f"IP/Login limit {'ON' if enabled else 'OFF'} untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - IP Limit", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - IP Limit", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["ip_limit_enabled"] = bool(enabled)
    if not enabled:
        st["ip_limit_locked"] = False
    _status_apply_lock_fields(st)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - IP Limit",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"IP limit {'ON' if enabled else 'OFF'} untuk {username}@{proto}",
        restore_markers=True,
        restart_limit_ip=True,
    )


def op_quota_set_ip_limit(proto: str, username: str, limit: int) -> tuple[bool, str, str]:
    if limit <= 0:
        return False, "Quota - Set IP Limit", "IP limit harus > 0"

    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Set IP Limit", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["ip_limit"] = int(limit)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - Set IP Limit", (
                f"IP/Login limit gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"IP/Login limit diubah ke {limit} untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Set IP Limit", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Set IP Limit", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["ip_limit"] = int(limit)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Set IP Limit",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"IP limit diubah ke {limit} untuk {username}@{proto}",
        restore_markers=True,
        restart_limit_ip=True,
    )


def op_quota_unlock_ip_lock(proto: str, username: str) -> tuple[bool, str, str]:
    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Unlock IP Lock", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["ip_limit_locked"] = False
        _status_apply_lock_fields(status)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_enforcer=True,
        )
        if not ok_apply:
            return False, "Quota - Unlock IP Lock", (
                f"IP/Login unlock gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"IP/Login lock di-unlock untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Unlock IP Lock", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Unlock IP Lock", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    email = _email(proto, username)
    previous_payload = copy.deepcopy(q_data)
    if Path("/usr/local/bin/limit-ip").exists():
        ok_unlock, unlock_msg = _run_cmd(["/usr/local/bin/limit-ip", "unlock", email], timeout=15)
        if not ok_unlock:
            return False, "Quota - Unlock IP Lock", unlock_msg

    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["ip_limit_locked"] = False
    _status_apply_lock_fields(st)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Unlock IP Lock",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"IP lock di-unlock untuk {username}@{proto}",
        restore_markers=True,
        restart_limit_ip=True,
    )


def op_quota_set_speed_down(proto: str, username: str, speed_down: float) -> tuple[bool, str, str]:
    if speed_down <= 0:
        return False, "Quota - Speed Download", "Speed download harus > 0"

    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Speed Download", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["speed_down_mbit"] = float(speed_down)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_account_info=True,
        )
        if not ok_apply:
            return False, "Quota - Speed Download", (
                f"Speed download gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"Speed download diubah ke {_fmt_number(speed_down)} Mbps untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Speed Download", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Speed Download", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["speed_down_mbit"] = float(speed_down)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Speed Download",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Speed download diubah ke {_fmt_number(speed_down)} Mbps untuk {username}@{proto}",
        sync_speed=bool(st.get("speed_limit_enabled")),
    )


def op_quota_set_speed_up(proto: str, username: str, speed_up: float) -> tuple[bool, str, str]:
    if speed_up <= 0:
        return False, "Quota - Speed Upload", "Speed upload harus > 0"

    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Speed Upload", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["speed_up_mbit"] = float(speed_up)
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_account_info=True,
        )
        if not ok_apply:
            return False, "Quota - Speed Upload", (
                f"Speed upload gagal diterapkan untuk {username}@{proto}: {apply_error}"
            )
        msg = f"Speed upload diubah ke {_fmt_number(speed_up)} Mbps untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Speed Upload", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Speed Upload", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["speed_up_mbit"] = float(speed_up)
    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Speed Upload",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Speed upload diubah ke {_fmt_number(speed_up)} Mbps untuk {username}@{proto}",
        sync_speed=bool(st.get("speed_limit_enabled")),
    )


def op_quota_speed_limit(proto: str, username: str, enabled: bool) -> tuple[bool, str, str]:
    if proto == SSH_PROTOCOL:
        ok_q, q_path_or_msg, q_data_or_msg = _ssh_load_state(username)
        if not ok_q:
            return False, "Quota - Speed Limit", str(q_path_or_msg)
        q_path = q_path_or_msg
        q_data = q_data_or_msg
        assert isinstance(q_path, Path)
        assert isinstance(q_data, dict)
        previous_payload = copy.deepcopy(q_data)

        status = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
        status["speed_limit_enabled"] = bool(enabled)
        if enabled:
            down = _to_float(status.get("speed_down_mbit"), 0.0)
            up = _to_float(status.get("speed_up_mbit"), 0.0)
            if down <= 0 or up <= 0:
                return False, "Quota - Speed Limit", "Set speed download/upload > 0 dulu sebelum ON."
        q_data["status"] = status
        ok_apply, warnings, apply_error = _ssh_apply_state_update(
            username,
            q_path,
            previous_payload,
            q_data,
            require_account_info=True,
        )
        if not ok_apply:
            return False, "Quota - Speed Limit", (
                f"Speed limit {'ON' if enabled else 'OFF'} gagal diterapkan untuk "
                f"{username}@{proto}: {apply_error}"
            )
        msg = f"Speed limit {'ON' if enabled else 'OFF'} untuk {username}@{proto}"
        if warnings:
            msg += "\n- Warning: " + " | ".join(warnings)
        return True, "Quota - Speed Limit", msg

    ok_q, q_path_or_msg, q_data_or_msg = _load_quota(proto, username)
    if not ok_q:
        return False, "Quota - Speed Limit", str(q_path_or_msg)
    q_path = q_path_or_msg
    q_data = q_data_or_msg
    assert isinstance(q_path, Path)
    assert isinstance(q_data, dict)

    previous_payload = copy.deepcopy(q_data)
    st = q_data.get("status") if isinstance(q_data.get("status"), dict) else {}
    st["speed_limit_enabled"] = bool(enabled)

    if enabled:
        down = _to_float(st.get("speed_down_mbit"), 0.0)
        up = _to_float(st.get("speed_up_mbit"), 0.0)
        if down <= 0 or up <= 0:
            return False, "Quota - Speed Limit", "Set speed download/upload > 0 dulu sebelum ON."

    q_data["status"] = st
    return _xray_apply_quota_update(
        "Quota - Speed Limit",
        proto,
        username,
        q_path,
        previous_payload,
        q_data,
        f"Speed limit {'ON' if enabled else 'OFF'} untuk {username}@{proto}",
        sync_speed=True,
    )


def _normalize_domain(domain: str) -> str:
    return str(domain or "").strip().lower()


def _rollback_nginx_domain_change(original: str) -> tuple[bool, str]:
    notes: list[str] = []
    try:
        _write_text_atomic(NGINX_CONF, original)
    except Exception as exc:
        notes.append(f"restore config nginx gagal: {exc}")
    else:
        ok_test, out_test = _run_cmd(["nginx", "-t"], timeout=20)
        if not ok_test:
            notes.append(f"nginx -t gagal saat rollback domain:\n{out_test}")
        elif not _restart_and_wait("nginx", timeout_sec=20):
            notes.append("nginx gagal restart saat rollback domain.")
    if notes:
        return False, "\n".join(notes)
    return True, "ok"


def _apply_nginx_domain(domain: str) -> tuple[bool, str]:
    if not NGINX_CONF.exists():
        return False, f"Nginx conf tidak ditemukan: {NGINX_CONF}"

    original = NGINX_CONF.read_text(encoding="utf-8", errors="ignore")
    changed = False
    out_lines: list[str] = []

    for line in original.splitlines():
        if re.match(r"^\s*server_name\s+", line):
            indent = re.match(r"^(\s*)", line).group(1) if re.match(r"^(\s*)", line) else ""
            out_lines.append(f"{indent}server_name {domain};")
            changed = True
        else:
            out_lines.append(line)

    if not changed:
        return False, "Baris server_name tidak ditemukan di nginx config"

    candidate = "\n".join(out_lines) + "\n"

    try:
        _write_text_atomic(NGINX_CONF, candidate)
        ok_test, out_test = _run_cmd(["nginx", "-t"], timeout=20)
        if not ok_test:
            ok_rb, msg_rb = _rollback_nginx_domain_change(original)
            if ok_rb:
                return False, f"nginx -t gagal setelah ubah domain:\n{out_test}\nPerubahan nginx sudah di-rollback."
            return False, f"nginx -t gagal setelah ubah domain:\n{out_test}\nRollback nginx gagal:\n{msg_rb}"

        if not _restart_and_wait("nginx", timeout_sec=20):
            ok_rb, msg_rb = _rollback_nginx_domain_change(original)
            if ok_rb:
                return False, "nginx gagal restart setelah ubah domain. Perubahan nginx sudah di-rollback."
            return False, f"nginx gagal restart setelah ubah domain.\nRollback nginx gagal:\n{msg_rb}"
    except Exception as exc:
        ok_rb, msg_rb = _rollback_nginx_domain_change(original)
        if ok_rb:
            return False, f"Gagal apply domain ke nginx: {exc}\nPerubahan nginx sudah di-rollback."
        return False, f"Gagal apply domain ke nginx: {exc}\nRollback nginx gagal:\n{msg_rb}"

    # Keep compatibility with compatibility scripts that still read active domain from /etc/xray/domain.
    try:
        XRAY_DOMAIN_FILE.parent.mkdir(parents=True, exist_ok=True)
        _write_text_atomic(XRAY_DOMAIN_FILE, f"{domain}\n")
    except Exception as exc:
        ok_rb, msg_rb = _rollback_nginx_domain_change(original)
        if ok_rb:
            return False, (
                f"Gagal sinkron domain kompatibilitas ke {XRAY_DOMAIN_FILE}: {exc}\n"
                "Perubahan nginx sudah di-rollback."
            )
        return False, f"Gagal sinkron domain kompatibilitas ke {XRAY_DOMAIN_FILE}: {exc}\nRollback nginx gagal:\n{msg_rb}"

    return True, "ok"


def _snapshot_optional_file(path: Path) -> dict[str, Any]:
    if not path.exists() or not path.is_file():
        return {"exists": False}
    try:
        st = path.stat()
        return {
            "exists": True,
            "payload": path.read_bytes(),
            "mode": int(st.st_mode & 0o777),
        }
    except Exception:
        return {"exists": False}


def _restore_optional_file(path: Path, snapshot: dict[str, Any]) -> tuple[bool, str]:
    try:
        if bool(snapshot.get("exists")):
            ok_write, msg_write = _write_bytes_atomic(path, bytes(snapshot.get("payload") or b""))
            if not ok_write:
                return False, msg_write
            mode = snapshot.get("mode")
            if isinstance(mode, int):
                try:
                    os.chmod(path, mode)
                except Exception:
                    pass
        elif path.exists():
            path.unlink()
    except Exception as exc:
        return False, f"Gagal restore file {path}: {exc}"
    return True, "ok"


def _capture_domain_runtime_snapshot() -> dict[str, Any]:
    edge_service = _edge_runtime_service_name().strip()
    if edge_service == "nginx":
        edge_service = ""
    return {
        "nginx_conf": _snapshot_optional_file(NGINX_CONF),
        "compat_domain": _snapshot_optional_file(XRAY_DOMAIN_FILE),
        "cert_fullchain": _snapshot_optional_file(CERT_FULLCHAIN),
        "cert_privkey": _snapshot_optional_file(CERT_PRIVKEY),
        "nginx_was_active": _service_exists("nginx") and _service_is_active("nginx"),
        "sshws_stunnel_was_active": _service_exists("sshws-stunnel") and _service_is_active("sshws-stunnel"),
        "edge_service_name": edge_service,
        "edge_service_was_active": bool(
            edge_service and _service_exists(edge_service) and _service_is_active(edge_service)
        ),
    }


def _capture_xray_network_runtime_snapshot() -> dict[str, Any]:
    return {
        "routing": _snapshot_optional_file(XRAY_ROUTING_CONF),
        "outbounds": _snapshot_optional_file(XRAY_OUTBOUNDS_CONF),
    }


def _restore_xray_network_runtime_snapshot(snapshot: dict[str, Any]) -> tuple[bool, str]:
    failures: list[str] = []
    for path, key in (
        (XRAY_ROUTING_CONF, "routing"),
        (XRAY_OUTBOUNDS_CONF, "outbounds"),
    ):
        entry = snapshot.get(key)
        if not isinstance(entry, dict):
            continue
        ok_restore, msg_restore = _restore_optional_file(path, entry)
        if not ok_restore:
            failures.append(msg_restore)
    if failures:
        return False, " | ".join(failures)
    if not _restart_and_wait("xray", timeout_sec=20):
        return False, "xray gagal restart saat rollback network controls."
    return True, "ok"


def _domain_snapshot_active_domain(snapshot: dict[str, Any]) -> str:
    compat = snapshot.get("compat_domain")
    if isinstance(compat, dict) and compat.get("exists"):
        try:
            value = bytes(compat.get("payload") or b"").decode("utf-8", errors="ignore").strip()
        except Exception:
            value = ""
        if DOMAIN_RE.match(value):
            return value

    nginx_conf = snapshot.get("nginx_conf")
    if isinstance(nginx_conf, dict) and nginx_conf.get("exists"):
        try:
            text = bytes(nginx_conf.get("payload") or b"").decode("utf-8", errors="ignore")
        except Exception:
            text = ""
        for line in text.splitlines():
            m = re.match(r"^\s*server_name\s+([^;]+);", line)
            if not m:
                continue
            domain = m.group(1).strip().split()[0]
            if DOMAIN_RE.match(domain):
                return domain
    return ""


def _restore_domain_runtime_snapshot(
    snapshot: dict[str, Any],
    skipped_services: set[str] | None = None,
) -> tuple[bool, str]:
    failures: list[str] = []
    for path, key in (
        (CERT_FULLCHAIN, "cert_fullchain"),
        (CERT_PRIVKEY, "cert_privkey"),
        (XRAY_DOMAIN_FILE, "compat_domain"),
        (NGINX_CONF, "nginx_conf"),
    ):
        entry = snapshot.get(key)
        if not isinstance(entry, dict):
            continue
        ok_restore, msg_restore = _restore_optional_file(path, entry)
        if not ok_restore:
            failures.append(msg_restore)

    if failures:
        return False, " | ".join(failures)

    ok_test, out_test = _run_cmd(["nginx", "-t"], timeout=20)
    if not ok_test:
        return False, f"nginx -t gagal saat rollback domain:\n{out_test}"
    if bool(snapshot.get("nginx_was_active")):
        if not _restart_and_wait("nginx", timeout_sec=20):
            return False, "nginx gagal restart saat rollback domain."
    elif _service_exists("nginx") and _service_is_active("nginx"):
        if not _stop_and_wait_inactive("nginx", timeout_sec=20):
            return False, "nginx gagal dikembalikan ke state inactive saat rollback domain."
    ok_tls, msg_tls = _restore_tls_runtime_consumers_from_snapshot(snapshot, skipped_services or set())
    if not ok_tls:
        return False, f"Rollback domain selesai, tetapi restart consumer TLS gagal:\n{msg_tls}"
    return True, "ok"


def _parse_bool_text(raw: Any, default: bool = False) -> bool:
    if isinstance(raw, bool):
        return raw
    text = str(raw or "").strip().lower()
    if text in {"1", "true", "yes", "y", "on", "aktif", "enable", "enabled"}:
        return True
    if text in {"0", "false", "no", "n", "off", "nonaktif", "disable", "disabled"}:
        return False
    return default


def _download_file(url: str, dest: Path, timeout: int = 60) -> tuple[bool, str]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = resp.read()
        ok_write, msg_write = _write_bytes_atomic(dest, data)
        if not ok_write:
            return False, msg_write
        if url.endswith(".sh"):
            try:
                os.chmod(dest, 0o700)
            except Exception:
                pass
        return True, "ok"
    except Exception as exc:
        return False, f"Gagal download {url}: {exc}"


def _rand_email() -> str:
    return f"admin{random.randint(1000, 9999)}@gmail.com"


def _acme_path() -> Path:
    return Path("/root/.acme.sh/acme.sh")


def _ensure_acme_installed() -> tuple[bool, str]:
    acme = _acme_path()
    if acme.exists():
        _run_cmd([str(acme), "--set-default-ca", "--server", "letsencrypt"], timeout=30)
        return True, "ok"

    account_email = _rand_email()
    tmpdir = Path(tempfile.mkdtemp(prefix="acme-install-"))
    src_dir: Path | None = None
    try:
        tgz = tmpdir / "acme.tar.gz"
        ok_dl, _ = _download_file(
            ACME_SH_TARBALL_URL,
            tgz,
            timeout=120,
        )
        if ok_dl:
            ok_extract, msg_extract = _safe_extract_tarball(tgz, tmpdir)
            if not ok_extract:
                return False, msg_extract
            for d in tmpdir.iterdir():
                if d.is_dir() and d.name.startswith("acme.sh-"):
                    src_dir = d
                    break

        if src_dir is None:
            src_dir = tmpdir / "acme-single"
            src_dir.mkdir(parents=True, exist_ok=True)
            ok_script, msg_script = _download_file(
                ACME_SH_SCRIPT_URL,
                src_dir / "acme.sh",
                timeout=120,
            )
            if not ok_script:
                return False, msg_script

        script = src_dir / "acme.sh"
        if not script.exists():
            return False, "acme.sh script tidak ditemukan setelah download."
        try:
            os.chmod(script, 0o700)
        except Exception:
            pass

        ok_install, out_install = _run_cmd(
            ["bash", str(script), "--install", "--home", "/root/.acme.sh", "--accountemail", account_email],
            timeout=240,
            cwd=str(src_dir),
        )
        if not ok_install:
            return False, f"Install acme.sh gagal:\n{out_install}"

        if not acme.exists():
            return False, "acme.sh tidak ditemukan setelah install."

        _run_cmd([str(acme), "--set-default-ca", "--server", "letsencrypt"], timeout=30)
        return True, "ok"
    finally:
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass


def _ensure_dns_cf_hook() -> tuple[bool, str]:
    hook = Path("/root/.acme.sh/dnsapi/dns_cf.sh")
    if hook.exists() and hook.stat().st_size > 0:
        return True, "ok"
    hook.parent.mkdir(parents=True, exist_ok=True)
    ok_dl, msg_dl = _download_file(
        ACME_SH_DNS_CF_HOOK_URL,
        hook,
        timeout=120,
    )
    if not ok_dl:
        return False, msg_dl
    try:
        os.chmod(hook, 0o700)
    except Exception:
        pass
    if not hook.exists() or hook.stat().st_size <= 0:
        return False, "Hook dns_cf tetap tidak ditemukan setelah bootstrap."
    return True, "ok"


def _stop_conflicting_services() -> tuple[list[str], list[str]]:
    stopped: list[str] = []
    failures: list[str] = []
    for svc in ("nginx", "apache2", "caddy", "lighttpd"):
        if not (_service_exists(svc) and _service_is_active(svc)):
            continue
        ok_stop, out_stop = _run_cmd(["systemctl", "stop", svc], timeout=25)
        if not ok_stop:
            failures.append(f"{svc}: {out_stop}")
            continue
        if _service_is_active(svc):
            failures.append(f"{svc}: masih aktif setelah stop")
            continue
        stopped.append(svc)
    edge_svc = _edge_runtime_service_name()
    if (
        _edge_runtime_uses_public_http_port_80()
        and edge_svc
        and edge_svc != "nginx"
        and _service_exists(edge_svc)
        and _service_is_active(edge_svc)
    ):
        ok_stop, out_stop = _run_cmd(["systemctl", "stop", edge_svc], timeout=25)
        if not ok_stop:
            failures.append(f"{edge_svc}: {out_stop}")
        elif _service_is_active(edge_svc):
            failures.append(f"{edge_svc}: masih aktif setelah stop")
        else:
            stopped.append(edge_svc)
    return stopped, failures


def _restore_services(services: list[str]) -> list[str]:
    failures: list[str] = []
    for svc in services:
        if not _service_exists(svc):
            failures.append(f"{svc}: service tidak ditemukan saat restore")
            continue
        ok_start, out_start = _run_cmd(["systemctl", "start", svc], timeout=25)
        if not ok_start:
            failures.append(f"{svc}: {out_start}")
            continue
        if not _service_is_active(svc):
            failures.append(f"{svc}: inactive setelah start")
    return failures


def _restart_tls_runtime_consumers(skipped_services: set[str] | None = None) -> tuple[bool, str]:
    skipped = skipped_services or set()
    targets = ["sshws-stunnel"]
    edge_svc = _edge_runtime_service_name()
    if edge_svc and edge_svc != "nginx":
        targets.append(edge_svc)

    failures: list[str] = []
    for svc in targets:
        if svc in skipped:
            continue
        if not _service_exists(svc) or not _service_is_active(svc):
            continue
        ok_reload, out_reload = _run_cmd(["systemctl", "reload", svc], timeout=30)
        if not ok_reload:
            ok_reload, out_reload = _run_cmd(["systemctl", "restart", svc], timeout=30)
        if not ok_reload or not _service_is_active(svc):
            failures.append(f"{svc}: {out_reload}")
    if failures:
        return False, "\n".join(failures)
    return True, "ok"


def _restore_tls_runtime_consumers_from_snapshot(
    snapshot: dict[str, Any],
    skipped_services: set[str] | None = None,
) -> tuple[bool, str]:
    skipped = skipped_services or set()
    failures: list[str] = []
    targets: list[tuple[str, bool]] = [
        ("sshws-stunnel", bool(snapshot.get("sshws_stunnel_was_active"))),
    ]
    edge_service = str(snapshot.get("edge_service_name") or "").strip()
    if edge_service and edge_service not in {"nginx", "sshws-stunnel"}:
        targets.append((edge_service, bool(snapshot.get("edge_service_was_active"))))

    for svc, should_be_active in targets:
        if svc in skipped:
            continue
        if should_be_active:
            if not _service_exists(svc):
                failures.append(f"{svc}: service tidak ditemukan saat rollback")
                continue
            ok_reload, out_reload = _run_cmd(["systemctl", "reload", svc], timeout=30)
            if not ok_reload:
                ok_reload, out_reload = _run_cmd(["systemctl", "restart", svc], timeout=30)
            if not ok_reload or not _service_is_active(svc):
                failures.append(f"{svc}: {out_reload}")
        elif _service_exists(svc) and _service_is_active(svc):
            if not _stop_and_wait_inactive(svc, timeout_sec=30):
                failures.append(f"{svc}: gagal dikembalikan ke inactive")

    if failures:
        return False, "\n".join(failures)
    return True, "ok"


def _cf_api(method: str, endpoint: str, payload: dict[str, Any] | None = None) -> tuple[bool, dict[str, Any] | str]:
    token = CLOUDFLARE_API_TOKEN.strip()
    if not token:
        return False, "CLOUDFLARE_API_TOKEN belum di-set."

    url = f"https://api.cloudflare.com/client/v4{endpoint}"
    data_bytes = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(
        url,
        data=data_bytes,
        method=method.upper(),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )

    body_text = ""
    status = 0
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = int(resp.getcode() or 0)
            body_text = resp.read().decode("utf-8", errors="ignore")
    except urllib.error.HTTPError as exc:
        status = int(exc.code or 0)
        try:
            body_text = exc.read().decode("utf-8", errors="ignore")
        except Exception:
            body_text = str(exc)
    except Exception as exc:
        return False, f"Gagal call Cloudflare API: {exc}"

    if not body_text.strip():
        return False, f"Cloudflare API empty response (HTTP {status or '?'}) for {endpoint}"

    try:
        parsed = json.loads(body_text)
    except Exception:
        return False, f"Cloudflare API non-JSON response (HTTP {status or '?'}) for {endpoint}:\n{body_text}"

    if not (200 <= status < 300):
        return False, f"Cloudflare API HTTP {status} for {endpoint}: {body_text}"

    if not bool(parsed.get("success", False)):
        errs = parsed.get("errors")
        if isinstance(errs, list) and errs:
            msg = "; ".join(str(e.get("message") or e) for e in errs if isinstance(e, dict) or isinstance(e, str))
            if msg:
                return False, f"Cloudflare API error: {msg}"
        return False, f"Cloudflare API success=false untuk endpoint {endpoint}"

    return True, parsed


def _cf_get_zone_id_by_name(zone_name: str) -> tuple[bool, str]:
    endpoint = f"/zones?name={urllib.parse.quote(zone_name)}&per_page=1"
    ok, res = _cf_api("GET", endpoint)
    if not ok:
        return False, str(res)
    payload = res if isinstance(res, dict) else {}
    result = payload.get("result")
    if not isinstance(result, list) or not result:
        return False, f"Zone Cloudflare tidak ditemukan: {zone_name}"
    zid = str((result[0] or {}).get("id") or "").strip()
    if not zid:
        return False, f"Zone id tidak ditemukan untuk: {zone_name}"
    return True, zid


def _cf_get_account_id_by_zone(zone_id: str) -> tuple[bool, str]:
    ok, res = _cf_api("GET", f"/zones/{zone_id}")
    if not ok:
        return False, str(res)
    payload = res if isinstance(res, dict) else {}
    account_id = str((((payload.get("result") or {}).get("account") or {}).get("id") or "")).strip()
    if not account_id:
        return False, f"CF account id tidak ditemukan untuk zone: {zone_id}"
    return True, account_id


def _cf_list_a_records_by_name(zone_id: str, fqdn: str) -> tuple[bool, list[dict[str, Any]] | str]:
    endpoint = f"/zones/{zone_id}/dns_records?type=A&name={urllib.parse.quote(fqdn)}&per_page=100"
    ok, res = _cf_api("GET", endpoint)
    if not ok:
        return False, str(res)
    payload = res if isinstance(res, dict) else {}
    result = payload.get("result")
    if not isinstance(result, list):
        return True, []
    out: list[dict[str, Any]] = []
    for item in result:
        if isinstance(item, dict):
            out.append(item)
    return True, out


def _cf_list_a_records_by_ip(zone_id: str, ip: str) -> tuple[bool, list[dict[str, Any]] | str]:
    endpoint = f"/zones/{zone_id}/dns_records?type=A&content={urllib.parse.quote(ip)}&per_page=100"
    ok, res = _cf_api("GET", endpoint)
    if not ok:
        return False, str(res)
    payload = res if isinstance(res, dict) else {}
    result = payload.get("result")
    if not isinstance(result, list):
        return True, []
    out: list[dict[str, Any]] = []
    for item in result:
        if isinstance(item, dict):
            out.append(item)
    return True, out


def _cf_delete_record(zone_id: str, record_id: str) -> tuple[bool, str]:
    ok, res = _cf_api("DELETE", f"/zones/{zone_id}/dns_records/{record_id}")
    if not ok:
        return False, str(res)
    return True, "ok"


def _cf_create_a_record(zone_id: str, name: str, ip: str, proxied: bool = False) -> tuple[bool, str]:
    payload = {
        "type": "A",
        "name": name,
        "content": ip,
        "ttl": 1,
        "proxied": bool(proxied),
    }
    ok, res = _cf_api("POST", f"/zones/{zone_id}/dns_records", payload=payload)
    if not ok:
        return False, str(res)
    return True, "ok"


def _gen_subdomain_random() -> str:
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(5))


def _validate_subdomain(subdomain: str) -> bool:
    s = str(subdomain or "").strip()
    if not s:
        return False
    if s != s.lower():
        return False
    if " " in s:
        return False
    return bool(re.match(r"^[a-z0-9]([a-z0-9.-]{0,61}[a-z0-9])?$", s))


def _resolve_root_domain_input(raw: str) -> tuple[bool, str]:
    text = str(raw or "").strip().lower()
    if not text:
        return False, "Root domain wajib diisi."
    if text.isdigit():
        idx = int(text)
        if 1 <= idx <= len(PROVIDED_ROOT_DOMAINS):
            return True, PROVIDED_ROOT_DOMAINS[idx - 1]
        return False, f"Index root domain di luar range 1-{len(PROVIDED_ROOT_DOMAINS)}."
    for root in PROVIDED_ROOT_DOMAINS:
        if text == root.lower():
            return True, root
    return False, f"Root domain tidak dikenali: {raw}. Pilihan: {', '.join(PROVIDED_ROOT_DOMAINS)}"


def _cf_prepare_subdomain_a_record(
    zone_id: str,
    fqdn: str,
    ip: str,
    proxied: bool,
    allow_existing_same_ip: bool,
) -> tuple[bool, str]:
    ok_name, name_records_or_err = _cf_list_a_records_by_name(zone_id, fqdn)
    if not ok_name:
        return False, str(name_records_or_err)
    name_records = name_records_or_err if isinstance(name_records_or_err, list) else []

    rec_ips = [str(r.get("content") or "").strip() for r in name_records if isinstance(r, dict)]
    if rec_ips:
        any_same = any(v == ip for v in rec_ips)
        any_diff = any(v and v != ip for v in rec_ips)
        if any_same:
            if allow_existing_same_ip:
                return True, f"A record sudah ada dan sama: {fqdn} -> {ip}"
            return False, f"A record {fqdn} -> {ip} sudah ada. Set allow_existing_same_ip=on untuk lanjut."
        if any_diff:
            return False, f"Subdomain {fqdn} sudah ada di Cloudflare tapi IP berbeda: {', '.join(rec_ips)}"

    ok_ip, same_ip_or_err = _cf_list_a_records_by_ip(zone_id, ip)
    if not ok_ip:
        return False, str(same_ip_or_err)
    same_ip_records = same_ip_or_err if isinstance(same_ip_or_err, list) else []
    for rec in same_ip_records:
        rec_id = str(rec.get("id") or "").strip()
        rec_name = str(rec.get("name") or "").strip()
        if not rec_id or not rec_name:
            continue
        if rec_name == fqdn:
            continue
        ok_del, del_msg = _cf_delete_record(zone_id, rec_id)
        if not ok_del:
            return False, f"Gagal hapus A record historis {rec_name}: {del_msg}"

    ok_create, create_msg = _cf_create_a_record(zone_id, fqdn, ip, proxied=proxied)
    if not ok_create:
        return False, create_msg
    return True, f"DNS A record siap: {fqdn} -> {ip} (proxied={'true' if proxied else 'false'})"


def _issue_cert_dns_cf_wildcard(domain: str, root_domain: str, zone_id: str, account_id: str = "") -> tuple[bool, str]:
    ok_verify, verify_res = _cf_api("GET", "/user/tokens/verify")
    if not ok_verify:
        return False, (
            "Token Cloudflare tidak valid/kurang scope. "
            "Butuh minimal Zone:DNS Edit + Zone:Read.\n"
            f"{verify_res}"
        )

    ok_acme, acme_msg = _ensure_acme_installed()
    if not ok_acme:
        return False, acme_msg
    ok_hook, hook_msg = _ensure_dns_cf_hook()
    if not ok_hook:
        return False, hook_msg

    acme = _acme_path()
    env = os.environ.copy()
    env["CF_Token"] = CLOUDFLARE_API_TOKEN
    if account_id:
        env["CF_Account_ID"] = account_id
    if zone_id:
        env["CF_Zone_ID"] = zone_id

    ok_issue, out_issue = _run_cmd(
        [str(acme), "--issue", "--force", "--dns", "dns_cf", "-d", domain, "-d", f"*.{domain}"],
        timeout=360,
        env=env,
    )
    if not ok_issue:
        return False, f"Gagal issue sertifikat wildcard via dns_cf untuk {domain}:\n{out_issue}"

    ok_install, out_install = _run_cmd(
        [
            str(acme),
            "--install-cert",
            "-d",
            domain,
            "--key-file",
            str(CERT_PRIVKEY),
            "--fullchain-file",
            str(CERT_FULLCHAIN),
            "--reloadcmd",
            "/bin/true",
        ],
        timeout=180,
        env=env,
    )
    if not ok_install:
        return False, f"Gagal install sertifikat wildcard untuk {domain}:\n{out_install}"

    _chmod_600(CERT_PRIVKEY)
    _chmod_600(CERT_FULLCHAIN)
    return True, f"Sertifikat wildcard terpasang untuk {domain} (root: {root_domain})"


def _issue_cert_standalone(domain: str) -> tuple[bool, str]:
    ok_acme, acme_msg = _ensure_acme_installed()
    if not ok_acme:
        return False, acme_msg
    acme = _acme_path()

    CERT_DIR.mkdir(parents=True, exist_ok=True)

    ok_issue, out_issue = _run_cmd(
        [
            str(acme),
            "--issue",
            "--force",
            "--standalone",
            "-d",
            domain,
            "--httpport",
            "80",
        ],
        timeout=240,
    )
    if not ok_issue:
        return False, f"Issue cert gagal:\n{out_issue}"

    ok_install, out_install = _run_cmd(
        [
            str(acme),
            "--install-cert",
            "-d",
            domain,
            "--key-file",
            str(CERT_PRIVKEY),
            "--fullchain-file",
            str(CERT_FULLCHAIN),
            "--reloadcmd",
            "/bin/true",
        ],
        timeout=120,
    )
    if not ok_install:
        return False, f"Install cert gagal:\n{out_install}"

    _chmod_600(CERT_PRIVKEY)
    _chmod_600(CERT_FULLCHAIN)
    return True, "ok"


def _get_public_ipv4() -> tuple[bool, str]:
    for url in ("https://api.ipify.org", "https://ipv4.icanhazip.com"):
        try:
            with urllib.request.urlopen(url, timeout=6) as resp:
                text = resp.read().decode("utf-8", errors="ignore").strip()
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", text):
                return True, text
        except Exception:
            continue
    fallback = _detect_public_ipv4()
    if re.match(r"^\d+\.\d+\.\d+\.\d+$", fallback) and fallback != "0.0.0.0":
        return True, fallback
    return False, "Gagal mendapatkan public IPv4 VPS."


def _parse_subdomain_mode(raw: Any) -> str:
    text = str(raw or "").strip().lower()
    if not text:
        return "auto"
    if text in {"1", "auto", "acak", "random", "generate", "generated"}:
        return "auto"
    if text in {"2", "manual", "input", "custom"}:
        return "manual"
    return ""


def op_domain_cloudflare_root_list() -> tuple[bool, str, str]:
    lines = [f"{i + 1}. {root}" for i, root in enumerate(PROVIDED_ROOT_DOMAINS)]
    msg = "Root domain Cloudflare yang tersedia:\n" + "\n".join(lines)
    msg += "\n\nInput bisa nomor (contoh: 1) atau nama domain penuh."
    return True, "Domain Control - Root Domain List", msg


def list_provided_root_domains() -> list[str]:
    return [str(root).strip() for root in PROVIDED_ROOT_DOMAINS if str(root).strip()]


@_user_data_mutation_locked
def op_domain_setup_custom(domain: str) -> tuple[bool, str, str]:
    title = "Domain Control - Set Domain (Custom)"
    domain_n = _normalize_domain(domain)
    if not DOMAIN_RE.match(domain_n):
        return False, title, "Domain tidak valid."

    snapshot = _capture_domain_runtime_snapshot()
    previous_domain = _domain_snapshot_active_domain(snapshot)
    stopped_services, stop_failures = _stop_conflicting_services()
    completed = False
    error_msg: str | None = None
    if stop_failures:
        error_msg = "Gagal menghentikan service konflik:\n" + "\n".join(stop_failures)
    restore_failures: list[str] = []
    try:
        if error_msg is None:
            ok_cert, cert_msg = _issue_cert_standalone(domain_n)
            if not ok_cert:
                error_msg = cert_msg
            else:
                ok_ng, ng_msg = _apply_nginx_domain(domain_n)
                if not ok_ng:
                    error_msg = ng_msg
                else:
                    ok_tls, tls_msg = _restore_tls_runtime_consumers_from_snapshot(snapshot, set(stopped_services))
                    if not ok_tls:
                        error_msg = f"Restart consumer TLS gagal:\n{tls_msg}"
                    else:
                        completed = True
    except Exception as exc:
        error_msg = f"Setup domain custom gagal: {exc}"
    finally:
        # Success path: nginx sudah di-restart oleh _apply_nginx_domain, restore service lain
        # yang tadinya aktif agar state sistem kembali seperti sebelum wizard.
        if completed:
            restore_failures = _restore_services([svc for svc in stopped_services if svc != "nginx"])
        else:
            # Failure path: pastikan semua service yang sebelumnya aktif dipulihkan.
            restore_failures = _restore_services(stopped_services)
        if restore_failures:
            restore_msg = "Restore service yang sebelumnya aktif gagal:\n" + "\n".join(restore_failures)
            if error_msg:
                error_msg = f"{error_msg}\n{restore_msg}"
            else:
                error_msg = restore_msg

    if error_msg:
        ok_rb, msg_rb = _restore_domain_runtime_snapshot(snapshot)
        if ok_rb and previous_domain:
            _, rb_failed = _refresh_all_account_info(domain=previous_domain)
            if rb_failed > 0:
                return False, title, (
                    f"{error_msg}\nRollback domain berhasil, tetapi {rb_failed} ACCOUNT INFO domain lama "
                    "gagal direfresh."
                )
        if ok_rb:
            return False, title, error_msg
        return False, title, f"{error_msg}\nRollback domain gagal:\n{msg_rb}"

    ip_override: str | None = None
    ok_ip, ip_or_err = _get_public_ipv4()
    if ok_ip:
        ip_override = str(ip_or_err)
    updated, failed = _refresh_all_account_info(domain=domain_n, ip=ip_override)
    lines = [
        f"Domain aktif sekarang: {domain_n}",
        "- Certificate mode : standalone",
        f"- ACCOUNT INFO updated: {updated}",
    ]
    if failed > 0:
        lines.append(
            f"- Warning: {failed} ACCOUNT INFO gagal direfresh. Domain aktif tetap dipertahankan; jalankan refresh eksplisit bila diperlukan."
        )
    return True, title, "\n".join(lines)


@_user_data_mutation_locked
def op_domain_setup_cloudflare(
    root_domain_input: str,
    subdomain_mode: str = "auto",
    subdomain: str = "",
    proxied: Any = False,
    allow_existing_same_ip: Any = False,
) -> tuple[bool, str, str]:
    title = "Domain Control - Set Domain (Cloudflare Wizard)"
    snapshot = _capture_domain_runtime_snapshot()
    previous_domain = _domain_snapshot_active_domain(snapshot)

    ok_root, root_or_err = _resolve_root_domain_input(root_domain_input)
    if not ok_root:
        return False, title, str(root_or_err)
    root_domain = str(root_or_err)

    ok_ip, ip_or_err = _get_public_ipv4()
    if not ok_ip:
        return False, title, str(ip_or_err)
    vps_ipv4 = str(ip_or_err)

    ok_zone, zone_or_err = _cf_get_zone_id_by_name(root_domain)
    if not ok_zone:
        return False, title, str(zone_or_err)
    zone_id = str(zone_or_err)

    account_id = ""
    ok_acc, acc_or_err = _cf_get_account_id_by_zone(zone_id)
    if ok_acc:
        account_id = str(acc_or_err)

    mode = _parse_subdomain_mode(subdomain_mode)
    if not mode:
        return (
            False,
            title,
            "subdomain_mode tidak valid. Gunakan: auto/manual (atau 1/2).",
        )

    if mode == "auto":
        sub = _gen_subdomain_random()
    else:
        sub = str(subdomain or "").strip().lower()
        if not _validate_subdomain(sub):
            return (
                False,
                title,
                "Subdomain tidak valid. Hanya huruf kecil, angka, titik, dan strip (-).",
            )

    domain_final = f"{sub}.{root_domain}".lower()
    proxied_b = _parse_bool_text(proxied, default=False)
    allow_same_b = _parse_bool_text(allow_existing_same_ip, default=False)

    ok_dns, dns_msg = _cf_prepare_subdomain_a_record(
        zone_id=zone_id,
        fqdn=domain_final,
        ip=vps_ipv4,
        proxied=proxied_b,
        allow_existing_same_ip=allow_same_b,
    )
    if not ok_dns:
        return False, title, dns_msg

    stopped_services, stop_failures = _stop_conflicting_services()
    completed = False
    error_msg: str | None = None
    if stop_failures:
        error_msg = "Gagal menghentikan service konflik:\n" + "\n".join(stop_failures)
    restore_failures: list[str] = []
    try:
        if error_msg is None:
            ok_cert, cert_msg = _issue_cert_dns_cf_wildcard(
                domain=domain_final,
                root_domain=root_domain,
                zone_id=zone_id,
                account_id=account_id,
            )
            if not ok_cert:
                error_msg = cert_msg
            else:
                ok_ng, ng_msg = _apply_nginx_domain(domain_final)
                if not ok_ng:
                    error_msg = ng_msg
                else:
                    ok_tls, tls_msg = _restore_tls_runtime_consumers_from_snapshot(snapshot, set(stopped_services))
                    if not ok_tls:
                        error_msg = f"Restart consumer TLS gagal:\n{tls_msg}"
                    else:
                        completed = True
    except Exception as exc:
        error_msg = f"Setup Cloudflare wizard gagal: {exc}"
    finally:
        if completed:
            restore_failures = _restore_services([svc for svc in stopped_services if svc != "nginx"])
        else:
            restore_failures = _restore_services(stopped_services)
        if restore_failures:
            restore_msg = "Restore service yang sebelumnya aktif gagal:\n" + "\n".join(restore_failures)
            if error_msg:
                error_msg = f"{error_msg}\n{restore_msg}"
            else:
                error_msg = restore_msg

    if error_msg:
        ok_rb, msg_rb = _restore_domain_runtime_snapshot(snapshot)
        if ok_rb and previous_domain:
            _, rb_failed = _refresh_all_account_info(domain=previous_domain, ip=vps_ipv4)
            if rb_failed > 0:
                return False, title, (
                    f"{error_msg}\nRollback domain berhasil, tetapi {rb_failed} ACCOUNT INFO domain lama "
                    "gagal direfresh."
                )
        if ok_rb:
            return False, title, error_msg
        return False, title, f"{error_msg}\nRollback domain gagal:\n{msg_rb}"

    updated, failed = _refresh_all_account_info(domain=domain_final, ip=vps_ipv4)
    lines = [
        f"Domain aktif sekarang: {domain_final}",
        f"- Root domain      : {root_domain}",
        f"- Cloudflare proxy : {'ON' if proxied_b else 'OFF'}",
        f"- DNS              : {dns_msg}",
        "- Certificate mode : dns_cf wildcard",
    ]
    if not ok_acc:
        lines.append(f"- Catatan: CF_ACCOUNT_ID tidak ditemukan ({acc_or_err})")
    if failed > 0:
        lines.append(
            f"- Warning: {failed} ACCOUNT INFO gagal direfresh. Domain/DNS/certificate aktif tetap dipertahankan; jalankan refresh eksplisit bila diperlukan."
        )
    lines.append(f"- ACCOUNT INFO updated: {updated}")
    return True, title, "\n".join(lines)


@_user_data_mutation_locked
def op_domain_set(domain: str, issue_cert: bool = False) -> tuple[bool, str, str]:
    title = "Domain Control - Set Domain"
    domain_n = _normalize_domain(domain)
    if not DOMAIN_RE.match(domain_n):
        return False, title, "Domain tidak valid."

    if issue_cert:
        ok_setup, _, msg_setup = op_domain_setup_custom(domain_n)
        if not ok_setup:
            return False, title, msg_setup
        return True, title, msg_setup

    ok_ng, ng_msg = _apply_nginx_domain(domain_n)
    if not ok_ng:
        return False, title, ng_msg

    updated, failed = _refresh_all_account_info(domain=domain_n)
    if failed > 0:
        return True, title, (
            f"Domain berhasil diubah ke: {domain_n}\n"
            f"- ACCOUNT INFO updated: {updated}\n"
            f"- Warning: {failed} ACCOUNT INFO gagal direfresh. Domain aktif tetap dipertahankan; jalankan refresh eksplisit bila diperlukan."
        )
    return True, title, f"Domain berhasil diubah ke: {domain_n}\n- ACCOUNT INFO updated: {updated}"


@_user_data_mutation_locked
def op_domain_refresh_accounts() -> tuple[bool, str, str]:
    updated, failed = _refresh_all_account_info()
    return _account_refresh_outcome(
        "Domain Control - Refresh Account Info",
        ["Selesai refresh ACCOUNT INFO."],
        updated=updated,
        failed=failed,
        partial_failure_hint="Sebagian ACCOUNT INFO gagal direfresh dan mungkin masih stale.",
    )


def op_network_apply_warp_global_mode(mode: str) -> tuple[bool, str, str]:
    title = "Network Controls - WARP Global"
    mode_n = str(mode or "").strip().lower()
    snapshot = _capture_xray_network_runtime_snapshot()

    ok_apply, msg_apply = _apply_routing_transaction(
        lambda rt_cfg, out_cfg: _routing_set_default_warp_global_mode(rt_cfg, out_cfg, mode_n)
    )
    if not ok_apply:
        return False, title, msg_apply

    ok_sync, msg_sync = _speed_policy_sync_xray()
    if not ok_sync:
        ok_rb, msg_rb = _restore_xray_network_runtime_snapshot(snapshot)
        if ok_rb:
            return False, title, f"{msg_apply}\nCatatan sinkronisasi speed policy: {msg_sync}"
        return False, title, f"{msg_apply}\nCatatan sinkronisasi speed policy: {msg_sync}\nRollback network controls gagal:\n{msg_rb}"
    if not _speed_policy_apply_now():
        ok_rb, msg_rb = _restore_xray_network_runtime_snapshot(snapshot)
        if ok_rb:
            return False, title, f"{msg_apply}\nCatatan apply runtime speed policy gagal (xray-speed)."
        return False, title, f"{msg_apply}\nCatatan apply runtime speed policy gagal (xray-speed).\nRollback network controls gagal:\n{msg_rb}"
    return True, title, msg_apply


def op_network_set_dns_primary(value: str) -> tuple[bool, str, str]:
    title = "Network Controls - Set Primary DNS"
    val = str(value or "").strip()
    ok_apply, msg_apply = _apply_dns_transaction(lambda cfg: _dns_set_primary(cfg, val))
    if not ok_apply:
        return False, title, msg_apply
    return True, title, msg_apply


def op_network_set_dns_secondary(value: str) -> tuple[bool, str, str]:
    title = "Network Controls - Set Secondary DNS"
    val = str(value or "").strip()
    ok_apply, msg_apply = _apply_dns_transaction(lambda cfg: _dns_set_secondary(cfg, val))
    if not ok_apply:
        return False, title, msg_apply
    return True, title, msg_apply


def op_network_set_dns_query_strategy(strategy: str) -> tuple[bool, str, str]:
    title = "Network Controls - Set DNS Query Strategy"
    strategy_n = str(strategy or "").strip()
    ok_apply, msg_apply = _apply_dns_transaction(lambda cfg: _dns_set_query_strategy(cfg, strategy_n))
    if not ok_apply:
        return False, title, msg_apply
    return True, title, msg_apply


def op_network_toggle_dns_cache() -> tuple[bool, str, str]:
    title = "Network Controls - Toggle DNS Cache"
    ok_apply, msg_apply = _apply_dns_transaction(_dns_toggle_cache)
    if not ok_apply:
        return False, title, msg_apply
    return True, title, msg_apply
