import axios, { AxiosInstance } from "axios";

const DEFAULT_BACKEND_TIMEOUT_MS = 30_000;
const ACTION_TIMEOUT_MS: Record<string, number> = {
  "5:setup_domain_custom": 420_000,
  "5:setup_domain_cloudflare": 420_000,
  "5:domain_guard_check": 190_000,
  "5:domain_guard_renew": 320_000,
  "6:run": 190_000,
};

function resolveActionTimeoutMs(menuId: string, action: string): number {
  return ACTION_TIMEOUT_MS[`${menuId}:${action}`] ?? DEFAULT_BACKEND_TIMEOUT_MS;
}

export interface BackendActionResponse {
  ok: boolean;
  code: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
}

export interface BackendHealthResponse {
  status?: string;
  service?: string;
  dangerous_actions_enabled?: boolean;
}

export interface BackendMainMenuResponse {
  mode?: string;
  dangerous_actions_enabled?: boolean;
  menu_count?: number;
  menus?: unknown[];
}

export interface BackendUserOption {
  proto: string;
  username: string;
}

export interface BackendRootDomainOption {
  root_domain: string;
}

export class BackendClient {
  private readonly client: AxiosInstance;

  constructor(baseURL: string, sharedSecret: string) {
    this.client = axios.create({
      baseURL,
      timeout: DEFAULT_BACKEND_TIMEOUT_MS,
      headers: {
        "X-Internal-Shared-Secret": sharedSecret,
      },
    });
  }

  async runAction(menuId: string, action: string, params: Record<string, string> = {}): Promise<BackendActionResponse> {
    const timeout = resolveActionTimeoutMs(menuId, action);
    const res = await this.client.post<BackendActionResponse>(
      `/api/menu/${menuId}/action`,
      {
        action,
        params,
      },
      {
        timeout,
      },
    );
    return res.data;
  }

  async listUserOptions(proto?: string): Promise<BackendUserOption[]> {
    const res = await this.client.get<{ users?: BackendUserOption[] }>("/api/users/options", {
      params: proto ? { proto } : {},
    });
    const users = Array.isArray(res.data?.users) ? res.data.users : [];
    return users.filter((item) => item && typeof item.proto === "string" && typeof item.username === "string");
  }

  async listDomainRootOptions(): Promise<BackendRootDomainOption[]> {
    const res = await this.client.get<{ roots?: BackendRootDomainOption[] }>("/api/domain/root-options");
    const roots = Array.isArray(res.data?.roots) ? res.data.roots : [];
    return roots.filter((item) => item && typeof item.root_domain === "string");
  }

  async getHealth(timeout = 8_000): Promise<BackendHealthResponse> {
    const res = await this.client.get<BackendHealthResponse>("/health", { timeout });
    return res.data;
  }

  async getMainMenu(timeout = 8_000): Promise<BackendMainMenuResponse> {
    const res = await this.client.get<BackendMainMenuResponse>("/api/main-menu", { timeout });
    return res.data;
  }
}
