#!/usr/bin/env bash
# shellcheck shell=bash

  mkdir -p "$(dirname "${lock_file}")" 2>/dev/null || true
  chmod 700 "$(dirname "${lock_file}")" 2>/dev/null || true
}

  [[ "${1:-}" =~ ^[A-Za-z0-9._-]{1,15}$ ]]
}

  local lock_file rc=0
    "$@"
    return $?
  fi
  if have_cmd flock; then
    if (
      flock -x 200 || exit 1
    ) 200>"${lock_file}"; then
      return 0
    fi
    return $?
  fi
  rc=$?
  return "${rc}"
}

  need_python3
import pathlib
import re
import sys

cfg_path = pathlib.Path(sys.argv[1])
defaults = {
  "global_mode": "direct",
  "fwmark": str(sys.argv[3] or "42042").strip() or "42042",
  "route_table": str(sys.argv[4] or "42042").strip() or "42042",
  "rule_pref": str(sys.argv[5] or "14200").strip() or "14200",
  "warp_backend": str(sys.argv[7] or "auto").strip().lower() or "auto",
  "xray_redir_port": str(sys.argv[8] or "12345").strip() or "12345",
  "xray_redir_port_v6": str(sys.argv[9] or "12346").strip() or "12346",
}
data = {}
if cfg_path.exists():
  try:
    for line in cfg_path.read_text(encoding="utf-8").splitlines():
      line = line.strip()
      if not line or line.startswith("#") or "=" not in line:
        continue
      key, value = line.split("=", 1)
      data[key.strip()] = value.strip()
  except Exception:
    data = {}

if global_mode not in ("direct", "warp"):
  global_mode = defaults["global_mode"]

if warp_backend not in ("auto", "local-proxy", "interface"):
  warp_backend = defaults["warp_backend"]

def read_num(key, fallback):
  raw = str(data.get(key, fallback)).strip()
  try:
    return str(int(float(raw)))
  except Exception:
    return str(fallback)

if not re.fullmatch(r"[A-Za-z0-9._-]{1,15}", warp_interface):
  warp_interface = defaults["warp_interface"]

print(f"global_mode={global_mode}")
print(f"warp_backend={warp_backend}")
print(f"warp_interface={warp_interface}")
PY
}

  local tmp
  need_python3
import pathlib
import sys

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
items = sys.argv[3:]
if len(items) % 2 != 0:
  raise SystemExit(2)
updates = {}
for i in range(0, len(items), 2):
  updates[str(items[i])] = str(items[i + 1])

lines = []
if src.exists():
  try:
    lines = src.read_text(encoding="utf-8").splitlines()
  except Exception:
    lines = []

out = []
seen = set()
for line in lines:
  stripped = line.strip()
  if not stripped or stripped.startswith("#") or "=" not in line:
    out.append(line)
    continue
  key, _ = line.split("=", 1)
  key = key.strip()
  if key in updates:
    out.append(f"{key}={updates[key]}")
    seen.add(key)
  else:
    out.append(line)

for key, value in updates.items():
  if key in seen:
    continue
  out.append(f"{key}={value}")

dst.write_text("\n".join(out).rstrip("\n") + "\n", encoding="utf-8")
PY
  local rc=$?
  if (( rc == 0 )); then
      rm -f "${tmp}" >/dev/null 2>&1 || true
      return 1
    }
  else
    rm -f "${tmp}" >/dev/null 2>&1 || true
  fi
  return "${rc}"
}

  local mode="${1:-}"
  case "${mode}" in
    direct|warp) ;;
    *) return 1 ;;
  esac
}

  local backend="${1:-}"
  case "${backend}" in
    auto|local-proxy|interface) ;;
    *) return 1 ;;
  esac
}

  local backend="${1:-auto}"
  case "${backend}" in
    local-proxy|interface)
      printf '%s\n' "${backend}"
      ;;
    *)
      if have_cmd xray && have_cmd iptables; then
        printf 'local-proxy\n'
      else
        printf 'interface\n'
      fi
      ;;
  esac
}

  local cfg backend=""
  backend="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"
}

  local backend="${1:-auto}"
  case "${backend}" in
    local-proxy) printf 'Local Proxy\n' ;;
    local-proxy-drift) printf 'Local Proxy (Drift)\n' ;;
    interface) printf 'Dedicated Interface\n' ;;
    interface-drift) printf 'Dedicated Interface (Drift)\n' ;;
    idle) printf 'Idle / Not Applied\n' ;;
    *) printf 'Auto\n' ;;
  esac
}

  local backend="${1:-auto}"
  case "${backend}" in
    idle) printf 'not applied\n' ;;
    local-proxy) printf 'xray redirect + local WARP SOCKS\n' ;;
    local-proxy-drift) printf 'xray redirect + local WARP SOCKS (drift)\n' ;;
    interface) printf 'wg-quick interface + nft/ip rule\n' ;;
    interface-drift) printf 'wg-quick interface + nft/ip rule (drift)\n' ;;
    *)
      case "${backend}" in
        local-proxy) printf 'xray redirect + local WARP SOCKS\n' ;;
        *) printf 'wg-quick interface + nft/ip rule\n' ;;
      esac
      ;;
  esac
}

  local iptables_state="${1:-absent}" ip6tables_state="${2:-absent}" nft_state="${3:-absent}"
  local ip_rule_state="${4:-absent}" ip_rule_v6_state="${5:-absent}" route_table_v4_state="${6:-absent}"
  local route_table_v6_state="${7:-absent}" iface_state="${8:-missing}" warp_service_state="${9:-inactive}"
  local xray_redir_v4_state="${10:-not-listening}" xray_redir_v6_state="${11:-not-listening}" host_warp_proxy_state="${12:-not-listening}"

  if [[ "${iptables_state}" == "present" || "${ip6tables_state}" == "present" ]]; then
    if [[ "${host_warp_proxy_state}" != "listening" ]]; then
      printf 'local-proxy-drift\n'
      return 0
    fi
    if [[ "${iptables_state}" == "present" && "${xray_redir_v4_state}" != "active" ]]; then
      printf 'local-proxy-drift\n'
      return 0
    fi
    if [[ "${ip6tables_state}" == "present" && "${xray_redir_v6_state}" != "active" ]]; then
      printf 'local-proxy-drift\n'
      return 0
    fi
    printf 'local-proxy\n'
    return 0
  fi
  if [[ "${nft_state}" == "present" || "${ip_rule_state}" == "present" || "${ip_rule_v6_state}" == "present" ]]; then
    if [[ "${iface_state}" == "present" && "${warp_service_state}" == "active" ]]; then
      printf 'interface\n'
    else
      printf 'interface-drift\n'
    fi
    return 0
  fi
  if [[ "${route_table_v4_state}" == "present" || "${route_table_v6_state}" == "present" ]]; then
    if [[ "${iface_state}" == "present" && "${warp_service_state}" == "active" ]]; then
      printf 'interface\n'
    else
      printf 'interface-drift\n'
    fi
    return 0
  fi
  if [[ "${iface_state}" == "present" && "${warp_service_state}" == "active" ]]; then
    printf 'interface\n'
    return 0
  fi
  printf 'idle\n'
}

  local listener_state="${1:-not-listening}" apply_state="${2:-absent}"
  case "${listener_state}:${apply_state}" in
    listening:present) printf 'active\n' ;;
    listening:absent) printf 'standby\n' ;;
    missing:*) printf 'missing\n' ;;
    not-listening:present) printf 'drift-no-listener\n' ;;
    *) printf 'not-listening\n' ;;
  esac
}

  local cfg=""
  printf '%s\n' "${cfg}" | awk -F'=' '/^xray_redir_port=/{print $2; exit}'
}

  local cfg=""
  printf '%s\n' "${cfg}" | awk -F'=' '/^xray_redir_port_v6=/{print $2; exit}'
}

}

}

}

}

}

}

  if declare -F warp_mode_display_cached_get >/dev/null 2>&1; then
    warp_mode_display_cached_get 2>/dev/null || printf 'Free/Plus\n'
  elif declare -F warp_mode_display_get >/dev/null 2>&1; then
    warp_mode_display_get 2>/dev/null || printf 'Free/Plus\n'
  else
    printf 'Free/Plus\n'
  fi
}

  if declare -F warp_backend_display_name_get >/dev/null 2>&1; then
    warp_backend_display_name_get 2>/dev/null || printf 'WARP Backend\n'
  else
    printf 'wireproxy\n'
  fi
}

  if declare -F warp_backend_service_name_get >/dev/null 2>&1; then
    warp_backend_service_name_get 2>/dev/null || printf 'wireproxy\n'
  else
    printf 'wireproxy\n'
  fi
}

  local svc=""
  if [[ -n "${svc}" ]] && svc_exists "${svc}"; then
    svc_state "${svc}"
  else
    printf 'missing\n'
  fi
}

  if declare -F warp_proxy_port_get >/dev/null 2>&1; then
    warp_proxy_port_get 2>/dev/null || printf '%s\n' "${WARP_ZEROTRUST_PROXY_PORT:-40000}"
  else
    printf '%s\n' "${WARP_ZEROTRUST_PROXY_PORT:-40000}"
  fi
}

  local mode=""
  if declare -F warp_mode_state_get >/dev/null 2>&1; then
    mode="$(warp_mode_state_get 2>/dev/null || true)"
  fi
  if [[ "${mode}" == "zerotrust" ]]; then
    warn "Gunakan backend Local Proxy, atau kembalikan host ke Free/Plus lebih dulu."
    return 1
  fi
  return 0
}

  local iface="${1:-}"
}

  local iface="${1:-}"
  printf '%s/%s.conf\n' "${WIREGUARD_DIR:-/etc/wireguard}" "${iface}"
}

  local iface="${1:-}"
  printf 'wg-quick@%s\n' "${iface}"
}

}

  local path="${1:-}"
  [[ -n "${path}" && -f "${path}" ]] || return 1
  cksum "${path}" 2>/dev/null | awk '{print $1 ":" $2}'
}

  local iface="${1:-}" source_conf="" dest_dir="" dest_path="" helper=""
    return 1
  }
  source_conf="${WIREPROXY_CONF:-/etc/wireproxy/config.conf}"
  dest_dir="${WIREGUARD_DIR:-/etc/wireguard}"
  [[ -s "${source_conf}" ]] || {
    warn "Source config WARP host tidak ditemukan: ${source_conf}"
    return 1
  }
  mkdir -p "${dest_dir}" 2>/dev/null || true
  chmod 700 "${dest_dir}" 2>/dev/null || true

    "${helper}" --interface "${iface}" --source "${source_conf}" --dest-dir "${dest_dir}" >/dev/null 2>&1 || {
      return 1
    }
  else
    need_python3
    python3 - <<'PY' "${source_conf}" "${dest_path}" >/dev/null 2>&1 || {
import os
import pathlib
import sys

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
keep_sections = {"[Interface]", "[Peer]"}
drop_interface_keys = {"dns", "table", "preup", "postup", "predown", "postdown", "saveconfig"}

def compact_blank(lines):
    out = []
    prev_blank = False
    for line in lines:
        blank = not line.strip()
        if blank and prev_blank:
            continue
        out.append("" if blank else line.rstrip())
        prev_blank = blank
    while out and not out[-1].strip():
        out.pop()
    return out

source_text = src.read_text(encoding="utf-8")
out = []
current = None
table_inserted = False
for raw in source_text.splitlines():
    line = raw.rstrip("\n")
    stripped = line.strip()
    if stripped.startswith("[") and stripped.endswith("]"):
        if current == "[Interface]" and not table_inserted:
            out.append("Table = off")
            out.append("")
            table_inserted = True
        current = stripped if stripped in keep_sections else None
        if current is not None:
            out.append(current)
        continue
    if current is None:
        continue
    if not stripped:
        out.append("")
        continue
    if stripped.startswith("#") or stripped.startswith(";"):
        out.append(line)
        continue
    key = stripped.split("=", 1)[0].strip().lower()
    if current == "[Interface]" and key in drop_interface_keys:
        continue
    out.append(line)

if current == "[Interface]" and not table_inserted:
    out.append("Table = off")

rendered = "\n".join(compact_blank(out)).rstrip() + "\n"
if "[Interface]" not in rendered or "[Peer]" not in rendered:
    raise SystemExit("source config tidak memuat [Interface] dan [Peer] yang valid")

dst.parent.mkdir(parents=True, exist_ok=True)
dst.write_text(rendered, encoding="utf-8")
os.chmod(dst, 0o600)
PY
      return 1
    }
  fi
  chmod 600 "${dest_path}" >/dev/null 2>&1 || true
  return 0
}

    return $?
  fi
}

  local iface="${1:-}" unit=""
    return 1
  }
  have_cmd wg-quick || {
    warn "wg-quick tidak tersedia. Install wireguard-tools atau rerun setup.sh."
    return 1
  }
  if ! systemctl cat "wg-quick@.service" >/dev/null 2>&1 && ! systemctl cat "wg-quick@${iface}" >/dev/null 2>&1; then
    warn "Template service wg-quick@.service tidak tersedia."
    return 1
  fi
  systemctl daemon-reload >/dev/null 2>&1 || true
  if svc_is_active "${unit}"; then
    if ! svc_restart_checked "${unit}" 30; then
      warn "Gagal restart ${unit}."
      return 1
    fi
  else
    if ! systemctl enable --now "${unit}" >/dev/null 2>&1; then
      warn "Gagal mengaktifkan ${unit}."
      return 1
    fi
    if ! svc_wait_active "${unit}" 30; then
      warn "${unit} belum aktif sesudah start."
      return 1
    fi
  fi
  if ! have_cmd ip || ! ip link show "${iface}" >/dev/null 2>&1; then
    return 1
  fi
  return 0
}

    return $?
  fi
}

  local iface="${1:-}" unit="" conf_path=""
    return 1
  }
  systemctl disable --now "${unit}" >/dev/null 2>&1 || systemctl stop "${unit}" >/dev/null 2>&1 || true
  if svc_exists "${unit}" && ! svc_wait_inactive "${unit}" 20; then
    warn "${unit} belum berhenti sepenuhnya."
    return 1
  fi
  if [[ -n "${conf_path}" && -f "${conf_path}" ]] && have_cmd wg-quick; then
    wg-quick down "${iface}" >/dev/null 2>&1 || true
  fi
  if have_cmd ip && ip link show "${iface}" >/dev/null 2>&1; then
    ip link delete dev "${iface}" >/dev/null 2>&1 || true
  fi
  if have_cmd ip && ip link show "${iface}" >/dev/null 2>&1; then
    return 1
  fi
  return 0
}

  local iface="${1:-}" conf_path=""
    return 1
  }
  if [[ -n "${conf_path}" && -f "${conf_path}" ]]; then
    rm -f "${conf_path}" >/dev/null 2>&1 || {
      return 1
    }
  fi
  return 0
}

  local iface="${1:-}"
    return 1
  }
}

    return $?
  fi
}

  local new_iface="${1:-}" cfg current_iface=""
    return 1
  }
  current_iface="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_interface=/{print $2; exit}')"
    current_iface=""
  fi
  if [[ "${new_iface}" == "${current_iface}" ]]; then
    return 0
  fi
    if [[ -n "${current_iface}" && "${current_iface}" != "${new_iface}" ]]; then
        warn "Cleanup interface lama '${current_iface}' gagal. Rollback ke interface sebelumnya..."
        fi
        return 1
      fi
    fi
    return 0
  fi
  if [[ -n "${current_iface}" && "${current_iface}" != "${new_iface}" ]]; then
  fi
  return 1
}

    return $?
  fi
    return $?
  fi
}

  local iface="${1:-}" conf_path=""
  [[ -f "${conf_path}" ]] || return 1
  need_python3
  python3 - <<'PY' "${conf_path}" 2>/dev/null || true
import ipaddress
import socket
import sys
from pathlib import Path

path = Path(sys.argv[1])
endpoint_host = ""
for raw in path.read_text(encoding="utf-8").splitlines():
    line = raw.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, value = line.split("=", 1)
    if key.strip().lower() != "endpoint":
        continue
    endpoint = value.strip()
    if endpoint.startswith("[") and "]" in endpoint:
        endpoint_host = endpoint[1:].split("]", 1)[0].strip()
    else:
        endpoint_host = endpoint.rsplit(":", 1)[0].strip()
    break

if not endpoint_host:
    raise SystemExit(0)

ipv4 = []
ipv6 = []
try:
    ip = ipaddress.ip_address(endpoint_host)
    if ip.version == 4:
        ipv4.append(str(ip))
    else:
        ipv6.append(str(ip))
except ValueError:
    try:
        infos = socket.getaddrinfo(endpoint_host, None, 0, socket.SOCK_DGRAM)
    except Exception:
        infos = []
    seen4 = set()
    seen6 = set()
    for family, _, _, _, sockaddr in infos:
        host = sockaddr[0]
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            continue
        if ip.version == 4 and host not in seen4:
            seen4.add(host)
            ipv4.append(host)
        elif ip.version == 6 and host not in seen6:
            seen6.add(host)
            ipv6.append(host)

for item in ipv4:
    print(f"ipv4|{item}")
for item in ipv6:
    print(f"ipv6|{item}")
PY
}

  local qf="${1:-}"
  [[ -n "${qf}" && -f "${qf}" ]] || {
    printf '%s\n' "inherit"
    return 0
  }
  need_python3
  python3 - <<'PY' "${qf}" 2>/dev/null || true
import json
import sys

mode = "inherit"
try:
  payload = json.load(open(sys.argv[1], "r", encoding="utf-8"))
  if isinstance(payload, dict):
    network = payload.get("network")
    if isinstance(network, dict):
      candidate = str(network.get("route_mode") or "").strip().lower()
      if candidate in ("inherit", "direct", "warp"):
        mode = candidate
except Exception:
  pass
print(mode)
PY
}

  local username="${1:-}"
  local mode="${2:-}"
  local qf=""
  [[ -n "${username}" ]] || return 1
  case "${mode}" in
    inherit|direct|warp) ;;
    *) return 1 ;;
  esac
  [[ -n "${qf}" ]] || return 1
  if [[ ! -f "${qf}" ]]; then
    if ! id "${username}" >/dev/null 2>&1; then
      return 1
    fi
      return 1
    fi
  fi
}

  local target_mode="${1:-}"
  local prev_mode=""
  local -a rollback_notes=()
  case "${target_mode}" in
    direct|warp) ;;
    *) return 1 ;;
  esac

  [[ "${prev_mode}" == "direct" || "${prev_mode}" == "warp" ]] || prev_mode="direct"

    return 1
  fi
    return 0
  fi

    rollback_notes+=("restore config gagal")
    rollback_notes+=("restore runtime gagal")
  fi

  if ((${#rollback_notes[@]} > 0)); then
  fi
  return 1
}

  local username="${1:-}"
  local target_mode="${2:-}"
  local qf="" prev_mode=""
  local -a rollback_notes=()
  [[ -n "${username}" ]] || return 1
  case "${target_mode}" in
    inherit|direct|warp) ;;
    *) return 1 ;;
  esac


    return 1
  fi
    return 0
  fi

    rollback_notes+=("restore metadata gagal")
    rollback_notes+=("restore runtime gagal")
  fi

  if ((${#rollback_notes[@]} > 0)); then
  fi
  return 1
}

  local cfg global_mode username uid qf override effective
  global_mode="$(printf '%s\n' "${cfg}" | awk -F'=' '/^global_mode=/{print $2; exit}')"
  [[ "${global_mode}" == "warp" ]] || global_mode="direct"
  while IFS= read -r username; do
    [[ -n "${username}" ]] || continue
    uid="$(id -u "${username}" 2>/dev/null || true)"
    [[ "${uid}" =~ ^[0-9]+$ ]] || continue
    case "${override}" in
      direct|warp) effective="${override}" ;;
      *) effective="${global_mode}" ; override="inherit" ;;
    esac
    printf '%s|%s|%s|%s\n' "${username}" "${uid:--}" "${override}" "${effective}"
}

  local port="${1:-}"
  [[ "${port}" =~ ^[0-9]+$ ]] || return 1
  have_cmd ss || return 1
  ss -lnt "( sport = :${port} )" 2>/dev/null | awk -v want=":${port}" 'index($0, want) {found=1} END{exit found ? 0 : 1}'
}

  local port="${1:-}" timeout="${2:-20}" i=0
  [[ "${port}" =~ ^[0-9]+$ ]] || return 1
  [[ "${timeout}" =~ ^[0-9]+$ ]] || timeout=20
  while (( i < timeout )); do
      return 0
    fi
    sleep 1
    ((i++))
  done
  return 1
}

}

  local root
}

  local path root="/sys/fs/cgroup"
  case "${path}" in
    "${root}")
      return 1
      ;;
    "${root}/"*)
      printf '%s\n' "${path#${root}/}"
      ;;
    *)
      return 1
      ;;
  esac
}

  local root="/sys/fs/cgroup" fs_type=""
  [[ -d "${root}" && -w "${root}" ]] || return 1
  have_cmd iptables || return 1
  fs_type="$(stat -fc %T "${root}" 2>/dev/null || true)"
  [[ "${fs_type}" == "cgroup2fs" ]] || return 1
  iptables -m cgroup -h >/dev/null 2>&1 || return 1
  return 0
}

  local root="/sys/fs/cgroup" path="" parent="" pid=""
  [[ -n "${path}" && -d "${path}" ]] || return 0

  if [[ -r "${path}/cgroup.procs" && -w "${root}/cgroup.procs" ]]; then
    while IFS= read -r pid; do
      [[ "${pid}" =~ ^[0-9]+$ ]] || continue
      printf '%s\n' "${pid}" > "${root}/cgroup.procs" 2>/dev/null || true
    done < "${path}/cgroup.procs"
  fi

  rmdir "${path}" >/dev/null 2>&1 || true
  parent="$(dirname "${path}")"
  if [[ -n "${parent}" && "${parent}" != "${root}" ]]; then
    rmdir "${parent}" >/dev/null 2>&1 || true
  fi
  return 0
}

  (( $# > 0 )) || return 0
  need_python3
import re
import subprocess
import sys

try:
except Exception:

def norm_user(value):
  text = str(value or "").strip()
    text = text[:-4]
  if "@" in text:
    text = text.split("@", 1)[0]
  return text

targets = {norm_user(item) for item in sys.argv[2:] if norm_user(item)}
if not targets:
  raise SystemExit(0)

rows = []
try:
  res = subprocess.run(
    ["ps", "-eo", "pid=,ppid=,user=,uid=,comm=,args="],
    stdout=subprocess.PIPE,
    stderr=subprocess.DEVNULL,
    text=True,
    check=False,
    timeout=2.0,
  )
except Exception:
  res = None

if res is None or res.returncode != 0:
  raise SystemExit(0)

for line in (res.stdout or "").splitlines():
  raw = line.strip()
  if not raw:
    continue
  parts = raw.split(None, 5)
  if len(parts) < 6:
    continue
  try:
    pid = int(parts[0])
    ppid = int(parts[1])
    uid = int(parts[3])
  except ValueError:
    continue
  rows.append({
    "pid": pid,
    "ppid": ppid,
    "user": parts[2],
    "uid": uid,
    "comm": parts[4],
    "args": parts[5],
  })

proc_info = {}
children = {}
for row in rows:
  pid = int(row.get("pid") or 0)
  ppid = int(row.get("ppid") or 0)
  proc_info[pid] = row
  children.setdefault(ppid, []).append(pid)

master_pids = set()
for row in rows:
    master_pids.add(int(row.get("pid") or 0))

if not master_pids:
  raise SystemExit(0)

session_pids = []
for row in rows:
    continue
  if int(row.get("ppid") or 0) in master_pids:
    session_pids.append(int(row.get("pid") or 0))

if not session_pids:
  raise SystemExit(0)

def username_from_pid(pid):
  queue = [int(pid)]
  seen = set()
  while queue:
    cur = queue.pop(0)
    if cur in seen:
      continue
    seen.add(cur)
    meta = proc_info.get(cur) or {}
    uid = int(meta.get("uid") or 0)
    if uid > 0:
      username = norm_user(meta.get("user"))
      if username:
        return username
      try:
        import pwd
        return norm_user(pwd.getpwuid(uid).pw_name)
      except Exception:
        pass
    for child in children.get(cur, ()):
      queue.append(int(child))
  return ""

mapping = {}

def parse_lines(lines):
  for line in lines:
    match = pat.search(str(line or ""))
    if not match:
      continue
    try:
      pid = int(match.group(1))
    except Exception:
      continue
    username = norm_user(match.group(2))
    if username:
      mapping[pid] = username

try:
  res = subprocess.run(
    stdout=subprocess.PIPE,
    stderr=subprocess.DEVNULL,
    text=True,
    check=False,
    timeout=2.0,
  )
  parse_lines((res.stdout or "").splitlines())
except Exception:
  pass

if not mapping:
  try:
    res = subprocess.run(
      ["tail", "-n", "5000", "/var/log/auth.log"],
      stdout=subprocess.PIPE,
      stderr=subprocess.DEVNULL,
      text=True,
      check=False,
      timeout=2.0,
    )
    parse_lines((res.stdout or "").splitlines())
  except Exception:
    pass

for pid in sorted(set(session_pids)):
  username = username_from_pid(pid) or mapping.get(pid)
  if username in targets:
    print(f"{pid}|{username}")
PY
}

  local parent="" path="" pid="" username=""
  (( $# > 0 )) || return 0

  mkdir -p "${parent}" "${path}" >/dev/null 2>&1 || return 1

  while IFS='|' read -r pid username; do
    [[ "${pid}" =~ ^[0-9]+$ ]] || continue
    printf '%s\n' "${pid}" > "${path}/cgroup.procs" 2>/dev/null || true
  return 0
}

  local port="" svc_name="" listener_name=""
  if declare -F warp_port_listener_name_get >/dev/null 2>&1; then
    listener_name="$(warp_port_listener_name_get "${port}" 2>/dev/null || true)"
    case "${listener_name}" in
      "${svc_name}") printf 'listening\n' ;;
      wireproxy) printf 'occupied-by-wireproxy\n' ;;
      "") printf 'not-listening\n' ;;
      *) printf 'busy-other-process\n' ;;
    esac
    return 0
  fi
    printf 'listening\n'
  else
    printf 'not-listening\n'
  fi
}

  local family="${1:-ipv4}" port=""
  case "${family}" in
  esac
    printf 'listening\n'
  else
    printf 'not-listening\n'
  fi
}

  local chain_v4="" chain_v6="" chain_mark_v4="" chain_mark_v6=""

  if have_cmd iptables; then
    while iptables -t nat -D OUTPUT -p tcp -j "${chain_v4}" >/dev/null 2>&1; do :; done
    iptables -t nat -F "${chain_v4}" >/dev/null 2>&1 || true
    iptables -t nat -X "${chain_v4}" >/dev/null 2>&1 || true
    while iptables -t mangle -D OUTPUT -p tcp -j "${chain_mark_v4}" >/dev/null 2>&1; do :; done
    iptables -t mangle -F "${chain_mark_v4}" >/dev/null 2>&1 || true
    iptables -t mangle -X "${chain_mark_v4}" >/dev/null 2>&1 || true
  fi
  if have_cmd ip6tables; then
    while ip6tables -t nat -D OUTPUT -p tcp -j "${chain_v6}" >/dev/null 2>&1; do :; done
    ip6tables -t nat -F "${chain_v6}" >/dev/null 2>&1 || true
    ip6tables -t nat -X "${chain_v6}" >/dev/null 2>&1 || true
    while ip6tables -t mangle -D OUTPUT -p tcp -j "${chain_mark_v6}" >/dev/null 2>&1; do :; done
    ip6tables -t mangle -F "${chain_mark_v6}" >/dev/null 2>&1 || true
    ip6tables -t mangle -X "${chain_mark_v6}" >/dev/null 2>&1 || true
  fi
}

  local port=""
  if declare -F warp_backend_post_restart_health_check >/dev/null 2>&1; then
    warp_backend_post_restart_health_check || return 1
  else
    local svc=""
    if [[ -n "${svc}" && "${svc}" != "missing" ]] && svc_exists "${svc}" && ! svc_is_active "${svc}"; then
      svc_restart_checked "${svc}" 30 || return 1
    fi
  fi
    warn "Proxy lokal WARP host port ${port} belum listening."
    return 1
  fi
  return 0
}

  local inb_conf="${XRAY_INBOUNDS_CONF}" rt_conf="${XRAY_ROUTING_CONF}"
  local svc_conf="/etc/systemd/system/xray.service.d/10-confdir.conf"
  local tmp_inb="" tmp_rt="" tmp_svc=""
  local backup_inb="" backup_rt="" backup_svc=""
  local port4="" port6="" tag4="" tag6="" rc=0

  [[ -f "${inb_conf}" ]] || {
    warn "Xray inbounds conf tidak ditemukan: ${inb_conf}"
    return 1
  }
  [[ -f "${rt_conf}" ]] || {
    warn "Xray routing conf tidak ditemukan: ${rt_conf}"
    return 1
  }
  [[ -f "${svc_conf}" ]] || {
    warn "Drop-in xray.service tidak ditemukan: ${svc_conf}"
    return 1
  }

  ensure_path_writable "${inb_conf}"
  ensure_path_writable "${rt_conf}"
  ensure_path_writable "${svc_conf}"

  backup_inb="$(xray_backup_path_prepare "${inb_conf}")"
  backup_rt="$(xray_backup_path_prepare "${rt_conf}")"
  backup_svc="$(xray_backup_path_prepare "${svc_conf}")"

  set +e
  (
    flock -x 200
    cp -a "${inb_conf}" "${backup_inb}" || exit 1
    cp -a "${rt_conf}" "${backup_rt}" || exit 1
    cp -a "${svc_conf}" "${backup_svc}" || exit 1

    python3 - <<'PY' "${svc_conf}" "${tmp_svc}" || exit 1
import pathlib
import sys

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
wanted = {
    "AmbientCapabilities": "CAP_NET_ADMIN",
    "CapabilityBoundingSet": "CAP_NET_ADMIN",
    "NoNewPrivileges": "no",
}

lines = []
if src.exists():
    lines = src.read_text(encoding="utf-8").splitlines()

out = []
seen = set()
for line in lines:
    stripped = line.strip()
    if not stripped or stripped.startswith("#") or "=" not in line:
        out.append(line)
        continue
    key, _ = line.split("=", 1)
    key = key.strip()
    if key in wanted:
        out.append(f"{key}={wanted[key]}")
        seen.add(key)
    else:
        out.append(line)

for key, value in wanted.items():
    if key not in seen:
        out.append(f"{key}={value}")

dst.write_text("\n".join(out).rstrip("\n") + "\n", encoding="utf-8")
PY

    python3 - <<'PY' "${inb_conf}" "${rt_conf}" "${tmp_inb}" "${tmp_rt}" "${port4}" "${port6}" "${tag4}" "${tag6}" || exit 1
import json
import pathlib
import sys

inb_src, rt_src, inb_dst, rt_dst, port4_raw, port6_raw, tag4, tag6 = sys.argv[1:9]
port4 = int(port4_raw)
port6 = int(port6_raw)

def load_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)

def dump_json(path, payload):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

inb_cfg = load_json(inb_src)
inbounds = inb_cfg.get("inbounds")
if not isinstance(inbounds, list):
    raise SystemExit("Invalid Xray inbounds config")

canonical_inbounds = [
    {
        "listen": "127.0.0.1",
        "port": port4,
        "protocol": "dokodemo-door",
        "tag": tag4,
        "settings": {
            "network": "tcp",
            "followRedirect": True,
        },
        "streamSettings": {
            "sockopt": {
                "tproxy": "redirect",
            }
        },
    },
    {
        "listen": "::1",
        "port": port6,
        "protocol": "dokodemo-door",
        "tag": tag6,
        "settings": {
            "network": "tcp",
            "followRedirect": True,
        },
        "streamSettings": {
            "sockopt": {
                "tproxy": "redirect",
            }
        },
    },
]

filtered_inbounds = []
inserted = False
for inbound in inbounds:
    if not isinstance(inbound, dict):
        filtered_inbounds.append(inbound)
        continue
    tag = str(inbound.get("tag") or "").strip()
    if tag in (tag4, tag6):
        continue
    filtered_inbounds.append(inbound)
    if not inserted and tag == "api":
        filtered_inbounds.extend(canonical_inbounds)
        inserted = True
if not inserted:
    filtered_inbounds = canonical_inbounds + filtered_inbounds
inb_cfg["inbounds"] = filtered_inbounds
dump_json(inb_dst, inb_cfg)

rt_cfg = load_json(rt_src)
routing = rt_cfg.get("routing") or {}
rules = routing.get("rules")
if not isinstance(rules, list):
    raise SystemExit("Invalid Xray routing config")

canonical_rule = {
    "type": "field",
    "inboundTag": [tag4, tag6],
    "outboundTag": "warp",
}

filtered_rules = []
inserted = False
for rule in rules:
    if not isinstance(rule, dict):
        filtered_rules.append(rule)
        continue
    inbound_tags = rule.get("inboundTag")
    if isinstance(inbound_tags, list) and any(item in (tag4, tag6) for item in inbound_tags if isinstance(item, str)):
        continue
    filtered_rules.append(rule)
    if not inserted and rule.get("type") == "field" and isinstance(inbound_tags, list) and "api" in inbound_tags:
      filtered_rules.append(canonical_rule)
      inserted = True
if not inserted:
    filtered_rules.insert(0, canonical_rule)
routing["rules"] = filtered_rules
rt_cfg["routing"] = routing
dump_json(rt_dst, rt_cfg)
PY

    xray_write_file_atomic "${svc_conf}" "${tmp_svc}" || exit 1
    xray_write_file_atomic "${inb_conf}" "${tmp_inb}" || exit 1
    xray_write_file_atomic "${rt_conf}" "${tmp_rt}" || exit 1

    systemctl daemon-reload >/dev/null 2>&1 || true
    if ! xray_restart_checked; then
      restore_file_if_exists "${backup_svc}" "${svc_conf}"
      restore_file_if_exists "${backup_inb}" "${inb_conf}"
      restore_file_if_exists "${backup_rt}" "${rt_conf}"
      systemctl daemon-reload >/dev/null 2>&1 || true
      xray_restart_checked >/dev/null 2>&1 || true
      exit 86
    fi
      restore_file_if_exists "${backup_svc}" "${svc_conf}"
      restore_file_if_exists "${backup_inb}" "${inb_conf}"
      restore_file_if_exists "${backup_rt}" "${rt_conf}"
      systemctl daemon-reload >/dev/null 2>&1 || true
      xray_restart_checked >/dev/null 2>&1 || true
      exit 1
    fi
      restore_file_if_exists "${backup_svc}" "${svc_conf}"
      restore_file_if_exists "${backup_inb}" "${inb_conf}"
      restore_file_if_exists "${backup_rt}" "${rt_conf}"
      systemctl daemon-reload >/dev/null 2>&1 || true
      xray_restart_checked >/dev/null 2>&1 || true
      exit 1
    fi
    exit 0
  ) 200>"${ROUTING_LOCK_FILE}"
  rc=$?
  set -e

  rm -f "${tmp_inb}" "${tmp_rt}" "${tmp_svc}" >/dev/null 2>&1 || true
  return "${rc}"
}

  local port4="" port6="" chain_v4="" chain_v6="" chain_mark_v4="" chain_mark_v6="" fwmark=""
  local uid="" rc=0 arg="" mode="uids" cgroup_rel=""
  local -a warp_uids=() warp_users=()

  for arg in "$@"; do
    if [[ "${arg}" == "--users" ]]; then
      mode="users"
      continue
    fi
    if [[ "${mode}" == "users" ]]; then
      warp_users+=("${arg}")
    else
      warp_uids+=("${arg}")
    fi
  done

  have_cmd iptables || {
    return 1
  }
  have_cmd xray || {
    return 1
  }

    return 1
  fi
    return 1
  fi



  else
  fi

  iptables -t nat -N "${chain_v4}" >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -m addrtype --dst-type LOCAL -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 0.0.0.0/8 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 10.0.0.0/8 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 100.64.0.0/10 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 127.0.0.0/8 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 169.254.0.0/16 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 172.16.0.0/12 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 192.168.0.0/16 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 224.0.0.0/4 -j RETURN >/dev/null 2>&1 || rc=1
  iptables -t nat -A "${chain_v4}" -d 240.0.0.0/4 -j RETURN >/dev/null 2>&1 || rc=1
  if [[ -n "${cgroup_rel}" && "${fwmark}" =~ ^[0-9]+$ ]]; then
    iptables -t mangle -N "${chain_mark_v4}" >/dev/null 2>&1 || rc=1
    iptables -t mangle -A "${chain_mark_v4}" -m cgroup --path "${cgroup_rel}" -p tcp -j MARK --set-mark "${fwmark}" >/dev/null 2>&1 || rc=1
    iptables -t mangle -A OUTPUT -p tcp -j "${chain_mark_v4}" >/dev/null 2>&1 || rc=1
    iptables -t nat -A "${chain_v4}" -m mark --mark "${fwmark}" -p tcp -j REDIRECT --to-ports "${port4}" >/dev/null 2>&1 || rc=1
  fi
  for uid in "${warp_uids[@]}"; do
    iptables -t nat -A "${chain_v4}" -m owner --uid-owner "${uid}" -p tcp -j REDIRECT --to-ports "${port4}" >/dev/null 2>&1 || rc=1
  done
  iptables -t nat -A OUTPUT -p tcp -j "${chain_v4}" >/dev/null 2>&1 || rc=1

  if have_cmd ip6tables; then
    ip6tables -t nat -N "${chain_v6}" >/dev/null 2>&1 || rc=1
    ip6tables -t nat -A "${chain_v6}" -m addrtype --dst-type LOCAL -j RETURN >/dev/null 2>&1 || rc=1
    ip6tables -t nat -A "${chain_v6}" -d ::1/128 -j RETURN >/dev/null 2>&1 || rc=1
    ip6tables -t nat -A "${chain_v6}" -d fc00::/7 -j RETURN >/dev/null 2>&1 || rc=1
    ip6tables -t nat -A "${chain_v6}" -d fe80::/10 -j RETURN >/dev/null 2>&1 || rc=1
    ip6tables -t nat -A "${chain_v6}" -d ff00::/8 -j RETURN >/dev/null 2>&1 || rc=1
    if [[ -n "${cgroup_rel}" && "${fwmark}" =~ ^[0-9]+$ ]]; then
      ip6tables -t mangle -N "${chain_mark_v6}" >/dev/null 2>&1 || rc=1
      ip6tables -t mangle -A "${chain_mark_v6}" -m cgroup --path "${cgroup_rel}" -p tcp -j MARK --set-mark "${fwmark}" >/dev/null 2>&1 || rc=1
      ip6tables -t mangle -A OUTPUT -p tcp -j "${chain_mark_v6}" >/dev/null 2>&1 || rc=1
      ip6tables -t nat -A "${chain_v6}" -m mark --mark "${fwmark}" -p tcp -j REDIRECT --to-ports "${port6}" >/dev/null 2>&1 || rc=1
    fi
    for uid in "${warp_uids[@]}"; do
      ip6tables -t nat -A "${chain_v6}" -m owner --uid-owner "${uid}" -p tcp -j REDIRECT --to-ports "${port6}" >/dev/null 2>&1 || rc=1
    done
    ip6tables -t nat -A OUTPUT -p tcp -j "${chain_v6}" >/dev/null 2>&1 || rc=1
  fi

  if (( rc != 0 )); then
    return 1
  fi
  return 0
}

  local nft_table mark route_table rule_pref mark_hex=""
  local cfg
  nft_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^nft_table=/{print $2; exit}')"
  mark="$(printf '%s\n' "${cfg}" | awk -F'=' '/^fwmark=/{print $2; exit}')"
  route_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^route_table=/{print $2; exit}')"
  rule_pref="$(printf '%s\n' "${cfg}" | awk -F'=' '/^rule_pref=/{print $2; exit}')"
  if [[ "${mark}" =~ ^[0-9]+$ ]]; then
    printf -v mark_hex '0x%x' "${mark}"
  fi
  if have_cmd nft && [[ -n "${nft_table}" ]]; then
    nft delete table inet "${nft_table}" >/dev/null 2>&1 || true
  fi
  if have_cmd ip; then
    while ip rule del pref "${rule_pref}" fwmark "${mark_hex:-${mark}}" table "${route_table}" >/dev/null 2>&1; do :; done
    while ip rule del pref "${rule_pref}" fwmark "${mark}" table "${route_table}" >/dev/null 2>&1; do :; done
    while ip -6 rule del pref "${rule_pref}" fwmark "${mark_hex:-${mark}}" table "${route_table}" >/dev/null 2>&1; do :; done
    while ip -6 rule del pref "${rule_pref}" fwmark "${mark}" table "${route_table}" >/dev/null 2>&1; do :; done
    ip route flush table "${route_table}" >/dev/null 2>&1 || true
    ip -6 route flush table "${route_table}" >/dev/null 2>&1 || true
  fi
}

  local cfg nft_table mark route_table rule_pref warp_iface warp_backend backend_effective mark_hex=""
  local -a warp_uids=() warp_users=()
  local -a endpoint_v4=() endpoint_v6=()
  local username uid override effective
  local tmp="" warp_conf_path="" warp_conf_before="" warp_conf_after="" warp_cfg_changed="false"

  nft_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^nft_table=/{print $2; exit}')"
  mark="$(printf '%s\n' "${cfg}" | awk -F'=' '/^fwmark=/{print $2; exit}')"
  route_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^route_table=/{print $2; exit}')"
  rule_pref="$(printf '%s\n' "${cfg}" | awk -F'=' '/^rule_pref=/{print $2; exit}')"
  warp_backend="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"
  warp_iface="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_interface=/{print $2; exit}')"
  if [[ "${mark}" =~ ^[0-9]+$ ]]; then
    printf -v mark_hex '0x%x' "${mark}"
  fi

  while IFS='|' read -r username uid override effective; do
    [[ -n "${username}" ]] || continue
    [[ "${uid}" =~ ^[0-9]+$ ]] || continue
    [[ "${effective}" == "warp" ]] || continue
    warp_users+=("${username}")
    warp_uids+=("${uid}")

  if (( ${#warp_uids[@]} == 0 )); then
        return 1
      fi
    fi
    return 0
  fi

  if [[ "${backend_effective}" == "local-proxy" ]]; then
      return 1
    fi
    fi
    return 0
  fi

    return 1
  fi

  have_cmd nft || {
    return 1
  }
  have_cmd ip || {
    return 1
  }
  if [[ -z "${warp_iface}" ]]; then
    return 1
  fi
    return 1
  fi
  if [[ -n "${warp_conf_after}" && "${warp_conf_after}" != "${warp_conf_before}" ]]; then
    warp_cfg_changed="true"
  fi
  if ! ip link show "${warp_iface}" >/dev/null 2>&1; then
      return 1
    fi
    if ! ip link show "${warp_iface}" >/dev/null 2>&1; then
      return 1
    fi
  elif [[ "${warp_cfg_changed}" == "true" ]]; then
      return 1
    fi
  fi
  while IFS='|' read -r fam ipaddr; do
    [[ -n "${fam}" && -n "${ipaddr}" ]] || continue
    case "${fam}" in
      ipv4) endpoint_v4+=("${ipaddr}") ;;
      ipv6) endpoint_v6+=("${ipaddr}") ;;
    esac

  {
    printf 'table inet %s {\n' "${nft_table}"
    printf '  chain output {\n'
    printf '    type route hook output priority mangle; policy accept;\n'
    printf '    oifname "lo" return\n'
    printf '    ip daddr { 0.0.0.0/8, 10.0.0.0/8, 100.64.0.0/10, 127.0.0.0/8, 169.254.0.0/16, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4 } return\n'
    printf '    ip6 daddr { ::1/128, fc00::/7, fe80::/10, ff00::/8 } return\n'
    if (( ${#endpoint_v4[@]} > 0 )); then
      printf '    ip daddr { '
      printf '%s' "${endpoint_v4[0]}"
      local idx
      for ((idx=1; idx<${#endpoint_v4[@]}; idx++)); do
        printf ', %s' "${endpoint_v4[$idx]}"
      done
      printf ' } return\n'
    fi
    if (( ${#endpoint_v6[@]} > 0 )); then
      printf '    ip6 daddr { '
      printf '%s' "${endpoint_v6[0]}"
      local idx6
      for ((idx6=1; idx6<${#endpoint_v6[@]}; idx6++)); do
        printf ', %s' "${endpoint_v6[$idx6]}"
      done
      printf ' } return\n'
    fi
    local seen_uid="" uid_entry=""
    while IFS= read -r uid_entry; do
      [[ "${uid_entry}" == "${seen_uid}" ]] && continue
      seen_uid="${uid_entry}"
      printf '    meta skuid %s meta mark set %s\n' "${uid_entry}" "${mark}"
    done < <(printf '%s\n' "${warp_uids[@]}" | sort -n)
    printf '  }\n'
    printf '}\n'
  } > "${tmp}"

  if ! nft -f "${tmp}" >/dev/null 2>&1; then
    rm -f "${tmp}" >/dev/null 2>&1 || true
    return 1
  fi
  rm -f "${tmp}" >/dev/null 2>&1 || true

  ip route replace table "${route_table}" default dev "${warp_iface}" >/dev/null 2>&1 || {
    return 1
  }
  ip -6 route replace table "${route_table}" default dev "${warp_iface}" >/dev/null 2>&1 || true
  ip rule add pref "${rule_pref}" fwmark "${mark_hex:-${mark}}" table "${route_table}" >/dev/null 2>&1 || {
    return 1
  }
  ip -6 rule add pref "${rule_pref}" fwmark "${mark_hex:-${mark}}" table "${route_table}" >/dev/null 2>&1 || true
  return 0
}

  local cfg warp_backend backend_effective="" username="" uid="" override="" effective=""
  local -a warp_users=()

  warp_backend="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"

  if [[ "${backend_effective}" != "local-proxy" ]]; then
    return 0
  fi

  while IFS='|' read -r username uid override effective; do
    [[ -n "${username}" ]] || continue
    [[ "${effective}" == "warp" ]] || continue
    warp_users+=("${username}")

  if (( ${#warp_users[@]} == 0 )); then
    return 0
  fi

    return 1
  fi
  return 0
}

    return $?
  fi
    return $?
  fi
}

    return $?
  fi
    return $?
  fi
}

}

  local cfg global_mode nft_table mark route_table rule_pref warp_iface warp_backend xray_redir_port xray_redir_port_v6 mark_hex=""
  local backend_effective="" backend_applied="idle" xray_redir_v4_state="not-listening" xray_redir_v6_state="not-listening"
  local xray_redir_v4_listener_state="not-listening" xray_redir_v6_listener_state="not-listening"
  local iptables_state="absent" ip6tables_state="absent" host_warp_mode="" host_warp_backend="" host_warp_service=""
  local host_warp_service_state="missing" host_warp_proxy_port="" host_warp_proxy_state="not-listening"
  local chain_v4="" chain_v6=""
  local nft_state="absent" ip_rule_state="absent" ip_rule_v6_state="absent" iface_state="missing"
  local route_table_v4_state="absent" route_table_v6_state="absent"
  local effective_warp_users="0" warp_conf_state="missing" warp_service_state="missing"
  local warp_unit="" warp_conf_path="" route_v4_lines="" route_v6_lines=""
  global_mode="$(printf '%s\n' "${cfg}" | awk -F'=' '/^global_mode=/{print $2; exit}')"
  nft_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^nft_table=/{print $2; exit}')"
  mark="$(printf '%s\n' "${cfg}" | awk -F'=' '/^fwmark=/{print $2; exit}')"
  route_table="$(printf '%s\n' "${cfg}" | awk -F'=' '/^route_table=/{print $2; exit}')"
  rule_pref="$(printf '%s\n' "${cfg}" | awk -F'=' '/^rule_pref=/{print $2; exit}')"
  warp_backend="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"
  warp_iface="$(printf '%s\n' "${cfg}" | awk -F'=' '/^warp_interface=/{print $2; exit}')"
  xray_redir_port="$(printf '%s\n' "${cfg}" | awk -F'=' '/^xray_redir_port=/{print $2; exit}')"
  xray_redir_port_v6="$(printf '%s\n' "${cfg}" | awk -F'=' '/^xray_redir_port_v6=/{print $2; exit}')"
  if [[ "${mark}" =~ ^[0-9]+$ ]]; then
    printf -v mark_hex '0x%x' "${mark}"
  fi
  if have_cmd nft && nft list table inet "${nft_table}" >/dev/null 2>&1; then
    nft_state="present"
  fi
  if have_cmd ip; then
    if ip rule show 2>/dev/null | grep -Eiq "(^| )${rule_pref}:.*fwmark (${mark}|${mark_hex:-${mark}})(/0xffffffff)? .*lookup ${route_table}( |$)"; then
      ip_rule_state="present"
    fi
    if ip -6 rule show 2>/dev/null | grep -Eiq "(^| )${rule_pref}:.*fwmark (${mark}|${mark_hex:-${mark}})(/0xffffffff)? .*lookup ${route_table}( |$)"; then
      ip_rule_v6_state="present"
    fi
    route_v4_lines="$(ip route show table "${route_table}" 2>/dev/null || true)"
    if [[ -n "${route_v4_lines//[$' \t\r\n']/}" ]]; then
      if [[ -n "${warp_iface}" && " ${route_v4_lines//$'\n'/ } " == *" dev ${warp_iface} "* ]]; then
        route_table_v4_state="present"
      else
        route_table_v4_state="mismatch"
      fi
    fi
    route_v6_lines="$(ip -6 route show table "${route_table}" 2>/dev/null || true)"
    if [[ -n "${route_v6_lines//[$' \t\r\n']/}" ]]; then
      if [[ -n "${warp_iface}" && " ${route_v6_lines//$'\n'/ } " == *" dev ${warp_iface} "* ]]; then
        route_table_v6_state="present"
      else
        route_table_v6_state="mismatch"
      fi
    fi
  fi
  if [[ -n "${warp_iface}" ]] && have_cmd ip && ip link show "${warp_iface}" >/dev/null 2>&1; then
    iface_state="present"
  fi
  if [[ -n "${warp_iface}" ]]; then
    [[ -n "${warp_conf_path}" && -f "${warp_conf_path}" ]] && warp_conf_state="present"
    if systemctl cat "wg-quick@.service" >/dev/null 2>&1 || { [[ -n "${warp_unit}" ]] && systemctl cat "${warp_unit}" >/dev/null 2>&1; }; then
      warp_service_state="$(svc_state "${warp_unit}")"
      [[ -n "${warp_service_state}" ]] || warp_service_state="inactive"
    fi
  fi
  if have_cmd iptables; then
    if iptables -t nat -S OUTPUT 2>/dev/null | grep -Fq -- "-A OUTPUT -p tcp -j ${chain_v4}"; then
      iptables_state="present"
    fi
  fi
  if have_cmd ip6tables; then
    if ip6tables -t nat -S OUTPUT 2>/dev/null | grep -Fq -- "-A OUTPUT -p tcp -j ${chain_v6}"; then
      ip6tables_state="present"
    fi
  fi
  if have_cmd ip6tables; then
  else
    xray_redir_v6_listener_state="missing"
  fi
    "${iptables_state}" "${ip6tables_state}" "${nft_state}" "${ip_rule_state}" "${ip_rule_v6_state}" \
    "${route_table_v4_state}" "${route_table_v6_state}" "${iface_state}" "${warp_service_state}" \
    "${xray_redir_v4_state}" "${xray_redir_v6_state}" "${host_warp_proxy_state}")"
  printf 'global_mode=%s\n' "${global_mode}"
  printf 'nft_table=%s\n' "${nft_table}"
  printf 'fwmark=%s\n' "${mark}"
  printf 'route_table=%s\n' "${route_table}"
  printf 'rule_pref=%s\n' "${rule_pref}"
  printf 'warp_backend=%s\n' "${warp_backend:-auto}"
  printf 'warp_backend_effective=%s\n' "${backend_effective}"
  printf 'warp_backend_applied=%s\n' "${backend_applied}"
  printf 'warp_interface=%s\n' "${warp_iface}"
  printf 'warp_interface_state=%s\n' "${iface_state}"
  printf 'warp_config_state=%s\n' "${warp_conf_state}"
  printf 'warp_service_state=%s\n' "${warp_service_state}"
  printf 'xray_redir_port=%s\n' "${xray_redir_port}"
  printf 'xray_redir_port_v6=%s\n' "${xray_redir_port_v6}"
  printf 'xray_redir_v4_state=%s\n' "${xray_redir_v4_state}"
  printf 'xray_redir_v6_state=%s\n' "${xray_redir_v6_state}"
  printf 'iptables_state=%s\n' "${iptables_state}"
  printf 'ip6tables_state=%s\n' "${ip6tables_state}"
  printf 'host_warp_mode=%s\n' "${host_warp_mode}"
  printf 'host_warp_backend=%s\n' "${host_warp_backend}"
  printf 'host_warp_service=%s\n' "${host_warp_service}"
  printf 'host_warp_service_state=%s\n' "${host_warp_service_state}"
  printf 'host_warp_proxy_port=%s\n' "${host_warp_proxy_port}"
  printf 'host_warp_proxy_state=%s\n' "${host_warp_proxy_state}"
  printf 'nft_state=%s\n' "${nft_state}"
  printf 'ip_rule_state=%s\n' "${ip_rule_state}"
  printf 'ip_rule_v6_state=%s\n' "${ip_rule_v6_state}"
  printf 'route_table_v4_state=%s\n' "${route_table_v4_state}"
  printf 'route_table_v6_state=%s\n' "${route_table_v6_state}"
  printf 'effective_warp_users=%s\n' "${effective_warp_users}"
}

  local username uid override effective
  printf "%-18s %-8s %-10s %-10s\n" "Username" "UID" "Override" "Effective"
  hr
  while IFS='|' read -r username uid override effective; do
    [[ -n "${username}" ]] || continue
    printf "%-18s %-8s %-10s %-10s\n" "${username}" "${uid:--}" "${override}" "${effective}"
}

  local -n _out_ref="$1"
  _out_ref=""

  local -a users=()
  local name="" uid="" override="" effective=""
  while IFS='|' read -r name uid override effective; do
    [[ -n "${name}" ]] || continue
    users+=("${name}")

  if (( ${#users[@]} > 1 )); then
    mapfile -t users < <(printf '%s\n' "${users[@]}" | sort -u)
  fi

  if (( ${#users[@]} == 0 )); then
    return 1
  fi

  local i pick
  for i in "${!users[@]}"; do
    printf "  %d) %s\n" "$((i + 1))" "${users[$i]}"
  done

  while true; do
    if ! read -r -p "Nomor akun (1-${#users[@]}/kembali): " pick; then
      echo
      return 1
    fi
    if is_back_choice "${pick}"; then
      return 1
    fi
    [[ "${pick}" =~ ^[0-9]+$ ]] || {
      warn "Input tidak valid."
      continue
    }
    if (( pick < 1 || pick > ${#users[@]} )); then
      warn "Nomor di luar daftar."
      continue
    fi
    _out_ref="${users[$((pick - 1))]}"
    return 0
  done
}

  local suffix="${1:-}"
  if [[ -n "${suffix}" ]]; then
  else
  fi
}

  while true; do
    local st cfg enabled dns_port primary secondary dns_service sync_service nft_table users_count
    local dns_state dns_state_raw sync_state sync_state_raw
    enabled="$(printf '%s\n' "${st}" | awk -F'=' '/^enabled=/{print $2; exit}')"
    dns_port="$(printf '%s\n' "${cfg}" | awk -F'=' '/^dns_port=/{print $2; exit}')"
    primary="$(printf '%s\n' "${cfg}" | awk -F'=' '/^upstream_primary=/{print $2; exit}')"
    secondary="$(printf '%s\n' "${cfg}" | awk -F'=' '/^upstream_secondary=/{print $2; exit}')"
    dns_service="$(printf '%s\n' "${st}" | awk -F'=' '/^dns_service=/{print $2; exit}')"
    dns_state_raw="$(printf '%s\n' "${st}" | awk -F'=' '/^dns_service_state=/{print $2; exit}')"
    sync_service="$(printf '%s\n' "${st}" | awk -F'=' '/^sync_service=/{print $2; exit}')"
    sync_state_raw="$(printf '%s\n' "${st}" | awk -F'=' '/^sync_service_state=/{print $2; exit}')"
    nft_table="$(printf '%s\n' "${st}" | awk -F'=' '/^nft_table=/{print $2; exit}')"
    users_count="$(printf '%s\n' "${st}" | awk -F'=' '/^users_count=/{print $2; exit}')"
    if [[ -n "${dns_state_raw}" ]]; then
      dns_state="${dns_state_raw}"
    elif [[ -n "${dns_service}" && "${dns_service}" != "missing" ]] && svc_exists "${dns_service}"; then
      dns_state="$(svc_state "${dns_service}")"
    else
      dns_state="missing"
    fi
    if [[ -n "${sync_state_raw}" ]]; then
      sync_state="${sync_state_raw}"
    elif [[ -n "${sync_service}" && "${sync_service}" != "missing" ]] && svc_exists "${sync_service}"; then
      sync_state="$(svc_state "${sync_service}")"
    else
      sync_state="missing"
    fi
    [[ -n "${primary}" ]] || primary="1.1.1.1"
    [[ -n "${secondary}" ]] || secondary="8.8.8.8"

    title
    hr
    printf "%-14s : %s\n" "Backend" "dnsmasq + nft meta skuid"
    printf "%-14s : %s\n" "Steering" "$([[ "${enabled}" == "1" ]] && echo "ON" || echo "OFF")"
    printf "%-14s : %s\n" "DNS Service" "${dns_service:--}"
    printf "%-14s : %s\n" "DNS State" "${dns_state:--}"
    printf "%-14s : %s\n" "Sync Service" "${sync_service:--}"
    printf "%-14s : %s\n" "Sync State" "${sync_state:--}"
    printf "%-14s : %s\n" "NFT Table" "${nft_table:--}"
    printf "%-14s : %s\n" "Managed Users" "${users_count:-0}"
    printf "%-14s : %s\n" "DNS Port" "${dns_port}"
    printf "%-14s : %s\n" "Primary DNS" "${primary}"
    printf "%-14s : %s\n" "Secondary DNS" "${secondary}"
    hr
    echo "  1) Enable DNS Steering"
    echo "  2) Disable DNS Steering"
    echo "  3) Set Primary DNS"
    echo "  4) Set Secondary DNS"
    echo "  5) Apply DNS Runtime"
    echo "  0) Back"
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi
    case "${c}" in
      1)
          warn "Enable DNS steering dibatalkan."
        else
        fi
        pause
        ;;
      2)
          warn "Disable DNS steering dibatalkan."
        else
        fi
        pause
        ;;
      3)
        local new_primary
          echo
          return 0
        fi
        if is_back_choice "${new_primary}"; then
          continue
        fi
        new_primary="$(dns_server_literal_normalize "${new_primary}")" || {
          pause
          continue
        }
          pause
          continue
        fi
        else
        fi
        pause
        ;;
      4)
        local new_secondary
          echo
          return 0
        fi
        if is_back_choice "${new_secondary}"; then
          continue
        fi
        new_secondary="$(dns_server_literal_normalize "${new_secondary}")" || {
          pause
          continue
        }
          pause
          continue
        fi
        else
        fi
        pause
        ;;
      5)
        else
        fi
        pause
        ;;
      0|kembali|k|back|b) return 0 ;;
      *) invalid_choice ;;
    esac
  done
}

  while true; do
    local st global_mode warp_iface warp_backend warp_backend_effective warp_backend_applied host_warp_mode host_warp_service_state
    local host_warp_proxy_state host_warp_proxy_port effective_warp_users
    global_mode="$(printf '%s\n' "${st}" | awk -F'=' '/^global_mode=/{print $2; exit}')"
    warp_backend="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"
    warp_backend_effective="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_effective=/{print $2; exit}')"
    warp_backend_applied="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_applied=/{print $2; exit}')"
    warp_iface="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_interface=/{print $2; exit}')"
    host_warp_mode="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_mode=/{print $2; exit}')"
    host_warp_service_state="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_service_state=/{print $2; exit}')"
    host_warp_proxy_port="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_proxy_port=/{print $2; exit}')"
    host_warp_proxy_state="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_proxy_state=/{print $2; exit}')"
    effective_warp_users="$(printf '%s\n' "${st}" | awk -F'=' '/^effective_warp_users=/{print $2; exit}')"

    title
    hr
    printf "%-18s : %s\n" "Global Mode" "${global_mode}"
    printf "%-18s : %s\n" "WARP Iface" "${warp_iface}"
    printf "%-18s : %s\n" "Host WARP Mode" "${host_warp_mode}"
    printf "%-18s : %s\n" "Host WARP Svc" "${host_warp_service_state}"
    printf "%-18s : %s\n" "Host WARP SOCKS" "${host_warp_proxy_state} (127.0.0.1:${host_warp_proxy_port:-40000})"
    printf "%-18s : %s\n" "Effective Warp Users" "${effective_warp_users}"
    hr
    hr
    echo "  1) Set Global Mode: Direct"
    echo "  2) Set Global Mode: WARP"
    echo "  3) Save WARP Backend (config only)"
    echo "  4) Apply Routing Runtime"
    echo "  0) Back"
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi
    case "${c}" in
      1)
          warn "Set routing global direct dibatalkan."
        else
        fi
        pause
        ;;
      2)
          warn "Set routing global WARP dibatalkan."
        else
        fi
        pause
        ;;
      3)
        local backend_pick=""
          echo
          return 0
        fi
        backend_pick="$(printf '%s' "${backend_pick}" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
        if is_back_choice "${backend_pick}"; then
          continue
        fi
          pause
          continue
        fi
        else
        fi
        pause
        ;;
      4)
        else
        fi
        pause
        ;;
      0|kembali|k|back|b) return 0 ;;
      *) invalid_choice ;;
    esac
  done
}

  while true; do
    local st="" backend_effective="" backend_applied="" menu_context=""
    local menu_title="" backend_label="" target_label="" option1="" option2="" option3=""
    local mode1="" mode2="" mode3="" confirm_prompt="" cancel_msg="" success_msg="" fail_msg=""
    backend_effective="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_effective=/{print $2; exit}')"
    backend_applied="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_applied=/{print $2; exit}')"
    if [[ "${menu_context}" == "warp" ]]; then
      backend_label="Kontrol WARP per-user"
      target_label="enable / disable / inherit"
      option1="Enable WARP for User"
      option2="Disable WARP for User"
      option3="Reset User to Inherit"
      mode1="warp"
      mode2="direct"
      mode3="inherit"
    else
      target_label="inherit / direct / warp"
      option1="Set User: Inherit"
      option2="Set User: Direct"
      option3="Set User: WARP"
      mode1="inherit"
      mode2="direct"
      mode3="warp"
    fi
    title
    hr
    printf "%-18s : %s\n" "Backend" "${backend_label}"
    if [[ "${menu_context}" == "warp" ]]; then
    fi
    printf "%-18s : %s\n" "Target" "${target_label}"
    hr
    hr
    echo "  1) ${option1}"
    echo "  2) ${option2}"
    echo "  3) ${option3}"
    if [[ "${menu_context}" == "warp" ]]; then
      echo "  4) Apply WARP Runtime"
    else
      echo "  4) Apply Routing Runtime"
    fi
    echo "  0) Back"
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi
    case "${c}" in
      1|2|3)
        local target_user="" target_mode=""
        case "${c}" in
          1) target_mode="${mode1}" ;;
          2) target_mode="${mode2}" ;;
          3) target_mode="${mode3}" ;;
        esac
          pause
          continue
        fi
        if [[ "${menu_context}" == "warp" ]]; then
          cancel_msg="Set mode WARP user dibatalkan."
        else
          cancel_msg="Set routing user dibatalkan."
        fi
        if ! confirm_yn_or_back "${confirm_prompt}"; then
          warn "${cancel_msg}"
          log "${success_msg}"
        else
          warn "${fail_msg}"
        fi
        pause
        ;;
      4)
          if [[ "${menu_context}" == "warp" ]]; then
          else
          fi
        else
          if [[ "${menu_context}" == "warp" ]]; then
          else
          fi
        fi
        pause
        ;;
      0|kembali|k|back|b) return 0 ;;
      *) invalid_choice ;;
    esac
  done
}

  while true; do
    local st global_mode warp_backend warp_backend_effective warp_backend_applied effective_warp_users
    local xray_redir_v4_state xray_redir_v6_state
    local iptables_state ip6tables_state host_warp_mode host_warp_backend host_warp_service_state host_warp_proxy_state host_warp_proxy_port
    global_mode="$(printf '%s\n' "${st}" | awk -F'=' '/^global_mode=/{print $2; exit}')"
    warp_backend="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend=/{print $2; exit}')"
    warp_backend_effective="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_effective=/{print $2; exit}')"
    warp_backend_applied="$(printf '%s\n' "${st}" | awk -F'=' '/^warp_backend_applied=/{print $2; exit}')"
    xray_redir_v4_state="$(printf '%s\n' "${st}" | awk -F'=' '/^xray_redir_v4_state=/{print $2; exit}')"
    xray_redir_v6_state="$(printf '%s\n' "${st}" | awk -F'=' '/^xray_redir_v6_state=/{print $2; exit}')"
    iptables_state="$(printf '%s\n' "${st}" | awk -F'=' '/^iptables_state=/{print $2; exit}')"
    ip6tables_state="$(printf '%s\n' "${st}" | awk -F'=' '/^ip6tables_state=/{print $2; exit}')"
    host_warp_mode="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_mode=/{print $2; exit}')"
    host_warp_backend="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_backend=/{print $2; exit}')"
    host_warp_service_state="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_service_state=/{print $2; exit}')"
    host_warp_proxy_state="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_proxy_state=/{print $2; exit}')"
    host_warp_proxy_port="$(printf '%s\n' "${st}" | awk -F'=' '/^host_warp_proxy_port=/{print $2; exit}')"
    effective_warp_users="$(printf '%s\n' "${st}" | awk -F'=' '/^effective_warp_users=/{print $2; exit}')"
    title
    hr
    printf "%-18s : %s\n" "Global WARP" "$([[ "${global_mode}" == "warp" ]] && echo "ON" || echo "OFF")"
    printf "%-18s : %s\n" "Host WARP Mode" "${host_warp_mode}"
    printf "%-18s : %s\n" "Host Backend" "${host_warp_backend}"
    printf "%-18s : %s\n" "Host Service" "${host_warp_service_state}"
    printf "%-18s : %s\n" "Host SOCKS" "${host_warp_proxy_state} (127.0.0.1:${host_warp_proxy_port:-40000})"
    printf "%-18s : %s\n" "Xray Redir IPv4" "${xray_redir_v4_state}"
    printf "%-18s : %s\n" "Xray Redir IPv6" "${xray_redir_v6_state}"
    printf "%-18s : %s\n" "iptables IPv4" "${iptables_state}"
    printf "%-18s : %s\n" "ip6tables IPv6" "${ip6tables_state}"
    printf "%-18s : %s\n" "Effective Warp Users" "${effective_warp_users}"
    hr
    echo "  1) Enable WARP Global"
    echo "  2) Disable WARP Global"
    echo "  0) Back"
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi
    case "${c}" in
      1)
        else
        fi
        pause
        ;;
      2)
        else
        fi
        pause
        ;;
      0|kembali|k|back|b) return 0 ;;
      *) invalid_choice ;;
    esac
  done
}

}

  # shellcheck disable=SC2034 # used by ui_menu_render_options via nameref
  local -a items=(
    "0|Back"
  )
  while true; do
    ui_menu_render_options items 76
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi
    case "${c}" in
      0|kembali|k|back|b) return 0 ;;
      *) invalid_choice ;;
    esac
  done
}

  local pending_count=0
  local -a items=(
    "1|Add User"
    "2|Delete User"
    "3|Set Expiry"
    "4|Reset Password"
    "5|List Users"
    "6|Recover Pending Txn"
    "0|Back"
  )
  while true; do
    [[ "${pending_count}" =~ ^[0-9]+$ ]] || pending_count=0
    if (( pending_count > 0 )); then
      hr
    fi
    ui_menu_render_options items 76
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      break
    fi
    case "${c}" in
      1)
        if (( pending_count > 0 )); then
          pause
        else
        fi
        ;;
      2)
        if (( pending_count > 0 )); then
          pause
        else
        fi
        ;;
      3)
        if (( pending_count > 0 )); then
          pause
        else
        fi
        ;;
      4)
        if (( pending_count > 0 )); then
          pause
        else
        fi
        ;;
      0|kembali|k|back|b) break ;;
      *) invalid_choice ;;
    esac
  done
}

# -------------------------
