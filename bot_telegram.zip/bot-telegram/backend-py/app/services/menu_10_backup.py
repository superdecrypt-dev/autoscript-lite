from ..adapters import backup_restore
from ..utils.response import error_response, ok_response
from ..utils.validators import require_param


def handle(action: str, params: dict, settings) -> dict:
    if action == "list_backups":
        ok, title, msg = backup_restore.op_backup_list()
        if ok:
            return ok_response(title, msg)
        return error_response("backup_list_failed", title, msg)

    if action == "create_backup":
        ok, title, msg, data = backup_restore.op_backup_create()
        if ok:
            return ok_response(title, msg, data=data if isinstance(data, dict) else None)
        return error_response("backup_create_failed", title, msg)

    if action == "restore_latest":
        ok, title, msg = backup_restore.op_restore_latest_local()
        if ok:
            return ok_response(title, msg)
        return error_response("backup_restore_latest_failed", title, msg)

    if action == "restore_from_upload":
        ok_param, upload_or_err = require_param(params, "upload_path", "Backup/Restore - Restore Upload")
        if not ok_param:
            return upload_or_err
        ok, title, msg = backup_restore.op_restore_from_upload(str(upload_or_err))
        if ok:
            return ok_response(title, msg)
        return error_response("backup_restore_upload_failed", title, msg)

    return error_response("unknown_action", "Backup/Restore", f"Action tidak dikenal: {action}")
