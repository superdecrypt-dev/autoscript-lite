from ..adapters import system, system_mutations
from ..utils.response import error_response, ok_response
from ..utils.validators import parse_bool_value, require_param


def handle(action: str, params: dict, settings) -> dict:
    if action == "domain_info":
        title, msg = system.op_domain_info()
        return ok_response(title, msg)
    if action == "tls_info":
        ok, title, msg = system.op_tls_info()
        if ok:
            return ok_response(title, msg)
        return error_response("tls_info_failed", title, msg)
    if action == "tls_expiry":
        title, msg = system.op_tls_expiry()
        return ok_response(title, msg)
    if action == "nginx_server_name":
        title, msg = system.op_domain_nginx_server_name()
        return ok_response(title, msg)
    if action == "setup_domain_custom":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        ok_d, domain_or_err = require_param(params, "domain", "Domain Control - Set Domain (Custom)")
        if not ok_d:
            return domain_or_err
        ok_set, title, msg = system_mutations.op_domain_setup_custom(str(domain_or_err))
        if ok_set:
            return ok_response(title, msg)
        return error_response("setup_domain_custom_failed", title, msg)
    if action == "setup_domain_cloudflare":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        title = "Domain Control - Set Domain Auto"
        warnings: list[str] = []
        ok_r, root_or_err = require_param(params, "root_domain", title)
        if not ok_r:
            return root_or_err
        proxied = False
        proxied_raw = str(params.get("proxied", "") or "").strip()
        if proxied_raw:
            proxied_parsed = parse_bool_value(proxied_raw, default=None)
            if proxied_parsed is None:
                warnings.append("Input 'proxied' tidak valid, default dipakai: OFF.")
            else:
                proxied = bool(proxied_parsed)

        allow_existing = False
        allow_existing_raw = str(params.get("allow_existing_same_ip", "") or "").strip()
        if allow_existing_raw:
            allow_existing_parsed = parse_bool_value(allow_existing_raw, default=None)
            if allow_existing_parsed is None:
                warnings.append("Input 'allow_existing_same_ip' tidak valid, default dipakai: OFF.")
            else:
                allow_existing = bool(allow_existing_parsed)

        ok_set, title, msg = system_mutations.op_domain_setup_cloudflare(
            root_domain_input=str(root_or_err),
            subdomain_mode="auto",
            subdomain="",
            proxied=bool(proxied),
            allow_existing_same_ip=bool(allow_existing),
        )
        warning_data = {"warnings": warnings} if warnings else None
        if warnings:
            msg = msg + "\n\nCatatan input:\n- " + "\n- ".join(warnings)
        if ok_set:
            return ok_response(title, msg, data=warning_data)
        return error_response("setup_domain_cloudflare_failed", title, msg, data=warning_data)
    if action == "set_domain":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        ok_d, domain_or_err = require_param(params, "domain", "Domain Control - Set Domain")
        if not ok_d:
            return domain_or_err
        issue_cert = parse_bool_value(params.get("issue_cert"), default=False)
        ok_set, title, msg = system_mutations.op_domain_set(str(domain_or_err), issue_cert=bool(issue_cert))
        if ok_set:
            return ok_response(title, msg)
        return error_response("set_domain_failed", title, msg)
    if action == "refresh_account_info":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        ok_ref, title, msg = system_mutations.op_domain_refresh_accounts()
        if ok_ref:
            return ok_response(title, msg)
        return error_response("domain_refresh_failed", title, msg)
    if action == "renew_cert":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        ok, title, msg = system_mutations.op_security_renew_cert()
        if ok:
            return ok_response(title, msg)
        return error_response("renew_cert_failed", title, msg)
    if action == "domain_guard_check":
        ok_chk, title, msg = system.op_domain_guard_check()
        if ok_chk:
            return ok_response(title, msg)
        return error_response("domain_guard_check_failed", title, msg)
    if action == "domain_guard_status":
        ok_status, title, msg = system.op_domain_guard_status()
        if ok_status:
            return ok_response(title, msg)
        return error_response("domain_guard_status_failed", title, msg)
    if action == "domain_guard_renew":
        if not settings.mutations_enabled:
            return error_response("forbidden", "Domain Control", "Dangerous actions dinonaktifkan via env.")
        force = bool(parse_bool_value(params.get("force"), default=False))
        ok_run, title, msg = system.op_domain_guard_renew_if_needed(force=force)
        if ok_run:
            return ok_response(title, msg)
        return error_response("domain_guard_renew_failed", title, msg)
    return error_response("unknown_action", "Domain Control", f"Action tidak dikenal: {action}")
