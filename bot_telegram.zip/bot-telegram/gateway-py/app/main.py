from __future__ import annotations
import asyncio
import io
import logging
import os
import re
import socket
import time
from dataclasses import dataclass
import html
from pathlib import Path

from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, NetworkError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from .backend_client import (
    BackendClient,
    BackendDomainOption,
    BackendError,
    BackendInboundOption,
    BackendRootDomainOption,
    BackendUserOption,
)
from .commands_loader import ActionSpec, CommandCatalog, MenuSpec
from .config import AppConfig, load_config
from .render import (
    action_form_prompt,
    action_result_text,
    confirm_text,
    decode_download_payload,
    main_menu_text,
    menu_text,
    sanitize_download_attachment,
)


LOGGER = logging.getLogger("bot-telegram-gateway")
BACKEND_MENU_SYNC_TIMEOUT_SECONDS = 30.0
BACKEND_MENU_SYNC_RETRY_INTERVAL_SECONDS = 1.0
TELEGRAM_TOKEN_RE = re.compile(r"\b\d{6,}:[A-Za-z0-9_-]{20,}\b")
DISCORD_TOKEN_RE = re.compile(r"\b[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{20,}\b")
BEARER_RE = re.compile(r"(?i)\bBearer\s+([A-Za-z0-9._~-]{16,})")
CALLBACK_SEP = "|"
ACTIONS_PER_PAGE = 6
BUTTONS_PER_ROW = 2
BUTTON_LABEL_MAX = 28
CALLBACK_DATA_MAX_LEN = 96
CLEANUP_FULL_SWEEP = -1
CLEANUP_MAX_LIMIT = 200
CLEANUP_KEEP_MESSAGES = 1
CLEANUP_MAX_SCAN_IDS = 2000
DELETE_PICK_PAGE_SIZE = 12
FORM_CHOICE_PAGE_SIZE = 12
XRAY_PROTOCOLS = ("vless", "vmess", "trojan")
USER_PROTOCOLS = XRAY_PROTOCOLS + ("ssh",)
XRAY_USER_MENU_ID = "22"
SSH_USER_MENU_ID = "23"
XRAY_QAC_MENU_ID = "24"
SSH_QAC_MENU_ID = "25"
BACKUP_MENU_ID = "32"
SSH_NETWORK_MENU_IDS = {"34", "37", "38", "39", "40", "41"}
DELETE_PICK_MENU_IDS = {XRAY_USER_MENU_ID, SSH_USER_MENU_ID}
QAC_MENU_IDS = {XRAY_QAC_MENU_ID, SSH_QAC_MENU_ID}
ACCOUNT_PICK_ACTION_IDS = {"account_info", "delete_user", "extend_expiry", "reset_password", "reset_credential"}
ROOT_DOMAIN_FALLBACK_OPTIONS = (
    "vyxara1.web.id",
    "vyxara2.web.id",
)
FORM_CHOICE_MANUAL_VALUE = "__manual_input__"
FORM_CHOICE_SKIP_VALUE = "__skip_optional__"
FORM_CHOICE_USERNAME_ACTIONS = {
    "extend_expiry",
    "account_info",
    "reset_password",
    "reset_credential",
    "detail",
    "set_quota_limit",
    "reset_quota_used",
    "manual_block",
    "ip_limit_enable",
    "set_ip_limit",
    "unlock_ip_lock",
    "set_speed_download",
    "set_speed_upload",
    "speed_limit",
    "set_warp_user_mode",
    "routing_ssh_user_inherit",
    "routing_ssh_user_direct",
    "routing_ssh_user_warp",
    "warp_ssh_user_enable",
    "warp_ssh_user_disable",
    "warp_ssh_user_inherit",
}
SSH_ONLY_PROTOCOL_ACTIONS = {
    "reset_password",
}
KEY_PENDING_FORM = "pending_form"
KEY_PENDING_CONFIRM = "pending_confirm"
KEY_PENDING_DELETE_PICK = "pending_delete_pick"
KEY_PENDING_QAC_PICK = "pending_qac_pick"
KEY_PENDING_ACCOUNT_PICK = "pending_account_pick"
KEY_PENDING_UPLOAD_RESTORE = "pending_upload_restore"
KEY_LAST_ACTION_TS = "last_action_ts"
KEY_LAST_CLEANUP_TS = "last_cleanup_ts"
KEY_QAC_SELECTIONS = "qac_selections"
KEY_MENU_PARENT_PAGES = "menu_parent_pages"
PENDING_STATE_KEYS = (
    KEY_PENDING_FORM,
    KEY_PENDING_CONFIRM,
    KEY_PENDING_DELETE_PICK,
    KEY_PENDING_QAC_PICK,
    KEY_PENDING_ACCOUNT_PICK,
    KEY_PENDING_UPLOAD_RESTORE,
)
PENDING_OTHER_CHAT_TEXT = "Sesi aktif ada di chat lain. Lanjutkan dari chat asal atau mulai ulang dengan /menu."
BOT_ROOT = Path(__file__).resolve().parents[2]
BOT_HOME = Path((os.getenv("BOT_HOME") or "").strip() or str(BOT_ROOT))
BOT_STATE_DIR = Path(os.getenv("BOT_STATE_DIR", "/var/lib/bot-telegram"))
UPLOAD_RESTORE_MAX_BYTES = 20 * 1024 * 1024
UPLOAD_RESTORE_DIRS = (
    BOT_STATE_DIR / "tmp" / "uploads",
    BOT_HOME / "runtime" / "tmp" / "uploads",
)
DOWNLOAD_LOCAL_ALLOW_DIRS = (
    BOT_STATE_DIR / "backups" / "archives",
    BOT_HOME / "runtime" / "backups" / "archives",
)


@dataclass
class Runtime:
    config: AppConfig
    catalog: CommandCatalog
    backend: BackendClient
    hostname: str


def _mask_secret(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return raw
    if len(raw) <= 8:
        return "********"
    return f"{raw[:4]}****{raw[-4:]}"


def _sanitize_log_text(value: str) -> str:
    text = str(value or "")
    text = TELEGRAM_TOKEN_RE.sub(lambda match: _mask_secret(match.group(0)), text)
    text = DISCORD_TOKEN_RE.sub(lambda match: _mask_secret(match.group(0)), text)
    text = BEARER_RE.sub(lambda match: f"Bearer {_mask_secret(match.group(1))}", text)
    return text


def _sanitize_log_value(value):
    if isinstance(value, str):
        return _sanitize_log_text(value)
    if isinstance(value, tuple):
        return tuple(_sanitize_log_value(item) for item in value)
    if isinstance(value, list):
        return [_sanitize_log_value(item) for item in value]
    if isinstance(value, dict):
        return {key: _sanitize_log_value(item) for key, item in value.items()}
    return value


class SecretMaskingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            if isinstance(record.msg, str):
                record.msg = _sanitize_log_text(record.msg)
            record.args = _sanitize_log_value(record.args)
            if isinstance(record.exc_text, str):
                record.exc_text = _sanitize_log_text(record.exc_text)
            if isinstance(record.stack_info, str):
                record.stack_info = _sanitize_log_text(record.stack_info)
        except Exception:
            pass
        return True


def _configure_logging() -> None:
    logging.basicConfig(
        format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        level=logging.INFO,
    )

    root_logger = logging.getLogger()
    masking_filter = SecretMaskingFilter()
    for handler in root_logger.handlers:
        handler.addFilter(masking_filter)

    # Suppress low-value request logs that include full Telegram URLs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _get_runtime(context: ContextTypes.DEFAULT_TYPE) -> Runtime:
    runtime = context.application.bot_data.get("runtime")
    if not isinstance(runtime, Runtime):
        raise RuntimeError("Runtime belum terinisialisasi.")
    return runtime


def _update_log_context(update: object) -> str:
    if not isinstance(update, Update):
        return "update=none"

    parts: list[str] = []
    if update.update_id is not None:
        parts.append(f"update_id={update.update_id}")
    if update.effective_chat is not None and update.effective_chat.id is not None:
        parts.append(f"chat_id={update.effective_chat.id}")
    if update.effective_user is not None and update.effective_user.id is not None:
        parts.append(f"user_id={update.effective_user.id}")
    if update.callback_query is not None:
        parts.append("kind=callback")
    elif update.message is not None:
        parts.append("kind=message")
    else:
        parts.append("kind=unknown")
    return " ".join(parts) if parts else "update=unknown"


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    err = context.error
    err_type = err.__class__.__name__ if err is not None else "UnknownError"
    err_text = _sanitize_log_text(str(err) if err is not None else "unknown")
    update_ctx = _update_log_context(update)
    exc_info = (type(err), err, err.__traceback__) if err is not None else None

    if isinstance(err, NetworkError):
        LOGGER.warning("Transient Telegram network error (%s) %s: %s", err_type, update_ctx, err_text)
        return

    LOGGER.error("Unhandled bot error (%s) %s: %s", err_type, update_ctx, err_text, exc_info=exc_info)

    if not isinstance(update, Update):
        return

    chat = update.effective_chat
    if chat is None or chat.id is None:
        return

    try:
        if update.callback_query is not None:
            try:
                await update.callback_query.answer("Terjadi error sementara.", show_alert=True)
                return
            except Exception:
                pass
        await context.bot.send_message(
            chat_id=chat.id,
            text="Terjadi error sementara di bot. Coba ulangi action atau jalankan /menu.",
        )
    except Exception as notify_exc:
        LOGGER.warning(
            "Gagal mengirim notifikasi error ke chat %s: %s",
            chat.id,
            _sanitize_log_text(str(notify_exc)),
        )


def _is_authorized(runtime: Runtime, update: Update) -> tuple[bool, str]:
    if runtime.config.allow_unrestricted_access:
        return True, ""

    user_id = str(update.effective_user.id) if update.effective_user else ""
    chat_id = str(update.effective_chat.id) if update.effective_chat else ""

    if runtime.config.admin_user_ids and user_id not in runtime.config.admin_user_ids:
        return False, "Akses ditolak: user Telegram belum terdaftar sebagai admin."

    if runtime.config.admin_chat_ids and chat_id not in runtime.config.admin_chat_ids:
        return False, "Akses ditolak: chat ini belum diizinkan untuk menu bot."

    return True, ""


def _clear_pending(context: ContextTypes.DEFAULT_TYPE) -> None:
    pending_confirm = context.user_data.get(KEY_PENDING_CONFIRM)
    if isinstance(pending_confirm, dict):
        action_id = str(pending_confirm.get("action_id") or "").strip()
        params = pending_confirm.get("params") if isinstance(pending_confirm.get("params"), dict) else {}
        if action_id == "restore_from_upload" and isinstance(params, dict):
            _cleanup_uploaded_archive(str(params.get("upload_path") or ""))
    context.user_data.pop(KEY_PENDING_FORM, None)
    context.user_data.pop(KEY_PENDING_CONFIRM, None)
    context.user_data.pop(KEY_PENDING_DELETE_PICK, None)
    context.user_data.pop(KEY_PENDING_ACCOUNT_PICK, None)
    context.user_data.pop(KEY_PENDING_UPLOAD_RESTORE, None)


def _chat_scope_id(chat_id: int | str | None) -> str:
    return str(chat_id or "").strip()


def _store_pending_state(
    context: ContextTypes.DEFAULT_TYPE,
    key: str,
    pending: dict,
    chat_id: int | str | None,
) -> dict:
    state = dict(pending)
    state["origin_chat_id"] = _chat_scope_id(chat_id)
    context.user_data[key] = state
    return state


def _get_pending_state(
    context: ContextTypes.DEFAULT_TYPE,
    key: str,
    chat_id: int | str | None,
) -> tuple[dict | None, str]:
    pending = context.user_data.get(key)
    if not isinstance(pending, dict):
        return None, ""

    current_chat_id = _chat_scope_id(chat_id)
    origin_chat_id = _chat_scope_id(pending.get("origin_chat_id"))
    if origin_chat_id and current_chat_id and origin_chat_id != current_chat_id:
        return None, PENDING_OTHER_CHAT_TEXT

    if current_chat_id and not origin_chat_id:
        pending = _store_pending_state(context, key, pending, current_chat_id)
    return pending, ""


def _menu_parent_page_store(context: ContextTypes.DEFAULT_TYPE) -> dict[str, dict]:
    raw = context.user_data.get(KEY_MENU_PARENT_PAGES)
    if isinstance(raw, dict):
        return raw
    store: dict[str, dict] = {}
    context.user_data[KEY_MENU_PARENT_PAGES] = store
    return store


def _set_menu_parent_page(
    context: ContextTypes.DEFAULT_TYPE,
    menu_id: str,
    *,
    chat_id: int | str | None,
    parent_page: int,
) -> None:
    store = _menu_parent_page_store(context)
    store[menu_id] = {
        "origin_chat_id": _chat_scope_id(chat_id),
        "page": max(0, int(parent_page)),
    }


def _get_menu_parent_page(
    context: ContextTypes.DEFAULT_TYPE,
    menu_id: str,
    *,
    chat_id: int | str | None,
) -> int:
    raw = _menu_parent_page_store(context).get(menu_id)
    if not isinstance(raw, dict):
        return 0
    current_chat_id = _chat_scope_id(chat_id)
    origin_chat_id = _chat_scope_id(raw.get("origin_chat_id"))
    if origin_chat_id and current_chat_id and origin_chat_id != current_chat_id:
        return 0
    return max(0, _safe_int(str(raw.get("page") or "0"), default=0))


def _has_pending_state_in_other_chat(context: ContextTypes.DEFAULT_TYPE, chat_id: int | str | None) -> bool:
    current_chat_id = _chat_scope_id(chat_id)
    if not current_chat_id:
        return False

    for key in PENDING_STATE_KEYS:
        pending = context.user_data.get(key)
        if not isinstance(pending, dict):
            continue
        origin_chat_id = _chat_scope_id(pending.get("origin_chat_id"))
        if origin_chat_id and origin_chat_id != current_chat_id:
            return True
    return False


def _fmt_size(num: int) -> str:
    n = max(0, int(num))
    if n >= 1024**3:
        return f"{n / (1024**3):.2f} GiB"
    if n >= 1024**2:
        return f"{n / (1024**2):.2f} MiB"
    if n >= 1024:
        return f"{n / 1024:.2f} KiB"
    return f"{n} B"


def _is_subpath(path: Path, base: Path) -> bool:
    try:
        rp = path.resolve()
        rb = base.resolve()
    except Exception:
        return False
    return rp == rb or rb in rp.parents


def _resolve_restore_upload_dir() -> Path:
    for candidate in UPLOAD_RESTORE_DIRS:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except Exception:
            continue
    return UPLOAD_RESTORE_DIRS[0]


def _cleanup_uploaded_archive(raw_path: str) -> None:
    path_text = str(raw_path or "").strip()
    if not path_text:
        return
    try:
        resolved = Path(path_text).resolve()
    except Exception:
        return
    if not any(_is_subpath(resolved, root) for root in UPLOAD_RESTORE_DIRS):
        return
    try:
        resolved.unlink(missing_ok=True)
    except Exception:
        pass


def _resolve_local_download(data: dict) -> tuple[str, Path] | None:
    raw_path = str(data.get("download_local_path") or "").strip()
    if not raw_path:
        return None
    try:
        resolved = Path(raw_path).resolve()
    except Exception:
        return None
    if not resolved.exists() or not resolved.is_file():
        return None
    if not any(_is_subpath(resolved, root) for root in DOWNLOAD_LOCAL_ALLOW_DIRS):
        return None

    filename = str(data.get("download_filename") or "").strip() or resolved.name
    return filename, resolved


def _cooldown_remaining(
    context: ContextTypes.DEFAULT_TYPE,
    *,
    user_id: str,
    key: str,
    min_interval_sec: float,
) -> float:
    if min_interval_sec <= 0:
        return 0.0

    now = time.monotonic()
    scope = context.application.bot_data.setdefault("_cooldowns", {})
    user_scope = scope.setdefault(user_id, {})
    try:
        prev = float(user_scope.get(key, 0.0))
    except Exception:
        prev = 0.0

    elapsed = now - prev
    if elapsed < min_interval_sec:
        return min_interval_sec - elapsed

    user_scope[key] = now
    return 0.0


def _throttle_message(seconds_left: float) -> str:
    if seconds_left <= 1:
        return "Terlalu cepat. Coba lagi dalam ~1 detik."
    return f"Terlalu cepat. Coba lagi dalam ~{int(seconds_left + 0.99)} detik."


def _short_button_label(text: str, max_len: int = BUTTON_LABEL_MAX) -> str:
    if len(text) <= max_len:
        return text
    if max_len < 4:
        return text[:max_len]
    return text[: max_len - 3] + "..."


def _rows_from_buttons(buttons: list[InlineKeyboardButton], per_row: int = BUTTONS_PER_ROW) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = []
    for idx in range(0, len(buttons), per_row):
        rows.append(buttons[idx : idx + per_row])
    return rows


def _main_menu_keyboard(runtime: Runtime) -> InlineKeyboardMarkup:
    buttons: list[InlineKeyboardButton] = []
    for menu in _visible_main_menus(runtime):
        if not _visible_actions(runtime, menu):
            continue
        buttons.append(
            InlineKeyboardButton(
                _short_button_label(menu.label),
                callback_data=f"m{CALLBACK_SEP}{menu.id}",
            )
        )

    rows = _rows_from_buttons(buttons)
    rows.append([InlineKeyboardButton("🔄 Refresh", callback_data="h")])
    return InlineKeyboardMarkup(rows)


def _action_visible(runtime: Runtime, action: ActionSpec) -> bool:
    if action.dangerous and not runtime.config.mutations_enabled:
        return False
    return True


def _visible_actions(runtime: Runtime, menu: MenuSpec) -> list[ActionSpec]:
    return [action for action in menu.actions if _action_visible(runtime, action)]


def _visible_main_menus(runtime: Runtime) -> list[MenuSpec]:
    return [
        menu
        for menu in runtime.catalog.menus
        if not menu.hidden and _visible_actions(runtime, menu)
    ]


def _menu_pages(runtime: Runtime, menu: MenuSpec) -> int:
    total = len(_visible_actions(runtime, menu))
    if total <= 0:
        return 1
    return ((total - 1) // ACTIONS_PER_PAGE) + 1


def _menu_keyboard(runtime: Runtime, menu: MenuSpec, page: int, *, parent_page: int = 0) -> InlineKeyboardMarkup:
    visible_actions = _visible_actions(runtime, menu)
    total_pages = _menu_pages(runtime, menu)
    page = max(0, min(page, total_pages - 1))

    start = page * ACTIONS_PER_PAGE
    chunk = visible_actions[start : start + ACTIONS_PER_PAGE]

    buttons: list[InlineKeyboardButton] = []
    for action in chunk:
        buttons.append(
            InlineKeyboardButton(
                _short_button_label(action.label),
                callback_data=f"a{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{page}{CALLBACK_SEP}{action.id}",
            )
        )

    rows = _rows_from_buttons(buttons)

    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Prev", callback_data=f"p{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
        if page + 1 < total_pages:
            nav.append(InlineKeyboardButton("Next ▶️", callback_data=f"p{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{page + 1}"))
        rows.append(nav)

    footer: list[InlineKeyboardButton] = []
    if menu.parent_menu:
        footer.append(
            InlineKeyboardButton(
                "⬅️ Kembali",
                callback_data=f"m{CALLBACK_SEP}{menu.parent_menu}{CALLBACK_SEP}{max(parent_page, 0)}",
            )
        )
    footer.append(InlineKeyboardButton("🏠 Main Menu", callback_data="h"))
    rows.append(footer)
    return InlineKeyboardMarkup(rows)


def _result_keyboard(menu_id: str, page: int = 0) -> InlineKeyboardMarkup:
    back_label = "⬅️ Kembali ke Panel QAC" if menu_id in QAC_MENU_IDS else "⬅️ Kembali ke Action"
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(back_label, callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(page, 0)}")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="h")],
        ]
    )


def _callback_chat_id(update: Update) -> int:
    query = update.callback_query
    if query is not None and query.message is not None:
        return query.message.chat.id
    if update.effective_chat is not None:
        return update.effective_chat.id
    raise RuntimeError("Chat ID callback tidak tersedia.")


def _confirm_keyboard(menu_id: str, page: int = 0) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Jalankan", callback_data="rc"), InlineKeyboardButton("❌ Batal", callback_data=f"cf{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(page, 0)}")],
        ]
    )


def _safe_int(raw: str, default: int = 0) -> int:
    try:
        return int(raw)
    except Exception:
        return default


def _menu_protocol_scope(menu_id: str) -> tuple[str, ...]:
    if menu_id in {XRAY_USER_MENU_ID, XRAY_QAC_MENU_ID}:
        return XRAY_PROTOCOLS
    if menu_id in {SSH_USER_MENU_ID, SSH_QAC_MENU_ID} | SSH_NETWORK_MENU_IDS:
        return ("ssh",)
    return USER_PROTOCOLS


def _qac_picker_title(menu_id: str) -> str:
    if menu_id == XRAY_QAC_MENU_ID:
        return "Xray QAC"
    if menu_id == SSH_QAC_MENU_ID:
        return "SSH QAC"
    return "Quota & Access Control"


def _qac_selection_store(context: ContextTypes.DEFAULT_TYPE) -> dict[str, dict]:
    raw = context.user_data.get(KEY_QAC_SELECTIONS)
    if isinstance(raw, dict):
        return raw
    store: dict[str, dict] = {}
    context.user_data[KEY_QAC_SELECTIONS] = store
    return store


def _set_qac_selection(
    context: ContextTypes.DEFAULT_TYPE,
    menu_id: str,
    *,
    chat_id: int | str | None,
    proto: str,
    username: str,
) -> None:
    store = _qac_selection_store(context)
    store[menu_id] = {
        "origin_chat_id": _chat_scope_id(chat_id),
        "proto": str(proto or "").strip().lower(),
        "username": str(username or "").strip(),
    }


def _clear_qac_selection(context: ContextTypes.DEFAULT_TYPE, menu_id: str) -> None:
    store = _qac_selection_store(context)
    store.pop(menu_id, None)


def _get_qac_selection(
    context: ContextTypes.DEFAULT_TYPE,
    menu_id: str,
    *,
    chat_id: int | str | None,
) -> dict | None:
    raw = _qac_selection_store(context).get(menu_id)
    if not isinstance(raw, dict):
        return None
    current_chat_id = _chat_scope_id(chat_id)
    origin_chat_id = _chat_scope_id(raw.get("origin_chat_id"))
    if origin_chat_id and current_chat_id and origin_chat_id != current_chat_id:
        return None
    proto = str(raw.get("proto") or "").strip().lower()
    username = str(raw.get("username") or "").strip()
    if not proto or not username:
        return None
    if proto not in _menu_protocol_scope(menu_id):
        return None
    return {"proto": proto, "username": username}


def _qac_selection_params(menu_id: str, selection: dict | None) -> dict[str, str]:
    if not isinstance(selection, dict):
        return {}
    proto = str(selection.get("proto") or "").strip().lower()
    username = str(selection.get("username") or "").strip()
    if not username:
        return {}
    params = {"username": username}
    if menu_id == XRAY_QAC_MENU_ID and proto:
        params["proto"] = proto
    return params


def _qac_selection_label(menu_id: str, selection: dict | None) -> str:
    if not isinstance(selection, dict):
        return "-"
    proto = str(selection.get("proto") or "").strip().lower()
    username = str(selection.get("username") or "").strip()
    if not username:
        return "-"
    if menu_id == XRAY_QAC_MENU_ID and proto:
        return f"{username}@{proto}"
    return username


def _qac_picker_entry_label(menu_id: str, proto: str, username: str) -> str:
    if menu_id == XRAY_QAC_MENU_ID:
        return f"{username}@{proto}"
    return username


def _qac_menu_text(menu: MenuSpec, selection: dict, summary: dict[str, str] | None, page: int, total_pages: int) -> str:
    lines = [
        f"<b>{html.escape(menu.label)}</b>",
    ]
    if menu.description:
        lines.append(html.escape(menu.description))
    if summary:
        if menu.id == SSH_QAC_MENU_ID:
            lines.extend(
                [
                    "",
                    "<pre>"
                    + html.escape(
                        "\n".join(
                            [
                                f"Username           : {str(summary.get('username') or _qac_selection_label(menu.id, selection))}",
                                f"Quota Limit        : {str(summary.get('quota_limit') or '-')}",
                                f"Quota Used (SSH)   : {str(summary.get('quota_used') or '-')}",
                                f"Expired At         : {str(summary.get('expired_at') or '-')}",
                                f"IP/Login Limit     : {str(summary.get('ip_limit') or '-')}",
                                f"IP/Login Limit Max : {str(summary.get('ip_limit_max') or '-')}",
                                f"IP Unik Aktif      : {str(summary.get('distinct_ip_count') or '0')}",
                                f"Daftar IP Aktif    : {str(summary.get('distinct_ips') or '-')}",
                                f"IP/Login Metric    : {str(summary.get('ip_limit_metric') or '0')}",
                                f"Block Reason       : {str(summary.get('block_reason') or '-')}",
                                f"Account Locked     : {str(summary.get('account_locked') or 'OFF')}",
                                f"Sesi Aktif         : {str(summary.get('active_sessions_total') or '0')}",
                                f"Speed Download     : {str(summary.get('speed_download') or '-')}",
                                f"Speed Upload       : {str(summary.get('speed_upload') or '-')}",
                                f"Speed Limit        : {str(summary.get('speed_limit') or '-')}",
                            ]
                        )
                    )
                    + "</pre>",
                ]
            )
        else:
            lines.extend(
                [
                    "",
                    "<pre>"
                    + html.escape(
                        "\n".join(
                            [
                                f"Username       : {str(summary.get('username') or _qac_selection_label(menu.id, selection))}",
                                f"Quota Limit    : {str(summary.get('quota_limit') or '-')}",
                                f"Quota Used     : {str(summary.get('quota_used') or '-')}",
                                f"Expired At     : {str(summary.get('expired_at') or '-')}",
                                f"IP Limit       : {str(summary.get('ip_limit') or '-')}",
                                f"Block Reason   : {str(summary.get('block_reason') or '-')}",
                                f"IP Limit Max   : {str(summary.get('ip_limit_max') or '-')}",
                                f"Speed Download : {str(summary.get('speed_download') or '-')}",
                                f"Speed Upload   : {str(summary.get('speed_upload') or '-')}",
                                f"Speed Limit    : {str(summary.get('speed_limit') or '-')}",
                            ]
                        )
                    )
                    + "</pre>",
                ]
            )
    else:
        lines.extend(
            [
                "",
                f"User aktif: <code>{html.escape(_qac_selection_label(menu.id, selection))}</code>",
            ]
        )
    lines.extend(
        [
            "",
            f"Halaman aksi <code>{page + 1}/{max(total_pages, 1)}</code>",
            "Pilih action:",
        ]
    )
    return "\n".join(lines)


def _qac_menu_keyboard(runtime: Runtime, menu: MenuSpec, page: int, *, parent_page: int = 0) -> InlineKeyboardMarkup:
    rows = list(_menu_keyboard(runtime, menu, page, parent_page=parent_page).inline_keyboard)
    utility_row = [
        InlineKeyboardButton("🔄 Refresh Summary", callback_data=f"qac_refresh{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{page}"),
        InlineKeyboardButton("🔁 Ganti User", callback_data=f"qac_pick_menu{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{page}"),
    ]
    if rows and rows[-1]:
        footer_callbacks = {str(btn.callback_data or "") for btn in rows[-1]}
        if "h" in footer_callbacks or any(
            cb == f"m{CALLBACK_SEP}{menu.parent_menu}" or cb.startswith(f"m{CALLBACK_SEP}{menu.parent_menu}{CALLBACK_SEP}")
            for cb in footer_callbacks
        ):
            rows.insert(-1, utility_row)
        else:
            rows.append(utility_row)
    else:
        rows.append(utility_row)
    return InlineKeyboardMarkup(rows)


def _qac_pick_keyboard(menu_id: str, page: int, users: list[dict[str, str]], menu_page: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    start = page * DELETE_PICK_PAGE_SIZE
    chunk = users[start : start + DELETE_PICK_PAGE_SIZE]

    user_buttons: list[InlineKeyboardButton] = []
    for idx, item in enumerate(chunk, start=start):
        label = _qac_picker_entry_label(menu_id, str(item.get("proto") or ""), str(item.get("username") or ""))
        user_buttons.append(
            InlineKeyboardButton(
                _short_button_label(label, max_len=22),
                callback_data=f"qac_pick{CALLBACK_SEP}{idx}",
            )
        )
    rows.extend(_rows_from_buttons(user_buttons))

    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Prev", callback_data=f"qac_page{CALLBACK_SEP}{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
        if page + 1 < total_pages:
            nav.append(InlineKeyboardButton("Next ▶️", callback_data=f"qac_page{CALLBACK_SEP}{page + 1}"))
        rows.append(nav)

    rows.append(
        [
            InlineKeyboardButton(
                "⬅️ Kembali",
                callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}",
            )
        ]
    )
    return InlineKeyboardMarkup(rows)


def _qac_pick_text(menu_id: str, page: int, users: list[dict[str, str]]) -> str:
    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    return (
        f"<b>{html.escape(_qac_picker_title(menu_id))}</b>\n"
        "Pilih user dulu untuk membuka menu QAC.\n\n"
        f"Total user: <code>{len(users)}</code>\n"
        f"Halaman: <code>{page + 1}/{total_pages}</code>"
    )


async def _load_qac_user_entries(runtime: Runtime, menu_id: str) -> list[dict[str, str]]:
    proto_filter = None
    protocols = _menu_protocol_scope(menu_id)
    if len(protocols) == 1:
        proto_filter = protocols[0]

    options = await runtime.backend.list_user_options(proto=proto_filter)
    users: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for option in options:
        proto = str(option.proto or "").strip().lower()
        username = str(option.username or "").strip()
        if proto not in protocols or not username:
            continue
        key = (proto, username)
        if key in seen:
            continue
        seen.add(key)
        users.append({"proto": proto, "username": username})

    users.sort(key=lambda item: (str(item.get("username") or "").lower(), str(item.get("proto") or "").lower()))
    return users


def _delete_picker_title(menu_id: str) -> str:
    if menu_id == XRAY_USER_MENU_ID:
        return "Xray Users"
    if menu_id == SSH_USER_MENU_ID:
        return "SSH Users"
    return "User Management"


def _account_picker_title(menu_id: str) -> str:
    if menu_id == XRAY_USER_MENU_ID:
        return "Xray Users"
    if menu_id == SSH_USER_MENU_ID:
        return "SSH Users"
    return "Accounts"


def _account_picker_entry_label(menu_id: str, proto: str, username: str) -> str:
    if menu_id == XRAY_USER_MENU_ID:
        return f"{username}@{proto}"
    return username


def _account_picker_return_keyboard(menu_id: str, menu_page: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")]]
    )


def _account_pick_keyboard(menu_id: str, page: int, users: list[dict[str, str]], menu_page: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    start = page * DELETE_PICK_PAGE_SIZE
    chunk = users[start : start + DELETE_PICK_PAGE_SIZE]

    user_buttons: list[InlineKeyboardButton] = []
    for idx, item in enumerate(chunk, start=start):
        label = _account_picker_entry_label(menu_id, str(item.get("proto") or ""), str(item.get("username") or ""))
        user_buttons.append(
            InlineKeyboardButton(
                _short_button_label(label, max_len=22),
                callback_data=f"acc_pick{CALLBACK_SEP}{idx}",
            )
        )
    rows.extend(_rows_from_buttons(user_buttons))

    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Prev", callback_data=f"acc_page{CALLBACK_SEP}{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
        if page + 1 < total_pages:
            nav.append(InlineKeyboardButton("Next ▶️", callback_data=f"acc_page{CALLBACK_SEP}{page + 1}"))
        rows.append(nav)

    rows.extend(_account_picker_return_keyboard(menu_id, menu_page).inline_keyboard)
    return InlineKeyboardMarkup(rows)


def _account_pick_text(menu_id: str, action_label: str, page: int, users: list[dict[str, str]]) -> str:
    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    return (
        f"<b>{html.escape(_account_picker_title(menu_id))} · {html.escape(action_label)}</b>\n"
        "Pilih user dulu dari daftar.\n\n"
        f"Total user: <code>{len(users)}</code>\n"
        f"Halaman: <code>{page + 1}/{total_pages}</code>"
    )


async def _load_account_user_entries(runtime: Runtime, menu_id: str) -> list[dict[str, str]]:
    proto_filter = None
    protocols = _menu_protocol_scope(menu_id)
    if len(protocols) == 1:
        proto_filter = protocols[0]

    options = await runtime.backend.list_user_options(proto=proto_filter)
    users: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for option in options:
        proto = str(option.proto or "").strip().lower()
        username = str(option.username or "").strip()
        if proto not in protocols or not username:
            continue
        key = (proto, username)
        if key in seen:
            continue
        seen.add(key)
        users.append({"proto": proto, "username": username})

    users.sort(key=lambda item: (str(item.get("username") or "").lower(), str(item.get("proto") or "").lower()))
    return users


async def _show_account_user_picker(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    query,
    menu_id: str,
    action_id: str,
    page: int = 0,
    menu_page: int = 0,
) -> None:
    menu = runtime.catalog.get_menu(menu_id)
    action = runtime.catalog.get_action(menu_id, action_id)
    if menu is None or action is None:
        await query.answer("Action tidak ditemukan.", show_alert=True)
        return

    try:
        users = await _load_account_user_entries(runtime, menu_id)
    except BackendError as exc:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                "<b>❌ Gagal Ambil Daftar User</b>\n"
                f"<pre>{html.escape(str(exc)[:1200])}</pre>"
            ),
            reply_markup=_account_picker_return_keyboard(menu_id, menu_page),
        )
        return

    if not users:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                f"<b>{html.escape(_account_picker_title(menu_id))} · {html.escape(action.label)}</b>\n"
                "Belum ada user untuk dipilih."
            ),
            reply_markup=_account_picker_return_keyboard(menu_id, menu_page),
        )
        return

    page_max = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE)
    page = max(0, min(page, page_max))
    _store_pending_state(
        context,
        KEY_PENDING_ACCOUNT_PICK,
        {
            "menu_id": menu_id,
            "action_id": action_id,
            "users": users,
            "page": page,
            "menu_page": max(0, menu_page),
        },
        chat_id,
    )
    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=_account_pick_text(menu_id, action.label, page, users),
        reply_markup=_account_pick_keyboard(menu_id, page, users, menu_page),
    )


def _delete_pick_proto_keyboard(menu_id: str, menu_page: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    proto_buttons = [
        InlineKeyboardButton(
            proto.upper(),
            callback_data=f"dup_proto{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{proto}{CALLBACK_SEP}{max(menu_page, 0)}",
        )
        for proto in _menu_protocol_scope(menu_id)
    ]
    rows.extend(_rows_from_buttons(proto_buttons))
    rows.append(
        [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")]]
    )
    return InlineKeyboardMarkup(rows)


def _delete_pick_return_keyboard(menu_id: str, menu_page: int) -> InlineKeyboardMarkup:
    protocols = _menu_protocol_scope(menu_id)
    rows: list[list[InlineKeyboardButton]] = []
    if len(protocols) > 1:
        rows.append(
            [
                InlineKeyboardButton(
                    "↩️ Ganti Protocol",
                    callback_data=f"dup_proto_menu{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}",
                )
            ]
        )
    rows.append(
        [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")]]
    )
    return InlineKeyboardMarkup(rows)


def _protocol_choices_for_action(menu_id: str, action_id: str) -> tuple[str, ...]:
    scoped = _menu_protocol_scope(menu_id)
    if scoped != USER_PROTOCOLS:
        return scoped
    if action_id in SSH_ONLY_PROTOCOL_ACTIONS:
        return ("ssh",)
    return XRAY_PROTOCOLS


def _delete_pick_users_keyboard(menu_id: str, page: int, users: list[str], menu_page: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    start = page * DELETE_PICK_PAGE_SIZE
    chunk = users[start : start + DELETE_PICK_PAGE_SIZE]

    user_buttons: list[InlineKeyboardButton] = []
    for idx, username in enumerate(chunk, start=start):
        user_buttons.append(
            InlineKeyboardButton(
                _short_button_label(username, max_len=22),
                callback_data=f"dup_user{CALLBACK_SEP}{idx}",
            )
        )
    rows.extend(_rows_from_buttons(user_buttons))

    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Prev", callback_data=f"dup_page{CALLBACK_SEP}{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
        if page + 1 < total_pages:
            nav.append(InlineKeyboardButton("Next ▶️", callback_data=f"dup_page{CALLBACK_SEP}{page + 1}"))
        rows.append(nav)

    return_markup = _delete_pick_return_keyboard(menu_id, menu_page)
    rows.extend(return_markup.inline_keyboard)
    return InlineKeyboardMarkup(rows)


def _delete_pick_text_proto(menu_id: str) -> str:
    return (
        f"<b>{html.escape(_delete_picker_title(menu_id))} · Delete User</b>\n"
        "Pilih protocol dulu, lalu pilih username dari daftar."
    )


def _delete_pick_text_users(menu_id: str, proto: str, page: int, users: list[str]) -> str:
    total_pages = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE) + 1 if users else 1
    return (
        f"<b>{html.escape(_delete_picker_title(menu_id))} · Delete User</b>\n"
        f"Protocol: <code>{html.escape(proto.upper())}</code>\n"
        f"Total user: <code>{len(users)}</code>\n"
        f"Halaman: <code>{page + 1}/{total_pages}</code>\n"
        "Pilih user yang mau dihapus:"
    )


async def _show_delete_user_proto_picker(
    *,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    query,
    menu_id: str,
    menu_page: int = 0,
) -> None:
    context.user_data.pop(KEY_PENDING_DELETE_PICK, None)
    protocols = _menu_protocol_scope(menu_id)
    if len(protocols) == 1:
        await _show_delete_user_list_picker(
            runtime=_get_runtime(context),
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu_id,
            proto=protocols[0],
            page=0,
            menu_page=menu_page,
        )
        return
    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=_delete_pick_text_proto(menu_id),
        reply_markup=_delete_pick_proto_keyboard(menu_id, menu_page),
    )


async def _show_delete_user_list_picker(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    query,
    menu_id: str,
    proto: str,
    page: int = 0,
    menu_page: int = 0,
) -> None:
    try:
        options: list[BackendUserOption] = await runtime.backend.list_user_options(proto=proto)
    except BackendError as exc:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                "<b>❌ Gagal Ambil Daftar User</b>\n"
                f"<pre>{html.escape(str(exc)[:1200])}</pre>"
            ),
            reply_markup=_delete_pick_return_keyboard(menu_id, menu_page),
        )
        return

    usernames = list(dict.fromkeys([o.username for o in options if o.proto == proto]))
    if not usernames:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                f"<b>{html.escape(_delete_picker_title(menu_id))} · Delete User</b>\n"
                f"Protocol <code>{html.escape(proto.upper())}</code> belum punya user."
            ),
            reply_markup=_delete_pick_return_keyboard(menu_id, menu_page),
        )
        return

    page_max = ((len(usernames) - 1) // DELETE_PICK_PAGE_SIZE)
    page = max(0, min(page, page_max))
    _store_pending_state(
        context,
        KEY_PENDING_DELETE_PICK,
        {
            "menu_id": menu_id,
            "proto": proto,
            "users": usernames,
            "page": page,
            "menu_page": max(0, menu_page),
        },
        chat_id,
    )
    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=_delete_pick_text_users(menu_id, proto, page, usernames),
        reply_markup=_delete_pick_users_keyboard(menu_id, page, usernames, menu_page),
    )


async def _render_qac_menu(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    query,
    menu: MenuSpec,
    page: int = 0,
) -> None:
    selection = _get_qac_selection(context, menu.id, chat_id=chat_id)
    if selection is None:
        await _show_qac_user_picker(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu.id,
            menu_page=page,
        )
        return
    try:
        users = await _load_qac_user_entries(runtime, menu.id)
    except BackendError as exc:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                f"<b>{html.escape(_qac_picker_title(menu.id))}</b>\n"
                "Gagal memvalidasi user aktif.\n\n"
                f"<pre>{html.escape(str(exc)[:1200])}</pre>"
            ),
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu.id}{CALLBACK_SEP}{max(page, 0)}")]]
            ),
        )
        return

    if not any(
        str(item.get("proto") or "").strip().lower() == str(selection.get("proto") or "").strip().lower()
        and str(item.get("username") or "").strip() == str(selection.get("username") or "").strip()
        for item in users
    ):
        _clear_qac_selection(context, menu.id)
        await _show_qac_user_picker(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu.id,
            menu_page=page,
        )
        return
    summary: dict[str, str] | None = None
    try:
        summary = await runtime.backend.get_qac_user_summary(
            str(selection.get("proto") or ""),
            str(selection.get("username") or ""),
        )
    except BackendError:
        summary = None
    total_pages = _menu_pages(runtime, menu)
    page = max(0, min(page, total_pages - 1))
    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=_qac_menu_text(menu, selection, summary, page, total_pages),
        reply_markup=_qac_menu_keyboard(runtime, menu, page),
    )


async def _show_qac_user_picker(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    query,
    menu_id: str,
    page: int = 0,
    menu_page: int = 0,
) -> None:
    try:
        users = await _load_qac_user_entries(runtime, menu_id)
    except BackendError as exc:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                f"<b>{html.escape(_qac_picker_title(menu_id))}</b>\n"
                "Gagal mengambil daftar user.\n\n"
                f"<pre>{html.escape(str(exc)[:1200])}</pre>"
            ),
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")]]
            ),
        )
        return

    context.user_data.pop(KEY_PENDING_QAC_PICK, None)
    if not users:
        _clear_qac_selection(context, menu_id)
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                f"<b>{html.escape(_qac_picker_title(menu_id))}</b>\n"
                "Belum ada user yang bisa dipilih."
            ),
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Kembali", callback_data=f"m{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")]]
            ),
        )
        return

    page_max = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE)
    page = max(0, min(page, page_max))
    _store_pending_state(
        context,
        KEY_PENDING_QAC_PICK,
        {
            "menu_id": menu_id,
            "users": users,
            "page": page,
            "menu_page": max(0, menu_page),
        },
        chat_id,
    )
    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=_qac_pick_text(menu_id, page, users),
        reply_markup=_qac_pick_keyboard(menu_id, page, users, menu_page),
    )


def _serialize_choice_options(options: list[tuple[str, str]]) -> list[dict[str, str]]:
    return [{"label": str(label), "value": str(value)} for label, value in options]


def _is_truthy(raw: str) -> bool:
    val = str(raw or "").strip().lower()
    return val in {"1", "true", "on", "yes", "y", "enable", "enabled"}


def _field_is_required(pending: dict, field: ActionSpec) -> bool:
    if field.required:
        return True

    # Add User: saat speed limit ON, nilai down/up wajib diisi.
    if field.id in {"speed_down_mbit", "speed_up_mbit"}:
        params = pending.get("params") if isinstance(pending.get("params"), dict) else {}
        return _is_truthy(str(params.get("speed_limit_enabled") or ""))

    return False


def _pending_choice_options(pending: dict) -> list[dict[str, str]]:
    raw = pending.get("choice_options")
    if not isinstance(raw, list):
        return []
    out: list[dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        label = str(item.get("label") or "").strip()
        value = str(item.get("value") or "").strip()
        if not label and not value:
            continue
        out.append({"label": label or value, "value": value or label})
    return out


def _pending_prefilled_fields(pending: dict) -> set[str]:
    raw = pending.get("prefilled_fields")
    if not isinstance(raw, (list, tuple, set)):
        return set()
    return {str(item).strip() for item in raw if str(item).strip()}


def _display_form_field_indices(action: ActionSpec, pending: dict) -> list[int]:
    prefilled = _pending_prefilled_fields(pending)
    params = pending.get("params") if isinstance(pending.get("params"), dict) else {}
    speed_limit_value = str(params.get("speed_limit_enabled") or "").strip()
    hide_speed_fields = bool(speed_limit_value) and not _is_truthy(speed_limit_value)

    indices: list[int] = []
    for idx, field in enumerate(action.modal.fields):
        if field.id in prefilled:
            continue
        if hide_speed_fields and field.id in {"speed_down_mbit", "speed_up_mbit"}:
            continue
        indices.append(idx)
    return indices


def _display_form_progress(action: ActionSpec, pending: dict, current_idx: int) -> tuple[int, int]:
    indices = _display_form_field_indices(action, pending)
    if not indices:
        return 1, 1
    total = len(indices)
    if current_idx in indices:
        return indices.index(current_idx) + 1, total
    completed = sum(1 for idx in indices if idx <= current_idx)
    return max(1, min(completed, total)), total


def _is_click_only_field(action_id: str, field_id: str) -> bool:
    return action_id == "setup_domain_cloudflare" and field_id == "root_domain"


def _choice_total_pages(choice_options: list[dict[str, str]]) -> int:
    if not choice_options:
        return 1
    return ((len(choice_options) - 1) // FORM_CHOICE_PAGE_SIZE) + 1


def _choice_keyboard(menu_id: str, choice_options: list[dict[str, str]], page: int, *, menu_page: int = 0) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if choice_options:
        start = page * FORM_CHOICE_PAGE_SIZE
        chunk = choice_options[start : start + FORM_CHOICE_PAGE_SIZE]
        option_buttons: list[InlineKeyboardButton] = []
        for idx, item in enumerate(chunk, start=start):
            option_buttons.append(
                InlineKeyboardButton(
                    _short_button_label(str(item.get("label") or str(item.get("value") or "")), max_len=22),
                    callback_data=f"pfc{CALLBACK_SEP}{idx}",
                )
            )
        rows.extend(_rows_from_buttons(option_buttons))

    total_pages = _choice_total_pages(choice_options)
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Prev", callback_data=f"pfp{CALLBACK_SEP}{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
        if page + 1 < total_pages:
            nav.append(InlineKeyboardButton("Next ▶️", callback_data=f"pfp{CALLBACK_SEP}{page + 1}"))
        rows.append(nav)

    rows.append([InlineKeyboardButton("❌ Batal", callback_data=f"cf{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{max(menu_page, 0)}")])
    return InlineKeyboardMarkup(rows)


async def _resolve_form_choice_options(runtime: Runtime, pending: dict, field_id: str) -> list[tuple[str, str]]:
    menu_id = str(pending.get("menu_id") or "").strip()
    action_id = str(pending.get("action_id") or "").strip()
    params = pending.get("params") if isinstance(pending.get("params"), dict) else {}

    if field_id == "proto":
        return [(proto.upper(), proto) for proto in _protocol_choices_for_action(menu_id, action_id)]

    if field_id == "enabled":
        if action_id == "manual_block":
            return [("BLOCK", "on"), ("UNBLOCK", "off")]
        if action_id in {"ip_limit_enable", "speed_limit"}:
            return [("ENABLE", "on"), ("DISABLE", "off")]

    if field_id in {"enabled", "proxied", "allow_existing_same_ip", "speed_limit_enabled"}:
        return [("ON", "on"), ("OFF", "off")]

    if field_id == "mode":
        if action_id == "extend_expiry":
            return [("Extend (+hari)", "extend"), ("Set Tanggal", "set")]
        if action_id == "set_warp_global_mode":
            return [("Direct", "direct"), ("Warp", "warp")]
        if action_id in {"set_warp_user_mode", "set_warp_inbound_mode", "set_warp_domain_mode"}:
            return [("Direct", "direct"), ("Warp", "warp"), ("Off (inherit)", "off")]

    if field_id == "strategy":
        if action_id == "set_dns_query_strategy":
            return [
                ("UseIP", "UseIP"),
                ("UseIPv4", "UseIPv4"),
                ("UseIPv6", "UseIPv6"),
                ("PreferIPv4", "PreferIPv4"),
                ("PreferIPv6", "PreferIPv6"),
            ]

    if field_id == "subdomain_mode":
        return [("AUTO", "auto"), ("MANUAL", "manual")]

    if field_id == "root_domain" and action_id == "setup_domain_cloudflare":
        try:
            options: list[BackendRootDomainOption] = await runtime.backend.list_domain_root_options()
            roots = list(dict.fromkeys([o.root_domain for o in options if o.root_domain]))
        except BackendError:
            roots = []

        if not roots:
            roots = list(ROOT_DOMAIN_FALLBACK_OPTIONS)
        return [(root, root) for root in roots]

    if field_id == "days":
        return [("7", "7"), ("30", "30"), ("60", "60"), ("90", "90")]

    if field_id == "quota_gb":
        return [("10", "10"), ("50", "50"), ("100", "100"), ("200", "200")]

    if field_id == "ip_limit":
        return [("OFF (0)", "0"), ("1", "1"), ("2", "2"), ("3", "3")]

    if field_id == "speed_down_mbit":
        return [("10", "10"), ("20", "20"), ("50", "50"), ("100", "100")]

    if field_id == "speed_up_mbit":
        return [("5", "5"), ("10", "10"), ("20", "20"), ("50", "50")]

    if field_id == "limit":
        return [("10", "10"), ("15", "15"), ("25", "25"), ("50", "50"), ("100", "100")]

    if field_id == "username" and action_id in FORM_CHOICE_USERNAME_ACTIONS:
        proto = str(params.get("proto") or "").strip().lower()
        if not proto:
            scoped_protocols = _menu_protocol_scope(menu_id)
            if len(scoped_protocols) == 1:
                proto = scoped_protocols[0]
        if proto not in _protocol_choices_for_action(menu_id, action_id):
            return []
        try:
            options: list[BackendUserOption] = await runtime.backend.list_user_options(proto=proto)
        except BackendError:
            return []
        usernames = list(dict.fromkeys([o.username for o in options if o.proto == proto and o.username]))
        return [(u, u) for u in usernames]

    if field_id == "inbound_tag" and action_id == "set_warp_inbound_mode":
        try:
            options: list[BackendInboundOption] = await runtime.backend.list_inbound_options()
        except BackendError:
            return []
        tags = list(dict.fromkeys([o.tag for o in options if o.tag]))
        return [(tag, tag) for tag in tags]

    if field_id == "entry" and action_id == "set_warp_domain_mode":
        mode = str(params.get("mode") or "").strip().lower()
        mode_q = mode if mode in {"direct", "warp"} else None
        try:
            options: list[BackendDomainOption] = await runtime.backend.list_warp_domain_options(mode=mode_q)
        except BackendError:
            return []
        entries = list(dict.fromkeys([o.entry for o in options if o.entry]))
        return [(ent, ent) for ent in entries]

    if field_id == "domain" and action_id == "delete_adblock_domain":
        try:
            options = await runtime.backend.list_adblock_manual_options()
        except BackendError:
            return []
        entries = list(dict.fromkeys([o.entry for o in options if o.entry]))
        return [(ent, ent) for ent in entries]

    if field_id == "url" and action_id == "delete_adblock_url_source":
        try:
            options = await runtime.backend.list_adblock_url_options()
        except BackendError:
            return []
        entries = list(dict.fromkeys([o.entry for o in options if o.entry]))
        return [(ent, ent) for ent in entries]

    return []


async def _render_pending_choice_prompt(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    pending: dict,
    query=None,
) -> None:
    menu = runtime.catalog.get_menu(str(pending.get("menu_id", "")))
    action = runtime.catalog.get_action(str(pending.get("menu_id", "")), str(pending.get("action_id", "")))
    if menu is None or action is None or action.modal is None:
        raise RuntimeError("State pilihan input tidak valid.")

    idx = int(pending.get("index", 0))
    if idx < 0 or idx >= len(action.modal.fields):
        raise RuntimeError("Index pilihan input tidak valid.")
    field = action.modal.fields[idx]
    step_no, total_steps = _display_form_progress(action, pending, idx)

    choice_options = _pending_choice_options(pending)
    page_max = _choice_total_pages(choice_options) - 1
    page = max(0, min(int(pending.get("choice_page", 0)), page_max))
    pending["choice_page"] = page
    _store_pending_state(context, KEY_PENDING_FORM, pending, chat_id)

    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=(
            f"{action_form_prompt(menu, action, field, step_no, total_steps, params=pending.get('params'))}\n\n"
            "Pilih nilainya lewat tombol."
        ),
        reply_markup=_choice_keyboard(menu.id, choice_options, page, menu_page=_safe_int(str(pending.get("page") or "0"), default=0)),
    )


def _manual_input_prompt(menu: MenuSpec, action: ActionSpec, field, idx: int, total: int, *, params: dict | None = None) -> str:
    return (
        f"{action_form_prompt(menu, action, field, idx, total, params=params)}\n\n"
        "Mode input manual aktif. Ketik nilainya sekarang."
    )


async def _send_or_edit(
    *,
    query,
    chat_id: int,
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
) -> None:
    if query is not None:
        try:
            await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
            return
        except BadRequest as exc:
            # Hindari duplikasi pesan saat payload tidak berubah.
            if "message is not modified" in str(exc).lower():
                return
            LOGGER.debug("Edit message gagal, fallback kirim pesan baru: %s", exc)
        except Exception as exc:
            LOGGER.debug("Edit message exception, fallback kirim pesan baru: %s", exc)

    await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=reply_markup,
    )


async def _run_action(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    menu_id: str,
    action_id: str,
    params: dict[str, str],
    page: int,
    query,
) -> None:
    try:
        result = await runtime.backend.run_action(menu_id=menu_id, action=action_id, params=params)
    except BackendError as exc:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=(
                "<b>❌ Backend Error</b>\n"
                "Tidak bisa menjalankan action.\n\n"
                f"<pre>{str(exc)[:1800]}</pre>"
            ),
            reply_markup=_result_keyboard(menu_id, page),
        )
        return

    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text=action_result_text(result),
        reply_markup=_result_keyboard(menu_id, page),
    )

    local_attachment = _resolve_local_download(result.data)
    if local_attachment is not None:
        filename, local_path = local_attachment
        try:
            with local_path.open("rb") as fp:
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=fp,
                    filename=filename,
                    caption=f"File hasil: {filename}",
                )
        except Exception as exc:
            LOGGER.warning("Gagal kirim lampiran lokal %s: %s", local_path, exc)
        return

    attachment = decode_download_payload(result.data)
    if attachment is None:
        return

    filename, payload = attachment
    if not payload:
        return
    allow_password = bool(result.data.get("allow_sensitive_output")) if isinstance(result.data, dict) else False
    filename, payload = sanitize_download_attachment(filename, payload, allow_password=allow_password)

    bio = io.BytesIO(payload)
    bio.name = filename
    try:
        await context.bot.send_document(
            chat_id=chat_id,
            document=bio,
            filename=filename,
            caption=f"File hasil: {filename}",
        )
    except Exception as exc:
        LOGGER.warning("Gagal kirim lampiran %s: %s", filename, exc)


def _prefilled_action_params(
    context: ContextTypes.DEFAULT_TYPE,
    *,
    menu_id: str,
    action_id: str,
    chat_id: int,
) -> dict[str, str]:
    if menu_id not in QAC_MENU_IDS or action_id == "summary":
        return {}
    return _qac_selection_params(menu_id, _get_qac_selection(context, menu_id, chat_id=chat_id))


async def _start_action_flow(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    user_id: str,
    query,
    menu: MenuSpec,
    action: ActionSpec,
    initial_params: dict[str, str],
    page: int = 0,
) -> None:
    if action.mode == "modal" and action.modal and len(action.modal.fields) > 0:
        initial_index = 0
        while initial_index < len(action.modal.fields) and action.modal.fields[initial_index].id in initial_params:
            initial_index += 1
        if initial_index >= len(action.modal.fields):
            params = dict(initial_params)
            if action.confirm:
                _store_pending_state(
                    context,
                    KEY_PENDING_CONFIRM,
                    {
                        "menu_id": menu.id,
                        "action_id": action.id,
                        "params": params,
                        "page": page,
                    },
                    chat_id,
                )
                await _send_or_edit(
                    query=query,
                    chat_id=chat_id,
                    context=context,
                    text=confirm_text(menu, action, params),
                    reply_markup=_confirm_keyboard(menu.id, page),
                )
                return

            wait = _cooldown_remaining(
                context,
                user_id=user_id,
                key=KEY_LAST_ACTION_TS,
                min_interval_sec=runtime.config.action_cooldown_seconds,
            )
            if wait > 0:
                await query.answer(_throttle_message(wait), show_alert=True)
                return

            await _send_or_edit(
                query=query,
                chat_id=chat_id,
                context=context,
                text="<b>⏳ Menjalankan action...</b>",
                reply_markup=_result_keyboard(menu.id, page),
            )
            await _run_action(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                menu_id=menu.id,
                action_id=action.id,
                params=params,
                page=page,
                query=query,
            )
            return

        pending_form = _store_pending_state(
            context,
            KEY_PENDING_FORM,
            {
                "menu_id": menu.id,
                "action_id": action.id,
                "index": initial_index,
                "params": dict(initial_params),
                "page": page,
                "prefilled_fields": [
                    field.id
                    for field in action.modal.fields
                    if field.id in initial_params
                ],
            },
            chat_id,
        )
        await _prompt_next_form_field(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            pending=pending_form,
            query=query,
        )
        return

    params = dict(initial_params)
    if action.confirm:
        _store_pending_state(
            context,
            KEY_PENDING_CONFIRM,
            {
                "menu_id": menu.id,
                "action_id": action.id,
                "params": params,
                "page": page,
            },
            chat_id,
        )
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=confirm_text(menu, action, params),
            reply_markup=_confirm_keyboard(menu.id, page),
        )
        return

    wait = _cooldown_remaining(
        context,
        user_id=user_id,
        key=KEY_LAST_ACTION_TS,
        min_interval_sec=runtime.config.action_cooldown_seconds,
    )
    if wait > 0:
        await query.answer(_throttle_message(wait), show_alert=True)
        return

    await _send_or_edit(
        query=query,
        chat_id=chat_id,
        context=context,
        text="<b>⏳ Menjalankan action...</b>",
        reply_markup=_result_keyboard(menu.id, page),
    )
    await _run_action(
        runtime=runtime,
        context=context,
        chat_id=chat_id,
        menu_id=menu.id,
        action_id=action.id,
        params=params,
        page=page,
        query=query,
    )


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    ok, reason = _is_authorized(runtime, update)
    if not ok:
        await update.effective_message.reply_text(reason)
        return

    await update.effective_message.reply_text(
        "Selamat datang. Gunakan /menu untuk membuka kontrol server.",
    )


def _parse_cleanup_limit(context: ContextTypes.DEFAULT_TYPE) -> tuple[int | None, str]:
    if not context.args:
        return CLEANUP_FULL_SWEEP, ""

    raw = str(context.args[0]).strip()
    if not raw.isdigit():
        return None, f"Argumen cleanup harus angka 1-{CLEANUP_MAX_LIMIT}. Contoh: /cleanup 80"

    limit = int(raw)
    if limit < 1 or limit > CLEANUP_MAX_LIMIT:
        return None, f"Batas cleanup harus antara 1 sampai {CLEANUP_MAX_LIMIT}."

    return limit, ""


async def cmd_cleanup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    ok, reason = _is_authorized(runtime, update)
    if not ok:
        if update.effective_message:
            await update.effective_message.reply_text(reason)
        return

    chat = update.effective_chat
    msg = update.effective_message
    if chat is None or msg is None:
        return

    user_id = str(update.effective_user.id) if update.effective_user else ""
    wait = _cooldown_remaining(
        context,
        user_id=user_id,
        key=KEY_LAST_CLEANUP_TS,
        min_interval_sec=runtime.config.cleanup_cooldown_seconds,
    )
    if wait > 0:
        await msg.reply_text(_throttle_message(wait))
        return

    limit, err = _parse_cleanup_limit(context)
    if limit is None:
        await msg.reply_text(err)
        return

    _clear_pending(context)

    deleted = 0
    skipped = 0
    anchor_message_id = int(msg.message_id)
    scan_message_id = anchor_message_id
    full_sweep = limit == CLEANUP_FULL_SWEEP
    target_deleted = max(anchor_message_id - CLEANUP_KEEP_MESSAGES, 0) if full_sweep else int(limit)
    max_scan = max(CLEANUP_MAX_SCAN_IDS, int(limit) + CLEANUP_KEEP_MESSAGES) if not full_sweep else CLEANUP_MAX_SCAN_IDS
    scanned = 0

    # Hapus sampai target jumlah pesan TERHAPUS tercapai, bukan sekadar jumlah ID yang dipindai.
    while scan_message_id >= 1 and deleted < target_deleted and scanned < max_scan:
        try:
            await context.bot.delete_message(chat_id=chat.id, message_id=scan_message_id)
            deleted += 1
        except Exception:
            skipped += 1
        scan_message_id -= 1
        scanned += 1

    suffix = ""
    if full_sweep and scanned >= max_scan and deleted < target_deleted:
        suffix = f" (dibatasi scan maksimal {max_scan} message-id)"

    await context.bot.send_message(
        chat_id=chat.id,
        text=f"🧹 Cleanup selesai: {deleted} pesan dihapus, {skipped} dilewati.{suffix}",
    )


async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    ok, reason = _is_authorized(runtime, update)
    if not ok:
        await update.effective_message.reply_text(reason)
        return

    _clear_pending(context)

    await update.effective_message.reply_text(
        main_menu_text(runtime.hostname, len(_visible_main_menus(runtime))),
        parse_mode=ParseMode.HTML,
        reply_markup=_main_menu_keyboard(runtime),
    )


async def _prompt_next_form_field(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    pending: dict,
    query=None,
) -> None:
    menu = runtime.catalog.get_menu(str(pending.get("menu_id", "")))
    action = runtime.catalog.get_action(str(pending.get("menu_id", "")), str(pending.get("action_id", "")))
    if menu is None or action is None or action.modal is None:
        raise RuntimeError("State form tidak valid.")

    idx = int(pending.get("index", 0))
    if idx < 0 or idx >= len(action.modal.fields):
        raise RuntimeError("Index form tidak valid.")

    field = action.modal.fields[idx]
    click_only_field = _is_click_only_field(action.id, field.id)
    choice_options = await _resolve_form_choice_options(runtime, pending, field.id)
    choice_with_manual: list[tuple[str, str]] = list(choice_options)
    if not click_only_field:
        if choice_options:
            choice_with_manual.append(("✍️ Lainnya (input manual)", FORM_CHOICE_MANUAL_VALUE))
        else:
            choice_with_manual.append(("✍️ Input Manual", FORM_CHOICE_MANUAL_VALUE))
    if not click_only_field and not _field_is_required(pending, field):
        choice_with_manual.append(("⏭️ Lewati", FORM_CHOICE_SKIP_VALUE))

    pending.pop("manual_entry", None)
    pending["choice_options"] = _serialize_choice_options(choice_with_manual)
    pending["choice_page"] = 0
    _store_pending_state(context, KEY_PENDING_FORM, pending, chat_id)
    await _render_pending_choice_prompt(
        runtime=runtime,
        context=context,
        chat_id=chat_id,
        pending=pending,
        query=query,
    )


async def _submit_pending_form_value(
    *,
    runtime: Runtime,
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    pending: dict,
    raw_value: str,
    query=None,
    reply_message=None,
) -> None:
    menu_id = str(pending.get("menu_id", ""))
    action_id = str(pending.get("action_id", ""))
    menu = runtime.catalog.get_menu(menu_id)
    action = runtime.catalog.get_action(menu_id, action_id)
    if menu is None or action is None or action.modal is None:
        _clear_pending(context)
        if reply_message is not None:
            await reply_message.reply_text("Sesi input rusak. Jalankan /menu lagi.")
        elif query is not None:
            await query.answer("Sesi input rusak. Jalankan /menu lagi.", show_alert=True)
        return

    idx = int(pending.get("index", 0))
    if idx < 0 or idx >= len(action.modal.fields):
        _clear_pending(context)
        if reply_message is not None:
            await reply_message.reply_text("Sesi input sudah selesai. Jalankan /menu lagi.")
        elif query is not None:
            await query.answer("Sesi input sudah selesai. Jalankan /menu lagi.", show_alert=True)
        return

    field = action.modal.fields[idx]
    value = str(raw_value or "").strip()
    manual_entry = bool(pending.get("manual_entry"))
    if manual_entry and len(value) > runtime.config.max_manual_input_len:
        msg = f"Input terlalu panjang (maks {runtime.config.max_manual_input_len} karakter)."
        if reply_message is not None:
            await reply_message.reply_text(msg)
        elif query is not None:
            await query.answer(msg, show_alert=True)
        return

    choice_options = _pending_choice_options(pending)
    if choice_options and not manual_entry:
        allowed = {str(item.get("value") or "") for item in choice_options}
        if value not in allowed:
            if reply_message is not None:
                await reply_message.reply_text("Untuk field ini gunakan tombol pilihan yang tersedia.")
            elif query is not None:
                await query.answer("Gunakan tombol pilihan.", show_alert=True)
            return

        if value == FORM_CHOICE_MANUAL_VALUE:
            pending.pop("choice_options", None)
            pending.pop("choice_page", None)
            pending["manual_entry"] = True
            _store_pending_state(context, KEY_PENDING_FORM, pending, chat_id)
            step_no, total_steps = _display_form_progress(action, pending, idx)
            text = _manual_input_prompt(
                menu,
                action,
                field,
                step_no,
                total_steps,
                params=pending.get("params"),
            )
            menu_page = _safe_int(str(pending.get("page") or "0"), default=0)
            markup = InlineKeyboardMarkup(
                [[InlineKeyboardButton("❌ Batal", callback_data=f"cf{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{menu_page}")]]
            )
            if query is not None:
                await _send_or_edit(
                    query=query,
                    chat_id=chat_id,
                    context=context,
                    text=text,
                    reply_markup=markup,
                )
            elif reply_message is not None:
                await reply_message.reply_text(
                    text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=markup,
                )
            return

        if value == FORM_CHOICE_SKIP_VALUE:
            value = ""
    elif value.lower() in {"-", "skip", "lewati"}:
        value = ""

    if manual_entry:
        pending.pop("manual_entry", None)

    if _field_is_required(pending, field) and not value:
        if reply_message is not None:
            await reply_message.reply_text("Field ini wajib diisi. Coba lagi.")
        elif query is not None:
            await query.answer("Field ini wajib diisi.", show_alert=True)
        await _prompt_next_form_field(runtime=runtime, context=context, chat_id=chat_id, pending=pending, query=query)
        return

    params = pending.get("params") if isinstance(pending.get("params"), dict) else {}
    if value:
        params[field.id] = value

    pending["params"] = params
    next_idx = idx + 1
    if field.id == "speed_limit_enabled" and not _is_truthy(value):
        # Saat speed limit OFF/skip, lewati field speed down/up.
        while next_idx < len(action.modal.fields):
            next_field_id = action.modal.fields[next_idx].id
            if next_field_id not in {"speed_down_mbit", "speed_up_mbit"}:
                break
            next_idx += 1

    pending["index"] = next_idx
    pending.pop("choice_options", None)
    pending.pop("choice_page", None)
    _store_pending_state(context, KEY_PENDING_FORM, pending, chat_id)

    if pending["index"] < len(action.modal.fields):
        await _prompt_next_form_field(runtime=runtime, context=context, chat_id=chat_id, pending=pending, query=query)
        return

    context.user_data.pop(KEY_PENDING_FORM, None)
    menu_page = _safe_int(str(pending.get("page") or "0"), default=0)

    if action.confirm:
        _store_pending_state(
            context,
            KEY_PENDING_CONFIRM,
            {
                "menu_id": menu_id,
                "action_id": action_id,
                "params": params,
                "page": menu_page,
            },
            chat_id,
        )
        if query is not None:
            await _send_or_edit(
                query=query,
                chat_id=chat_id,
                context=context,
                text=confirm_text(menu, action, params),
                reply_markup=_confirm_keyboard(menu_id, menu_page),
            )
        elif reply_message is not None:
            await reply_message.reply_text(
                confirm_text(menu, action, params),
                parse_mode=ParseMode.HTML,
                reply_markup=_confirm_keyboard(menu_id, menu_page),
            )
        return

    if query is not None:
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text="<b>⏳ Menjalankan action...</b>",
            reply_markup=_result_keyboard(menu_id, menu_page),
        )
    elif reply_message is not None:
        await reply_message.reply_text("⏳ Menjalankan action...")

    await _run_action(
        runtime=runtime,
        context=context,
        chat_id=chat_id,
        menu_id=menu_id,
        action_id=action_id,
        params=params,
        page=menu_page,
        query=query,
    )


async def on_document_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    ok, reason = _is_authorized(runtime, update)
    if not ok:
        if update.effective_message:
            await update.effective_message.reply_text(reason)
        return

    msg = update.effective_message
    chat = update.effective_chat
    doc = msg.document if msg else None
    if msg is None or chat is None or doc is None:
        return

    pending_upload, pending_upload_err = _get_pending_state(context, KEY_PENDING_UPLOAD_RESTORE, chat.id if chat else None)
    if pending_upload is None:
        if pending_upload_err:
            await msg.reply_text(pending_upload_err)
        return

    name = str(doc.file_name or "").strip()
    if not name.lower().endswith(".tar.gz"):
        await msg.reply_text("File restore harus berekstensi .tar.gz")
        return

    size_bytes = int(doc.file_size or 0)
    if size_bytes > UPLOAD_RESTORE_MAX_BYTES:
        await msg.reply_text(
            (
                "Ukuran file terlalu besar untuk restore upload.\n"
                f"Maksimal: {_fmt_size(UPLOAD_RESTORE_MAX_BYTES)}\n"
                f"File ini: {_fmt_size(size_bytes)}"
            )
        )
        return

    upload_dir = _resolve_restore_upload_dir()
    upload_id = f"{int(time.time())}-{doc.file_unique_id}"
    upload_name = f"restore-upload-{upload_id}.tar.gz"
    upload_path = upload_dir / upload_name

    try:
        tg_file = await doc.get_file()
        await tg_file.download_to_drive(custom_path=str(upload_path))
    except Exception as exc:
        LOGGER.warning("Gagal download file restore upload: %s", exc)
        await msg.reply_text("Gagal mengunduh file dari Telegram. Coba kirim ulang.")
        return

    menu_id = str(pending_upload.get("menu_id") or BACKUP_MENU_ID)
    action_id = str(pending_upload.get("action_id") or "restore_from_upload")
    menu_page = _safe_int(str(pending_upload.get("page") or "0"), default=0)
    menu = runtime.catalog.get_menu(menu_id)
    action = runtime.catalog.get_action(menu_id, action_id)
    if menu is None or action is None:
        context.user_data.pop(KEY_PENDING_UPLOAD_RESTORE, None)
        _cleanup_uploaded_archive(str(upload_path))
        await msg.reply_text("Action restore upload tidak ditemukan. Jalankan /menu lagi.")
        return

    params = {"upload_path": str(upload_path)}
    context.user_data.pop(KEY_PENDING_UPLOAD_RESTORE, None)
    _store_pending_state(
        context,
        KEY_PENDING_CONFIRM,
        {
            "menu_id": menu_id,
            "action_id": action_id,
            "params": params,
            "page": menu_page,
        },
        chat.id,
    )

    confirm_msg = (
        f"<b>Konfirmasi: {html.escape(menu.label)} · {html.escape(action.label)}</b>\n\n"
        f"- File: <code>{html.escape(name or upload_name)}</code>\n"
        f"- Ukuran: <code>{html.escape(_fmt_size(size_bytes))}</code>\n\n"
        "Lanjutkan eksekusi restore?"
    )
    await msg.reply_text(
        confirm_msg,
        parse_mode=ParseMode.HTML,
        reply_markup=_confirm_keyboard(menu_id, menu_page),
    )


async def on_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    ok, reason = _is_authorized(runtime, update)
    if not ok:
        await update.effective_message.reply_text(reason)
        return

    pending_upload, pending_upload_err = _get_pending_state(
        context,
        KEY_PENDING_UPLOAD_RESTORE,
        update.effective_chat.id if update.effective_chat else None,
    )
    if pending_upload is not None:
        await update.effective_message.reply_text(
            "Sesi restore upload aktif. Kirim file backup .tar.gz atau tekan Batal."
        )
        return
    if pending_upload_err:
        await update.effective_message.reply_text(pending_upload_err)
        return

    pending, pending_err = _get_pending_state(
        context,
        KEY_PENDING_FORM,
        update.effective_chat.id if update.effective_chat else None,
    )
    if pending is None:
        if pending_err:
            await update.effective_message.reply_text(pending_err)
        return

    await _submit_pending_form_value(
        runtime=runtime,
        context=context,
        chat_id=update.effective_chat.id,
        pending=pending,
        raw_value=(update.effective_message.text or ""),
        query=None,
        reply_message=update.effective_message,
    )


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    runtime = _get_runtime(context)
    query = update.callback_query
    if query is None:
        return

    ok, reason = _is_authorized(runtime, update)
    if not ok:
        await query.answer(reason, show_alert=True)
        return

    data = str(query.data or "")
    if not data or len(data) > CALLBACK_DATA_MAX_LEN:
        await query.answer("Payload callback tidak valid.", show_alert=True)
        return
    await query.answer()
    chat_id = _callback_chat_id(update)
    user_id = str(update.effective_user.id) if update.effective_user else ""

    if data == "noop":
        return

    if _has_pending_state_in_other_chat(context, chat_id):
        await query.answer(PENDING_OTHER_CHAT_TEXT, show_alert=True)
        return

    if data == "h":
        _clear_pending(context)
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=main_menu_text(runtime.hostname, len(_visible_main_menus(runtime))),
            reply_markup=_main_menu_keyboard(runtime),
        )
        return

    if data.startswith(f"cf{CALLBACK_SEP}"):
        _clear_pending(context)
        parts = data.split(CALLBACK_SEP)
        menu_id = parts[1] if len(parts) > 1 else ""
        page = _safe_int(parts[2] if len(parts) > 2 else "0", default=0)
        menu = runtime.catalog.get_menu(menu_id)
        if menu is None:
            await _send_or_edit(
                query=query,
                chat_id=chat_id,
                context=context,
                text=main_menu_text(runtime.hostname, len(_visible_main_menus(runtime))),
                reply_markup=_main_menu_keyboard(runtime),
            )
            return
        if menu_id in QAC_MENU_IDS:
            await _render_qac_menu(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                query=query,
                menu=menu,
                page=page,
            )
            return
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=menu_text(menu, page, _menu_pages(runtime, menu)),
            reply_markup=_menu_keyboard(runtime, menu, page),
        )
        return

    if data.startswith(f"pfp{CALLBACK_SEP}"):
        pending, pending_err = _get_pending_state(context, KEY_PENDING_FORM, chat_id)
        if pending is None:
            if pending_err:
                await query.answer(pending_err, show_alert=True)
                return
            await query.answer("Sesi input tidak aktif.", show_alert=True)
            return
        choice_options = _pending_choice_options(pending)
        if not choice_options:
            await query.answer("Pilihan tombol tidak tersedia.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        page = _safe_int(parts[1] if len(parts) > 1 else "0", default=0)
        page_max = _choice_total_pages(choice_options) - 1
        page = max(0, min(page, page_max))
        pending["choice_page"] = page
        _store_pending_state(context, KEY_PENDING_FORM, pending, chat_id)
        await _render_pending_choice_prompt(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            pending=pending,
            query=query,
        )
        return

    if data.startswith(f"pfc{CALLBACK_SEP}"):
        pending, pending_err = _get_pending_state(context, KEY_PENDING_FORM, chat_id)
        if pending is None:
            if pending_err:
                await query.answer(pending_err, show_alert=True)
                return
            await query.answer("Sesi input tidak aktif.", show_alert=True)
            return
        choice_options = _pending_choice_options(pending)
        if not choice_options:
            await query.answer("Pilihan tombol tidak tersedia.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        idx = _safe_int(parts[1] if len(parts) > 1 else "-1", default=-1)
        if idx < 0 or idx >= len(choice_options):
            await query.answer("Pilihan tidak valid.", show_alert=True)
            return
        value = str(choice_options[idx].get("value") or "")
        await _submit_pending_form_value(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            pending=pending,
            raw_value=value,
            query=query,
            reply_message=None,
        )
        return

    if data.startswith(f"acc_page{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_ACCOUNT_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan akun tidak aktif.", show_alert=True)
            return
        menu_id = str(state.get("menu_id") or XRAY_USER_MENU_ID)
        action_id = str(state.get("action_id") or "").strip()
        users = state.get("users") if isinstance(state.get("users"), list) else []
        menu_page = _safe_int(str(state.get("menu_page") or "0"), default=0)
        if menu_id not in DELETE_PICK_MENU_IDS or action_id not in ACCOUNT_PICK_ACTION_IDS or not users:
            await query.answer("Sesi pemilihan akun tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        page = _safe_int(parts[1] if len(parts) > 1 else "0", default=0)
        page_max = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE)
        page = max(0, min(page, page_max))
        state["page"] = page
        _store_pending_state(context, KEY_PENDING_ACCOUNT_PICK, state, chat_id)
        menu = runtime.catalog.get_menu(menu_id)
        action = runtime.catalog.get_action(menu_id, action_id)
        if menu is None or action is None:
            await query.answer("Action tidak ditemukan.", show_alert=True)
            return
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=_account_pick_text(menu_id, action.label, page, users),
            reply_markup=_account_pick_keyboard(menu_id, page, users, menu_page),
        )
        return

    if data.startswith(f"acc_pick{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_ACCOUNT_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan akun tidak aktif.", show_alert=True)
            return
        menu_id = str(state.get("menu_id") or XRAY_USER_MENU_ID)
        action_id = str(state.get("action_id") or "").strip()
        users = state.get("users") if isinstance(state.get("users"), list) else []
        menu_page = _safe_int(str(state.get("menu_page") or "0"), default=0)
        if menu_id not in DELETE_PICK_MENU_IDS or action_id not in ACCOUNT_PICK_ACTION_IDS or not users:
            await query.answer("Sesi pemilihan akun tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        idx = _safe_int(parts[1] if len(parts) > 1 else "-1", default=-1)
        if idx < 0 or idx >= len(users):
            await query.answer("User tidak valid.", show_alert=True)
            return
        selected = users[idx] if isinstance(users[idx], dict) else {}
        proto = str(selected.get("proto") or "").strip().lower()
        username = str(selected.get("username") or "").strip()
        if not username or proto not in _menu_protocol_scope(menu_id):
            await query.answer("User tidak valid.", show_alert=True)
            return
        context.user_data.pop(KEY_PENDING_ACCOUNT_PICK, None)

        menu = runtime.catalog.get_menu(menu_id)
        action = runtime.catalog.get_action(menu_id, action_id)
        if menu is None or action is None:
            await query.answer("Action tidak ditemukan.", show_alert=True)
            return

        initial_params = {"username": username}
        if menu_id == XRAY_USER_MENU_ID:
            initial_params["proto"] = proto
        await _start_action_flow(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            user_id=user_id,
            query=query,
            menu=menu,
            action=action,
            initial_params=initial_params,
            page=menu_page,
        )
        return

    if data.startswith(f"dup_proto_menu{CALLBACK_SEP}"):
        parts = data.split(CALLBACK_SEP)
        menu_id = parts[1] if len(parts) > 1 else XRAY_USER_MENU_ID
        menu_page = _safe_int(parts[2] if len(parts) > 2 else "0", default=0)
        await _show_delete_user_proto_picker(
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu_id,
            menu_page=menu_page,
        )
        return

    if data.startswith(f"dup_proto{CALLBACK_SEP}"):
        parts = data.split(CALLBACK_SEP)
        if len(parts) not in {3, 4}:
            await query.answer("Protocol tidak valid.", show_alert=True)
            return
        menu_id = str(parts[1]).strip()
        proto = parts[2].strip().lower()
        menu_page = _safe_int(parts[3] if len(parts) > 3 else "0", default=0)
        if menu_id not in DELETE_PICK_MENU_IDS or proto not in _menu_protocol_scope(menu_id):
            await query.answer("Protocol tidak valid.", show_alert=True)
            return
        await _show_delete_user_list_picker(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu_id,
            proto=proto,
            page=0,
            menu_page=menu_page,
        )
        return

    if data.startswith(f"dup_page{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_DELETE_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan user tidak aktif.", show_alert=True)
            return
        proto = str(state.get("proto") or "").strip().lower()
        menu_id = str(state.get("menu_id") or XRAY_USER_MENU_ID)
        users = state.get("users") if isinstance(state.get("users"), list) else []
        menu_page = _safe_int(str(state.get("menu_page") or "0"), default=0)
        if proto not in _menu_protocol_scope(menu_id) or not users:
            await query.answer("Sesi pemilihan user tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        page = _safe_int(parts[1] if len(parts) > 1 else "0", default=0)
        page_max = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE)
        page = max(0, min(page, page_max))
        state["page"] = page
        _store_pending_state(context, KEY_PENDING_DELETE_PICK, state, chat_id)
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=_delete_pick_text_users(menu_id, proto, page, users),
            reply_markup=_delete_pick_users_keyboard(menu_id, page, users, menu_page),
        )
        return

    if data.startswith(f"dup_user{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_DELETE_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan user tidak aktif.", show_alert=True)
            return
        proto = str(state.get("proto") or "").strip().lower()
        menu_id = str(state.get("menu_id") or XRAY_USER_MENU_ID)
        users = state.get("users") if isinstance(state.get("users"), list) else []
        if proto not in _menu_protocol_scope(menu_id) or not users:
            await query.answer("Sesi pemilihan user tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        idx = _safe_int(parts[1] if len(parts) > 1 else "-1", default=-1)
        if idx < 0 or idx >= len(users):
            await query.answer("User tidak valid.", show_alert=True)
            return
        username = str(users[idx])
        context.user_data.pop(KEY_PENDING_DELETE_PICK, None)

        menu = runtime.catalog.get_menu(menu_id)
        action = runtime.catalog.get_action(menu_id, "delete_user")
        if menu is None or action is None:
            await query.answer("Action tidak ditemukan.", show_alert=True)
            return

        params = {
            "proto": proto,
            "username": username,
        }
        _store_pending_state(
            context,
            KEY_PENDING_CONFIRM,
            {
                "menu_id": menu_id,
                "action_id": "delete_user",
                "params": params,
                "page": menu_page,
            },
            chat_id,
        )
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=confirm_text(menu, action, params),
            reply_markup=_confirm_keyboard(menu_id, menu_page),
        )
        return

    if data.startswith(f"qac_pick_menu{CALLBACK_SEP}"):
        parts = data.split(CALLBACK_SEP)
        menu_id = parts[1] if len(parts) > 1 else XRAY_QAC_MENU_ID
        menu_page = _safe_int(parts[2] if len(parts) > 2 else "0", default=0)
        await _show_qac_user_picker(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu_id=menu_id,
            page=0,
            menu_page=menu_page,
        )
        return

    if data.startswith(f"qac_refresh{CALLBACK_SEP}"):
        parts = data.split(CALLBACK_SEP)
        menu_id = parts[1] if len(parts) > 1 else XRAY_QAC_MENU_ID
        page = _safe_int(parts[2] if len(parts) > 2 else "0", default=0)
        menu = runtime.catalog.get_menu(menu_id)
        if menu is None or menu_id not in QAC_MENU_IDS:
            await query.answer("Menu QAC tidak ditemukan.", show_alert=True)
            return
        await _render_qac_menu(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu=menu,
            page=page,
        )
        return

    if data.startswith(f"qac_page{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_QAC_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan user QAC tidak aktif.", show_alert=True)
            return
        menu_id = str(state.get("menu_id") or XRAY_QAC_MENU_ID)
        users = state.get("users") if isinstance(state.get("users"), list) else []
        menu_page = _safe_int(str(state.get("menu_page") or "0"), default=0)
        if menu_id not in QAC_MENU_IDS or not users:
            await query.answer("Sesi pemilihan user QAC tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        page = _safe_int(parts[1] if len(parts) > 1 else "0", default=0)
        page_max = ((len(users) - 1) // DELETE_PICK_PAGE_SIZE)
        page = max(0, min(page, page_max))
        state["page"] = page
        _store_pending_state(context, KEY_PENDING_QAC_PICK, state, chat_id)
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=_qac_pick_text(menu_id, page, users),
            reply_markup=_qac_pick_keyboard(menu_id, page, users, menu_page),
        )
        return

    if data.startswith(f"qac_pick{CALLBACK_SEP}"):
        state, state_err = _get_pending_state(context, KEY_PENDING_QAC_PICK, chat_id)
        if state is None:
            if state_err:
                await query.answer(state_err, show_alert=True)
                return
            await query.answer("Sesi pemilihan user QAC tidak aktif.", show_alert=True)
            return
        menu_id = str(state.get("menu_id") or XRAY_QAC_MENU_ID)
        users = state.get("users") if isinstance(state.get("users"), list) else []
        menu_page = _safe_int(str(state.get("menu_page") or "0"), default=0)
        if menu_id not in QAC_MENU_IDS or not users:
            await query.answer("Sesi pemilihan user QAC tidak valid.", show_alert=True)
            return
        parts = data.split(CALLBACK_SEP)
        idx = _safe_int(parts[1] if len(parts) > 1 else "-1", default=-1)
        if idx < 0 or idx >= len(users):
            await query.answer("User tidak valid.", show_alert=True)
            return
        selected = users[idx] if isinstance(users[idx], dict) else {}
        proto = str(selected.get("proto") or "").strip().lower()
        username = str(selected.get("username") or "").strip()
        if proto not in _menu_protocol_scope(menu_id) or not username:
            await query.answer("User tidak valid.", show_alert=True)
            return
        context.user_data.pop(KEY_PENDING_QAC_PICK, None)
        _set_qac_selection(
            context,
            menu_id,
            chat_id=chat_id,
            proto=proto,
            username=username,
        )
        menu = runtime.catalog.get_menu(menu_id)
        if menu is None:
            await query.answer("Menu QAC tidak ditemukan.", show_alert=True)
            return
        await _render_qac_menu(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            query=query,
            menu=menu,
            page=menu_page,
        )
        return

    if data == "rc":
        pending, pending_err = _get_pending_state(context, KEY_PENDING_CONFIRM, chat_id)
        if pending is None:
            if pending_err:
                await query.answer(pending_err, show_alert=True)
                return
            await query.answer("Tidak ada aksi yang menunggu konfirmasi.", show_alert=True)
            return

        wait = _cooldown_remaining(
            context,
            user_id=user_id,
            key=KEY_LAST_ACTION_TS,
            min_interval_sec=runtime.config.action_cooldown_seconds,
        )
        if wait > 0:
            await query.answer(_throttle_message(wait), show_alert=True)
            return

        menu_id = str(pending.get("menu_id", ""))
        action_id = str(pending.get("action_id", ""))
        params = pending.get("params") if isinstance(pending.get("params"), dict) else {}
        page = _safe_int(str(pending.get("page") or "0"), default=0)
        context.user_data.pop(KEY_PENDING_CONFIRM, None)

        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text="<b>⏳ Menjalankan action...</b>",
            reply_markup=_result_keyboard(menu_id, page),
        )
        await _run_action(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            menu_id=menu_id,
            action_id=action_id,
            params=params,
            page=page,
            query=query,
        )
        if action_id == "restore_from_upload":
            _cleanup_uploaded_archive(str(params.get("upload_path") or ""))
        return

    parts = data.split(CALLBACK_SEP)
    kind = parts[0]

    if kind == "m" and len(parts) in {2, 3}:
        _clear_pending(context)
        menu = runtime.catalog.get_menu(parts[1])
        if menu is None:
            await query.answer("Menu tidak ditemukan.", show_alert=True)
            return
        page = _safe_int(parts[2] if len(parts) > 2 else "0", default=0)
        if not _visible_actions(runtime, menu):
            await query.answer("Tidak ada action yang aktif di menu ini.", show_alert=True)
            return
        parent_page = _get_menu_parent_page(context, menu.id, chat_id=chat_id)
        if menu.id in QAC_MENU_IDS:
            await _render_qac_menu(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                query=query,
                menu=menu,
                page=page,
            )
            return
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=menu_text(menu, page, _menu_pages(runtime, menu)),
            reply_markup=_menu_keyboard(runtime, menu, page, parent_page=parent_page),
        )
        return

    if kind == "p" and len(parts) == 3:
        menu = runtime.catalog.get_menu(parts[1])
        if menu is None:
            await query.answer("Menu tidak ditemukan.", show_alert=True)
            return
        if not _visible_actions(runtime, menu):
            await query.answer("Tidak ada action yang aktif di menu ini.", show_alert=True)
            return
        try:
            page = int(parts[2])
        except ValueError:
            page = 0
        page = max(0, min(page, _menu_pages(runtime, menu) - 1))
        parent_page = _get_menu_parent_page(context, menu.id, chat_id=chat_id)
        if menu.id in QAC_MENU_IDS:
            await _render_qac_menu(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                query=query,
                menu=menu,
                page=page,
            )
            return
        await _send_or_edit(
            query=query,
            chat_id=chat_id,
            context=context,
            text=menu_text(menu, page, _menu_pages(runtime, menu)),
            reply_markup=_menu_keyboard(runtime, menu, page, parent_page=parent_page),
        )
        return

    if kind == "a" and len(parts) in {3, 4}:
        menu_id = parts[1]
        if len(parts) > 3:
            page = _safe_int(parts[2], default=0)
            action_id = parts[3]
        else:
            page = 0
            action_id = parts[2]
        menu = runtime.catalog.get_menu(menu_id)
        action = runtime.catalog.get_action(menu_id, action_id)
        if menu is None or action is None:
            await query.answer("Action tidak ditemukan.", show_alert=True)
            return
        if not _action_visible(runtime, action):
            await query.answer("Action ini sedang nonaktif.", show_alert=True)
            return

        _clear_pending(context)

        if menu_id in DELETE_PICK_MENU_IDS and action_id in ACCOUNT_PICK_ACTION_IDS:
            await _show_account_user_picker(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                query=query,
                menu_id=menu_id,
                action_id=action_id,
                page=0,
                menu_page=page,
            )
            return

        if action.mode == "menu":
            target_menu_id = str(action.target_menu or "").strip()
            target_menu = runtime.catalog.get_menu(target_menu_id)
            if target_menu is None:
                await query.answer("Submenu tidak ditemukan.", show_alert=True)
                return
            if not _visible_actions(runtime, target_menu):
                await query.answer("Tidak ada action yang aktif di submenu ini.", show_alert=True)
                return
            _set_menu_parent_page(context, target_menu.id, chat_id=chat_id, parent_page=page)
            if target_menu.id in QAC_MENU_IDS:
                await _render_qac_menu(
                    runtime=runtime,
                    context=context,
                    chat_id=chat_id,
                    query=query,
                    menu=target_menu,
                    page=0,
                )
                return
            await _send_or_edit(
                query=query,
                chat_id=chat_id,
                context=context,
                text=menu_text(target_menu, 0, _menu_pages(runtime, target_menu)),
                reply_markup=_menu_keyboard(runtime, target_menu, 0, parent_page=page),
            )
            return

        if menu_id == BACKUP_MENU_ID and action_id == "restore_from_upload":
            _store_pending_state(
                context,
                KEY_PENDING_UPLOAD_RESTORE,
                {
                    "menu_id": menu_id,
                    "action_id": action_id,
                    "page": page,
                },
                chat_id,
            )
            await _send_or_edit(
                query=query,
                chat_id=chat_id,
                context=context,
                text=(
                    "<b>Restore Upload</b>\n"
                    "Kirim file backup berekstensi <code>.tar.gz</code> lewat Telegram.\n"
                    f"Ukuran maksimal: <code>{html.escape(_fmt_size(UPLOAD_RESTORE_MAX_BYTES))}</code>\n\n"
                    "Setelah file diterima, bot akan minta konfirmasi sebelum restore dijalankan."
                ),
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("❌ Batal", callback_data=f"cf{CALLBACK_SEP}{menu_id}{CALLBACK_SEP}{page}")]]
                ),
            )
            return

        initial_params = _prefilled_action_params(
            context,
            menu_id=menu_id,
            action_id=action_id,
            chat_id=chat_id,
        )
        if menu_id in QAC_MENU_IDS and action_id != "summary" and not initial_params:
            await _show_qac_user_picker(
                runtime=runtime,
                context=context,
                chat_id=chat_id,
                query=query,
                menu_id=menu_id,
                page=0,
                menu_page=page,
            )
            return

        await _start_action_flow(
            runtime=runtime,
            context=context,
            chat_id=chat_id,
            user_id=user_id,
            query=query,
            menu=menu,
            action=action,
            initial_params=initial_params,
            page=page,
        )
        return

    await query.answer("Interaksi tidak dikenali. Jalankan /menu lagi.", show_alert=True)


def _load_catalog_from_backend_or_die(backend: BackendClient) -> CommandCatalog:
    deadline = time.monotonic() + BACKEND_MENU_SYNC_TIMEOUT_SECONDS
    attempt = 0
    last_error: Exception | None = None

    while True:
        attempt += 1
        try:
            main_menu = asyncio.run(backend.get_main_menu())
            menus = main_menu.get("menus") if isinstance(main_menu, dict) else None
            if not isinstance(menus, list):
                raise RuntimeError("payload menus tidak valid")
            catalog = CommandCatalog.from_payload({"menus": menus})
            LOGGER.info(
                "Backend menu sync complete: menus=%s mutations_enabled=%s attempts=%s",
                len(catalog.menus),
                bool(main_menu.get("mutations_enabled")) if isinstance(main_menu, dict) else False,
                attempt,
            )
            return catalog
        except (BackendError, RuntimeError) as exc:
            last_error = exc

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RuntimeError(f"Sinkronisasi menu backend gagal: {last_error}") from last_error

        sleep_for = min(BACKEND_MENU_SYNC_RETRY_INTERVAL_SECONDS, remaining)
        LOGGER.warning(
            "Backend menu sync belum siap (attempt=%s retry_in=%.1fs): %s",
            attempt,
            sleep_for,
            last_error,
        )
        time.sleep(sleep_for)


async def post_init(application: Application) -> None:
    runtime = application.bot_data.get("runtime")
    if isinstance(runtime, Runtime):
        try:
            health = await runtime.backend.health()
            LOGGER.info("Backend health: %s", health)
        except Exception as exc:
            LOGGER.warning("Backend health check saat startup gagal: %s", exc)

    try:
        await application.bot.set_my_commands(
            [
                BotCommand("menu", "Open menu utama"),
                BotCommand("cleanup", "Hapus pesan menumpuk"),
            ]
        )
    except Exception as exc:
        LOGGER.warning("Gagal set bot commands: %s", exc)


def main() -> None:
    _configure_logging()

    config = load_config()
    backend = BackendClient(config.backend_base_url, config.shared_secret)
    catalog = _load_catalog_from_backend_or_die(backend)

    runtime = Runtime(
        config=config,
        catalog=catalog,
        backend=backend,
        hostname=socket.gethostname(),
    )

    application = Application.builder().token(config.token).post_init(post_init).build()
    application.bot_data["runtime"] = runtime

    application.add_handler(CommandHandler("start", cmd_start))
    application.add_handler(CommandHandler("menu", cmd_menu))
    application.add_handler(CommandHandler("cleanup", cmd_cleanup))

    application.add_handler(CallbackQueryHandler(on_callback))
    application.add_handler(MessageHandler(filters.Document.ALL, on_document_input))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text_input))
    application.add_error_handler(on_error)

    LOGGER.info("Starting bot-telegram-gateway")
    # Python 3.12 no longer guarantees a default loop for the main thread.
    # PTB still expects one when entering run_polling().
    asyncio.set_event_loop(asyncio.new_event_loop())
    application.run_polling(allowed_updates=["message", "callback_query"])


if __name__ == "__main__":
    main()
